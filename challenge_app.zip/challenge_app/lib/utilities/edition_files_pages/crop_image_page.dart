import 'dart:io';
import 'dart:ui' as ui;

import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:path_provider/path_provider.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:crop/crop.dart';

import '../helper_classes/main_helper.dart';
import '../../configurations/global_setup.dart';

// ignore: must_be_immutable
class CropImagePage extends StatefulWidget {
  static const String route = '/image/crop';

  static const double aspectRatioSquare = 1;
  static const double aspectRatioProfile = 4 / 6;

  double? aspectRatio;
  dynamic pathOrBytes;

  CropImagePage({Key? key, this.pathOrBytes, this.aspectRatio})
      : super(key: key);

  @override
  State<CropImagePage> createState() => _CropImagePageState();
}

class _CropImagePageState extends State<CropImagePage> {
  double _rotation = 0;
  BoxShape shape = BoxShape.rectangle;
  late CropController controller;

  @override
  void initState() {
    controller = CropController(
        aspectRatio: widget.aspectRatio != null ? widget.aspectRatio! : 4 / 6);
    super.initState();
  }

  void _cropImage() async {
    MainHelper.showLoadingDialog(context);

    final pixelRatio = MediaQuery.of(context).devicePixelRatio;
    final cropped = await controller.crop(pixelRatio: pixelRatio);

    final result = await _saveCroppedImage(cropped!);
    if (result != null) {
      // ignore: use_build_context_synchronously
      MainHelper.hideLoadingDialog(context);

      if (MainHelper.isWebPlatform()) {
        // ignore: use_build_context_synchronously
        MainHelper.goBackToPreviousPage(context, result: result);
      } else {
        final tempDir = await getTemporaryDirectory();
        File file = await File('${tempDir.path}/image.png').create();
        file.writeAsBytesSync(result);

        // ignore: use_build_context_synchronously
        MainHelper.goBackToPreviousPage(context, result: file.path);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ToolBar(
      backgroundColor: kTransparentColor,
      title: 'page_title.crop_photo_title'.tr(),
      centerTitle: true,
      leftButtonIcon: Icons.close,
      rightButtonIcon: Icons.check,
      onLeftButtonTap: () => MainHelper.goBackToPreviousPage(context),
      rightButtonPress: _cropImage,
      child: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              color: Colors.black,
              padding: const EdgeInsets.all(8),
              child: Crop(
                onChanged: (decomposition) {
                  if (_rotation != decomposition.rotation) {
                    setState(() {
                      _rotation = ((decomposition.rotation + 180) % 360) - 180;
                    });
                  }
                },
                controller: controller,
                shape: shape,
                // Uncomment if you want to put something in the photo
                foreground: Visibility(
                  visible: Setup.useWatermarkInPhotos,
                  child: IgnorePointer(
                    child: Container(
                      margin: const EdgeInsets.all(5),
                      alignment: Alignment.bottomRight,
                      child: Image.asset(
                        'assets/images/ic_logo.png',
                        width: 120,
                        height: 120,
                      ),
                    ),
                  ),
                ),
                helper: shape == BoxShape.rectangle
                    ? Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                      )
                    : null,
                child: MainHelper.isWebPlatform()
                    ? Image.network(
                        widget.pathOrBytes!,
                        fit: BoxFit.cover,
                      )
                    : MainHelper.isIOSPlatform()
                        ? Image.asset(
                            widget.pathOrBytes,
                            fit: BoxFit.cover,
                          )
                        : Image.file(
                            File(widget.pathOrBytes),
                            fit: BoxFit.cover,
                          ),
              ),
            ),
          ),
          Row(
            children: <Widget>[
              IconButton(
                icon: const Icon(Icons.rotate_right),
                //tooltip: 'Undo',
                onPressed: () {
                  controller.rotation = _rotation >= -180 ? _rotation + 45 : 0;
                  controller.scale = 1;
                  controller.offset = Offset.zero;
                  setState(() {
                    _rotation = _rotation >= -180 ? _rotation + 45 : 0;
                  });
                },
              ),
              Expanded(
                child: SliderTheme(
                  data: theme.sliderTheme.copyWith(
                      //trackShape: CenteredRectangularSliderTrackShape(),
                      ),
                  child: Slider(
                    divisions: 360,
                    value: _rotation,
                    min: -180,
                    max: 180,
                    label: '$_rotation°',
                    onChanged: (n) {
                      setState(() {
                        _rotation = n.roundToDouble();
                        controller.rotation = _rotation;
                      });
                    },
                  ),
                ),
              ),
              Visibility(
                //visible: widget.aspectRatio == null,
                visible: true,
                child: PopupMenuButton<double>(
                  icon: const Icon(Icons.aspect_ratio),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 4 / 6,
                      child: const Text("Recom_").tr(),
                    ),
                    const PopupMenuDivider(),
                    PopupMenuItem(
                      value: 1,
                      child: const Text("square_").tr(),
                    ),
                    const PopupMenuItem(
                      value: 4.0 / 3.0,
                      child: Text("4:3"),
                    ),
                    const PopupMenuItem(
                      value: 1,
                      child: Text("1:1"),
                    ),
                    const PopupMenuItem(
                      value: 3.0 / 4.0,
                      child: Text("3:4"),
                    ),
                    const PopupMenuItem(
                      value: 9.0 / 16.0,
                      child: Text("9:16"),
                    ),
                  ],
                  //tooltip: 'Aspect Ratio',
                  onSelected: (x) {
                    controller.aspectRatio = x;
                    setState(() {});
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<dynamic> _saveCroppedImage(ui.Image img) async {
    var byteData = await img.toByteData(format: ui.ImageByteFormat.png);
    var buffer = byteData!.buffer.asUint8List();

    return buffer;
  }
}
