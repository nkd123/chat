// ignore_for_file: non_constant_identifier_names

import 'dart:convert';

import 'package:challenge/configurations/global_setup.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utilities/helper_classes/main_helper.dart';
import 'global_config.dart';

class Constants {

  static String facebookLoginConfig = "facebookLoginConfig";
  static String phoneLoginConfig = "phoneLoginEnabled";
  static String appleLoginConfig = "appleLoginEnabled";
  static String appleLoginIosConfig = "appleLoginEnabledForIOS";
  static String googleLoginConfig = "googleLoginEnabled";

  static String callsConfig = "calls_enabled";
  static String streamKeyConfig = "stream_key";
  static String streamTypeConfig = "stream_type";

  static String withdrawPaypalConfig = "withdraw_paypal";
  static String withdrawPayoneerConfig = "withdraw_payoneer";
  static String withdrawIbanConfig = "withdraw_bank";
  static String withdrawUSDTConfig = "withdraw_usdt";

  static String agencyPercentConfig = "agency_percent";
  static String diamondsEarnPercentConfig = "diamonds_earn_percent";
  static String diamondsNeededToRedeemConfig = "diamonds_needed_to_redeem";
  static String withDrawPercentConfig = "withdraw_percent";

  static String s3RegionConfig = "s3_region";
  static String s3BucketConfig = "s3_bucket";
  static String s3UrlConfig = "s3_url";
  static String s3AccessKeyConfig = "s3_access_key";
  static String s3SecretKeyConfig = "s3_secret_key";

  static String bannerAdsOnHomeReelsEnabledConfig = "banner_ads_reels";

  static String getNativeAdUnit(){
    if(Setup.isDebug){
      return MainHelper.admobNativeAdTest;
    }else{
      if(MainHelper.isIOSPlatform()){
        return Config.admobAIOSNativeAd;
      }else{
        return Config.admobAndroidNativeAd;
      }
    }
  }

  static String getOpenAdUnit(){
    if(Setup.isDebug){
      return MainHelper.admobOpenAdTest;
    }else{
      if(MainHelper.isIOSPlatform()){
        return Config.admobIOSOpenUp;
      }else{
        return Config.admobAndroidOpenUp;
      }
    }
  }

  static String getAdmobRewardedVideoUnit() {
    if (Setup.isDebug) {
      return MainHelper.isIOSPlatform()
        ? MainHelper.admobRewardedVideoAdTestIos
        : MainHelper.admobRewardedVideoAdTestAndroid;
    } else {
      if (MainHelper.isIOSPlatform()) {
        return Config.admobIOSRewardedVideoAd;
      } else {
        return Config.admobAndroidRewardedVideoAd;
      }
    }
  }

  static String getAdmobBannerUnit() {
    if (Setup.isDebug) {
      return MainHelper.admobBannerAdTest;
    } else {
      if (MainHelper.isIOSPlatform()) {
        return Config.admobIOSBannerAd;
      } else {
        return Config.admobAndroidBannerAd;
      }
    }
  }

  static String getGoogleApiKeyGeo() {
    if (MainHelper.isIOSPlatform()) {
      return Config.googleIosApiKeyGeo;
    } else if (MainHelper.isAndroidPlatform()) {
      return Config.googleAndroidApiKeyGeo;
    } else {
      return Config.googleWebApiKeyGeo;
    }
  }

  static String appPackageName() {
    if (MainHelper.isIOSPlatform()) {
      return Config.appBundleID;
    } else if (MainHelper.isAndroidPlatform()) {
      return Config.packageNameAndroid;
    } else {
      return Config.packageNameAndroid;
    }
  }

  static void QueryParseConfig(SharedPreferences prefs) async {
    final ParseConfig parseConfig = ParseConfig();

    final ParseResponse response = await parseConfig.getConfigs();
    if (response.success) {
      var config = getParseConfigResults(response.result);

      var facebookLogin = config[facebookLoginConfig];
      var phoneLogin = config[phoneLoginConfig];
      var appleLogin = config[appleLoginConfig];
      var appleIosLogin = config[appleLoginIosConfig];
      var googleLogin = config[googleLoginConfig];

      prefs.setBool(facebookLoginConfig, facebookLogin);
      prefs.setBool(phoneLoginConfig, phoneLogin);
      prefs.setBool(appleLoginConfig, appleLogin);
      prefs.setBool(appleLoginIosConfig, appleIosLogin);
      prefs.setBool(googleLoginConfig, googleLogin);
    } else {
      if (prefs.getBool(facebookLoginConfig) == null){
        prefs.setBool(facebookLoginConfig, Setup.isFacebookLoginEnabled);
      }

      if (prefs.getBool(phoneLoginConfig) == null){
        prefs.setBool(phoneLoginConfig, Setup.isPhoneLoginEnabled);
      }

      if (prefs.getBool(appleLoginConfig) == null){
        prefs.setBool(appleLoginConfig, Setup.isAppleLoginEnabled);
      }

      if (prefs.getBool(appleLoginIosConfig) == null){
        prefs.setBool(appleLoginIosConfig, Setup.isAppleLoginEnabled);
      }

      if (prefs.getBool(googleLoginConfig) == null){
        prefs.setBool(googleLoginConfig, Setup.isGoogleLoginEnabled);
      }

    }
  }

  static Map getParseConfigResults(Map response) {
    var body = {};
    body.addAll(response);

    var config = {};
    //uncomment to add object before results
    config = body; // config["config"] = body;
    String result = json.encode(config);

    Map map = json.decode(result);
    return map;
  }
}
