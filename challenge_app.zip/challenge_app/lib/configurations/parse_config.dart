
class ParseConfigParams {
  static const String agoraAppId = 'agora_app_id';

}