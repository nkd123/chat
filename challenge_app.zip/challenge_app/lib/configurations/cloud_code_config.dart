class CloudParams {

  // Cloud endpoints
  static const String updateUserGlobalParam = "update_user_global";
  static const String updateUserGlobalListParam = "update_user_global_list";
  static const String followUserParam = "follow_user";
  static const String sendGiftParam = "send_gift";
  static const String sendAgencyParam = "send_agency";
  static const String rewardChallenger = "reward_challenger";
  static const String resetUserPassword = "reset_password";
  static const String sendCodeToEmail = "send_code";
  static const String verifyCodeFromEmail = "verify_code";

  // Global values
  static const String userGlobal = "user";
  static const String columnGlobal = "column";
  static const String valueGlobal = "value";

  // Sent email Parameters
  static const String sendEmailParam = "send_my_email";
  static const String emailType = "email_type";

  // Verify email Parameters
  static const String verifyEmailParam = "verify_my_email";
  static const String emailVerificationCode = "email_verification_code";

  // Check phone number params
  static const String checkPhoneParam = "check_phone_number";
  static const String phoneNumber = "phone_number";

  // Follow user params
  static const String author = "authorId";
  static const String receiver = "receiverId";
  static const String isFollowing = "isFollowing";

  // Send gift params
  static const String objectId = "objectId";
  static const String credits = "credits";

  // Reward challenger params
  static const String challenger = "challengerId";
  static const String points = "points";

  // Update password
  static const String password = "password";

  // Send code to email
  static const String to = "to";
  static const String from = "from";
  static const String appName = "appName";
  static const String apiKey = "apiKey";

  // Verify code from email
  static const String code = "code";

}