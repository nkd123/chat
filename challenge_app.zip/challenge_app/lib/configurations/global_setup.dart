import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:easy_localization/easy_localization.dart';

import 'global_config.dart';

class Setup {

  static const bool isDebug = kDebugMode;

  static String appName = Config.appName;
  static String appPackageName = Config.packageName;
  static String appVersion = Config.appVersion;
  static const String dataBaseName = '/Challenge';
  static String bio = "welcome_bio".tr(namedArgs: {"app_name" : appName});
  static final List<String> allowedCountries = []; //['FR', 'CA', 'US', 'AO', 'BR'];
  static const int verificationCodeDigits = 6;

  // App config
  static const bool isCallsEnabled = true;
  static const String streamingProviderType = 'agora'; // webrtc
  static const String streamingProviderKey = '01309548fffa441b93bb5bee0c654b38';

  // Social login= Config.appName
  static const bool isFacebookLoginEnabled = true;
  static const bool isPhoneLoginEnabled = true;
  static const bool isGoogleLoginEnabled = true;
  static const bool isAppleLoginEnabled = false;

  // Additional Payments method, Google Play and Apple Pay are enabled by default
  static const bool isStripePaymentsEnabled = false;
  static const bool isPayPalPaymentsEnabled = true;

  // User fields
  static const int welcomeCredit = 10;
  static const int minimumAgeToRegister = 16;
  static const int maximumAgeToRegister = 16;
  static const int maxDistanceBetweenUsers = 80;

  // Amount of days to activate features
  static const int daysToActivateFeatures = 7;

  //Images configurations
  static const bool useWatermarkInPhotos = false;

  // Credits needed to activate features
  static const int crushCreditNeeded = 50;
  static const int typeCreditsRiseUp = 50;
  static const int typeCreditsMoreVisits = 100;
  static const int typeCreditsExtraShows = 100;
  static const int typeCreditsImOnline = 100;
  static const int typeCredits3xPopular = 200;

  // Live Streaming and Calls
  static const int minimumDiamondsToPopular = 100;
  static const int callWaitingDuration = 30; // seconds

  // Enable or Disable Ads and Premium.
  static const bool isPaidMessagesActivated = true;
  static const bool isCrushAdsEnabled = true;
  static const bool isAdsActivated = true;
  static const bool isPremiumEnabled = true;
  static const bool isNearByNativeAdsActivated = true;
  static const bool isEncountersNativeAdsActivated = false;
  static const bool isOpenAppAdsActivated = true;

  //Withdraw calculations
  static const int diamondsEarnPercent = 70; //Percent to give the streamer.
  static const int withDrawPercent = 50; //Percent to give the streamer.
  static const int agencyPercent = 10; //Percent to give the agency.
  static const int diamondsNeededToRedeem = 6000; // Minimum diamonds needed to redeem

  static const String agencySupportNumber = "+244915452765";
  static const String coinsSupportNumber = "+244915452765";
  static const String customerSupportNumber = "+244915452765";

  // Calls cost
  static const int coinsNeededForVideoCallPerMinute = 120; //Coins per minute needed to make video call
  static const int coinsNeededForVoiceCallPerMinute = 60; //Coins per minute needed to make Voice call

  //Leaders
  static const int diamondsNeededForLeaders = 10;

  //Lives
  static const double maxDistanceToNearBy = 500; //In Km
  static const int maxSecondsToShowBigGift = 5; //In seconds

  // Feed
  static const int coinsNeededToForExclusivePost = 50;

  // Ads Config
  static const bool isBannerAdsOnHomeReelsEnabled = false;

  static const bool isWithdrawIbanEnabled = false;
  static const bool isWithdrawPayoneerEnabled = false;
  static const bool isWithdrawPaypalEnabled = true;
  static const bool isWithdrawUSDTlEnabled = true;

}