import 'dart:ui';

class Config {
  //FireBase Setup
  static const String packageNameAndroid = "com.yourdomain.appName";
  static const String appBundleID = "com.yourdomain.appName";
  static const String iosAppStoreId = "";
  static const String packageName = "com.yourdomain.appName";
  static const String appName = "";
  static const String appVersion = "1.1.3";
  static const String companyName = "";
  static const String appOrCompanyUrl = "";
  static const String initialCountry = 'AO'; // Angola

  // Android Admob ad
  static const String admobAndroidRewardedVideoAd = "";
  static const String admobAndroidBannerAd = "";
  static const String admobAndroidOpenUp = "";
  static const String admobAndroidNativeAd = "";

  // iOS Admob ad
  static const String admobIOSRewardedVideoAd = "";
  static const String admobIOSBannerAd = "";
  static const String admobIOSOpenUp = "";
  static const String admobAIOSNativeAd = "";

  // Send Email
  static const String appEmailAddress = '';
  static const String senderGridApiKey = '';

  //New Parse Server Setup
  static const String serverUrl = "https://parseapi.back4app.com/";
  static const String liveQueryUrl = "wss://[your server live query url]";
  static const String appId = "";
  static const String clientKey = "";

  //Agora Engine Live Broadcasting Setup
  static const String agoraAppId = ""; //Without token

  //Languages Setup
  static String defaultLanguage = "en"; // English is default language.
  static List<Locale> languages = [
    Locale(defaultLanguage), //Locale('pt'),
    //Locale('fr')
  ];

  // Dynamic link
  static const String videoSuffix = "video";
  static const String inviteSuffix = "invite";
  static const String uriPrefix = "";
  static const String link = "";

  //Stripe credentials Setup
  static const String stripePublishableKey = "";
  static const String stripeAccountId = "";

  // Web links for help, privacy policy and terms of use. Setup
  static const String helpCenterUrl = "";
  static const String privacyPolicyUrl = "";
  static const String termsOfUseUrl = "";

  //Google Play and Apple Pay In-app Purchases IDs Setup
  static const String credit100 = "challenge.100.credits";
  static const String credit200 = "challenge.200.credits";
  static const String credit500 = "challenge.500.credits";
  static const String credit1000 = "challenge.1000.credits";
  static const String credit2200 = "challenge.2200.credits";
  static const String credit5260 = "challenge.5260.credits";
  static const String credit10600 = "challenge.10600.credits";

  // Signup reward credits
  static const int signupGoldenCoinCredit = 5;
  static const int completeSignupGoldenCoinCredit = 100;

  // Selection rewards
  static const int userSelectionReward = 1;
  static const int challengerSelectionReward = 1;

  // Live points
  static const int userLivePoints = 10;
  static const int endLivePoints = 1;

  // Progress Bar Percentage Limit
  static const int progressBarLimit = 2000000;

  // Admob
  static const int rewardedCredit = 1;

   //Facebook AppID Setup
  static const String facebookAppId = "";

  //More Services Setup
  static const String pushGcm = "";
  static const String googleApiKeyGeo = ""; // Change
  static const String webPushCertificate = "";
  static const String googleIosApiKeyGeo = "";
  static const String googleAndroidApiKeyGeo = "";
  static const String googleWebApiKeyGeo = "";

  // Video time duration
  static const String videoLimitTimeDuration = "00:30";
  static const String videoDefaultTimeDuration = "00:00";
  static const int videoMaxDuration = 30;
}
