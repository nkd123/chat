
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../models/AudioChatUsersModel.dart';
import '../models/CategoryModel.dart';
import '../models/ChallengeModel.dart';
import '../models/GiftSendersGlobalModel.dart';
import '../models/GiftSendersModel.dart';
import '../models/GiftsModel.dart';
import '../models/GiftsSentModel.dart';
import '../models/GroupMessageModel.dart';
import '../models/InvitedUsersModel.dart';
import '../models/LiveMessagesModel.dart';
import '../models/LiveStreamingModel.dart';
import '../models/LiveViewersModel.dart';
import '../models/MessageListModel.dart';
import '../models/MessageModel.dart';
import '../models/NotificationsModel.dart';
import '../models/PaymentsModel.dart';
import '../models/PictureModel.dart';
import '../models/StoriesAuthorsModel.dart';
import '../models/StoriesModel.dart';
import '../models/VideoCommentModel.dart';
import '../models/VideoModel.dart';
import '../models/WithdrawModel.dart';

class AppModels {

  static Map<String, ParseObjectConstructor> subClassMap =
  <String, ParseObjectConstructor>{
    PictureModel.keyTableName: () => PictureModel(),
    NotificationsModel.keyTableName: () => NotificationsModel(),
    MessageModel.keyTableName: () => MessageModel(),
    MessageGroupModel.keyTableName: () => MessageGroupModel(),
    MessageListModel.keyTableName: () => MessageListModel(),
    GiftsModel.keyTableName: () => GiftsModel(),
    GiftsSentModel.keyTableName: () => GiftsSentModel(),
    LiveStreamingModel.keyTableName: () => LiveStreamingModel(),
    LiveMessagesModel.keyTableName: () => LiveMessagesModel(),
    WithdrawModel.keyTableName: () => WithdrawModel(),
    PaymentsModel.keyTableName: () => PaymentsModel(),
    InvitedUsersModel.keyTableName: () => InvitedUsersModel(),
    GiftsSenderModel.keyTableName: () => GiftsSenderModel(),
    GiftsSenderGlobalModel.keyTableName: () => GiftsSenderGlobalModel(),
    StoriesModel.keyTableName: () => StoriesModel(),
    StoriesAuthorsModel.keyTableName: () => StoriesAuthorsModel(),
    ChallengeModel.keyTableName: () => ChallengeModel(),
    VideoModel.keyTableName: () => VideoModel(),
    VideoCommentModel.keyTableName: () => VideoCommentModel(),
    CategoryModel.keyTableName: () => CategoryModel(),
    AudioChatUsersModel.keyTableName: () => AudioChatUsersModel(),
    LiveViewersModel.keyTableName: () => LiveViewersModel(),
  };

}
