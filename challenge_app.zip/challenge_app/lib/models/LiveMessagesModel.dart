// ignore_for_file: file_names

import 'package:challenge/models/GiftsSentModel.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class LiveMessagesModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "StreamingMessage";

  LiveMessagesModel() : super(keyTableName);
  LiveMessagesModel.clone() : this();

  @override
  LiveMessagesModel clone(Map<String, dynamic> map) => LiveMessagesModel.clone()..fromJson(map);


  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static const String messageTypeComment = "COMMENT";
  static const String messageTypeFollow = "FOLLOW";
  static const String messageTypeGift = "GIFT";
  static const String messageTypeSystem = "SYSTEM";
  static const String messageTypeJoin = "JOIN";
  static const String messageTypeCoHost = "HOST";
  static const String messageTypeLike = "LIKE";
  static const String messageTypeLeave = "LEAVE";
  static const String messageTypeRemoved = "REMOVED";

  static const String keySenderAuthor = "author";
  static const String keySenderAuthorId = "authorId";

  static const String keyLiveStreaming = "liveStream";
  static const String keyLiveStreamingId = "liveStreamId";

  static const String keyGiftSent = "giftLive";
  static const String keyGift = "giftLive";
  static const String keyGiftSentGift = "giftLive.gift";
  static const String keyGiftId = "giftLiveId";

  static const String keyMessage = "message";
  static const String keyMessageType = "messageType";

  static const String keyCoHostAvailable = "coHostAvailable";
  static const String keyCoHostAuthor = "coHostAuthor";
  static const String keyCoHostAuthorUid = "coHostAuthorUid";


  UserModel? get getAuthor => get<UserModel>(keySenderAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keySenderAuthor, author);

  String? get getAuthorId => get<String>(keySenderAuthorId);
  set setAuthorId(String authorId) => set<String>(keySenderAuthorId, authorId);

  UserModel? get getCoHostAuthor => get<UserModel>(keyCoHostAuthor);
  set setCoHostAuthor(UserModel author) => set<UserModel>(keyCoHostAuthor, author);

  int? get getCoHostAuthorUid => get<int>(keyCoHostAuthorUid);
  set setCoHostAuthorUid(int authorUid) => set<int>(keyCoHostAuthorUid, authorUid);

  bool? get getCoHostAuthorAvailable => get<bool>(keyCoHostAvailable);
  set setCoHostAvailable(bool coHostAvailable) => set<bool>(keyCoHostAvailable, coHostAvailable);

  String? get getMessage => get<String>(keyMessage);
  set setMessage(String message) => set<String>(keyMessage, message);

  String? get getMessageType => get<String>(keyMessageType);
  set setMessageType(String messageType) => set<String>(keyMessageType, messageType);

  LiveStreamingModel? get getLiveStreaming => get<LiveStreamingModel>(keyLiveStreaming);
  set setLiveStreaming(LiveStreamingModel liveStreaming) => set<LiveStreamingModel>(keyLiveStreaming, liveStreaming);

  String? get getLiveStreamingId => get<String>(keyLiveStreamingId);
  set setLiveStreamingId(String liveStreamingId) => set<String>(keyLiveStreamingId, liveStreamingId);

  GiftsSentModel? get getGiftSent => get<GiftsSentModel>(keyGift);
  set setGiftSent(GiftsSentModel giftsSent) => set<GiftsSentModel>(keyGift, giftsSent);

  String? get getGiftSentId => get<String>(keyGiftId);
  set setGiftSentId(String giftSentId) => set<String>(keyGiftId, giftSentId);

  String? get getGiftId => get<String>(keyGiftId);
  set setGiftId(String giftId) => set<String>(keyGiftId, giftId);

}