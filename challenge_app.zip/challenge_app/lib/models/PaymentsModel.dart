// ignore_for_file: file_names

import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class PaymentsModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Payments";

  PaymentsModel() : super(keyTableName);
  PaymentsModel.clone() : this();

  @override
  PaymentsModel clone(Map<String, dynamic> map) => PaymentsModel.clone()..fromJson(map);

  static const String paymentTypeConsumible = "consumable";
  static const String paymentTypeSubscription = "subscription";

  static const String paymentStatusPending = "pending";
  static const String paymentStatusCompleted = "completed";
  static const String paymentStatusRefunded = "refunded";

  static const String keyCreatedAt = "createdAt";

  static const String keyAuthor = "author";
  static const String keyAuthorId = "authorId";

  static const String keyPaymentMethod = "method";
  static const String keyPaymentStatus = "status";
  static const String keyPaymentType = "type";

  static const String keyItemId = "sku";
  static const String  keyItemName = "name";
  static const String  keyItemPrice = "price";
  static const String  keyItemCurrency = "currency";
  static const String  keyItemTransactionId = "transactionId";

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  String? get getPaymentType => get<String>(keyPaymentType);
  set setPaymentType(String authorId) => set<String>(keyPaymentType, authorId);

  String? get getStatus => get<String>(keyPaymentStatus);
  set setStatus(String status) => set<String>(keyPaymentStatus, status);

  String? get getMethod => get<String>(keyPaymentMethod);
  set setMethod(String method) => set<String>(keyPaymentMethod, method);

  String? get getPrice => get<String>(keyItemPrice);
  set setPrice(String email) => set<String>(keyItemPrice, email);

  String? get getCurrency => get<String>(keyItemCurrency);
  set setCurrency(String currency) => set<String>(keyItemCurrency, currency);

  String? get getId => get<String>(keyItemId);
  set setId(String id) => set<String>(keyItemId, id);

  String? get getTitle => get<String>(keyItemName);
  set setTitle(String title) => set<String>(keyItemName, title);

  String? get getTransactionId => get<String>(keyItemTransactionId);
  set setTransactionId(String title) => set<String>(keyItemTransactionId, title);

}