// ignore_for_file: file_names
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:easy_localization/easy_localization.dart';

import '../configurations/global_setup.dart';
import 'CategoryModel.dart';

class UserModel extends ParseUser implements ParseCloneable {

  UserModel(String? username, String? password, String? emailAddress)
      : super(username, password, emailAddress);

  UserModel.clone() : this(null, null, null);

  UserModel.forQuery() : super(null, null, null);

  @override
  clone(Map map) => UserModel.clone()..fromJson(map as Map<String, dynamic>);

  static Future<UserModel> getUserResult(dynamic user) async{

    UserModel? user = await ParseUser.currentUser();
    user = UserModel.clone()..fromJson(user as Map<String, dynamic>);

    return user;
  }

  static String keyObjectId = "objectId";
  static const sexualityAskMe = "AM";

  static const anyUser = "AU";
  static const onlyMyFriends = "OF";

  //Categories
  static const categoryDance = "DNC";
  static const categoryART = "ART";
  static const categoryJOKES = "JKS";
  static const categorySPORT = "SPT";
  static const categoryLOGIC = "LGC";
  static const categoryFUN = "FUN";
  static const categoryCOOK = "COK";
  static const categorySING = "SNG";
  static const categoryINVENTIVE = "INV";
  static const categoryFAMILY = "FAM";
  static const categorySNERVATING = "SNR";
  static const categoryPENANCE = "PEN";

  //User gender
  static const genderMALE = "MAL";
  static const genderFEMALE = "FML";
  static const genderOTHER = "OTR";

  //School
  static const schoolHIGHSCHOOL = "HSC";
  static const schoolUNIVERSITY = "UNV";

  //Favorite Films
  static const filmHORROR = "HOR";
  static const filmCOMEDY= "CMD";
  static const filmDRAMATIC = "DRM";

  //Hobby
  static const hobbyDANCE = "DNC";
  static const hobbyCOOK= "COK";
  static const hobbySPORT = "SPR";

  //Status
  static const statusSINGLE = "SIG";
  static const statusRELATIONSHP= "REL";

  // User role
  static const String roleUser = "user";
  static const String roleAdmin = "admin";

  // Filter
  static const String keyGenderMale = "male";
  static const String keyGenderFemale = "female";
  static const String keyGenderBoth = "both";

  static const String keyStatusAll = "all";
  static const String keyStatusOnline= "online";
  static const String keyStatusNew = "new";

  //User Categories
  static const String keyCategories = "categories";
  static const String keyCategory = "category";
  static const String keyCategoryId = "categoryId";

  // Backend field
  static const String keyUid = "uid";
  static const String keyId = "objectId";
  static const String keySessionToken = 'sessionToken';
  static const String keyCreatedAt = "createdAt";
  static const String keyUpdatedAt = "updatedAt";
  static const String keyInstallation = "installation";

  // User sensitive data
  static const String keyRole = "role";
  static const String keyUsername = "username";
  static const String keyEmail = "email";
  static const String keyEmailPublic = 'email_public';
  static const String keyEmailVerified = 'emailVerified';
  static const String keySecondaryPassword = 'secondary_password';
  static const String keyHasPassword = "has_password";
  static const String keyHasChangedName = "has_name_changed";
  static const String keyAccountHidden = "account_hidden";
  static const String keyNationality = "nationality";
  static const String keyFavoriteFilm = "favoriteFilm";
  static const String keyHobby = "hobby";

  // Reported videos
  static const String keyReportedVideos = "reportedVideos";

  // User required data
  static const String keyFullName = "name";
  static const String keyFirstName = "first_name";
  static const String keyLastName = "last_name";
  static const String keyBio = "bio";
  static const String keyBirthday = "birthday";
  static const String keyAge = "age";
  static const String keyGender = "gender";
  static const String keyAvatar = "avatar";
  static const String keyCover = "cover";

  // Phone data
  static const String keyCountry = "country";
  static const String keyCountryCode = "country_code";
  static const String keyCountryDialCode = "country_dial_code";
  static const String keyPhoneNumber = "phone_number";
  static const String keyPhoneNumberFull = "phone_number_full";

  // Social media fields
  static const String keyFacebookId = "fbId";
  static const String keyGoogleId = "ggId";
  static const String keyAppleId = "appleId";
  static const String keyInstagramId = "instaId";
  static const String keyInstagramLink = "instaLink";
  static const String keyInstagramToken = "instaToken";

  // User additional data
  static const String keyPhotoVerified = "photo_verified";
  static const String keyAboutMe = "aboutMe";
  static const String keyGeoPoint = "geopoint";
  static const String keyHasGeoPoint = "hasGeopoint";
  static const String keyLocation = "location";
  static const String keyCity = "city";
  static const String keyHideMyLocation = "hideLocation";
  static const String keyLastOnline = "lastOnline";
  static const String keyUserStatus = "activationStatus";
  static const String keyUserAccountDeleted = "accountDeleted";
  static const String keyUserAccountDeletedReason = "accountDeletedReason";
  static const String keyPopularity = "popularity";

  // User filter preferences
  static const String keyPrefLocationType = "prefLocationType";
  static const String keyPrefGender = "prefGender";
  static const String keyPrefStatus = "prefStatus";
  static const String keyPrefMinimumAge = "prefMinAge";
  static const String keyPrefMaximumAge = "prefMaxAge";
  static const String keyPrefDistance = "distanceFilter";

  // Vip and Premium features
  static const String keyPremiumLifeTime = "premium_lifetime";
  static const String keyPremium = "premium";
  static const String keyCoins = "credit";
  static const String keyPoints = "points";
  static const String keyPointsTotal = "pointsTotal";

  static const String keyPointsAgency = "pointsAgency";
  static const String keyPointsAgencyTotal = "pointsAgencyTotal";

  // School and job
  static const String keyCompanyName = "company_name";
  static const String keyJobTitle = "job_title";
  static const String keySchool = "school";

  // Mood
  static const String keyMoodTitle = "mood";

  // Credits features to activate
  static const String vipAdsDisabled = "AdsDisabled";
  static const String vip3xPopular = "popular";
  static const String vipShowOnline = "showOnline";
  static const String vipExtraShows = "extraShows";
  static const String vipMoreVisits = "getMoreVisits";
  static const String vipMoveToTop = "moveToTop";

  // Premium invisible mode
  static const String vipInvisibleMode = "invisibleMode";
  static const String vipIsInvisible = "isInvisible";

  // Users blocks
  static const String keyBlockedUsers = "blockedUsers";
  static const String keyBlockedUserIDs = "blockedUsersIDs";

  // Content blocks
  static const String keyBlokedContentIDs = "blockedContentIDs";

  // Privacy
  static const String keyPrivacyShowDistance = "privacyShowDistance";
  static const String keyPrivacyShowStatusOnline = "privacyShowOnlineStatus";

  // Edit profile
  static const String keyWhatIWant = "profile_honestly_want";
  static const String keyRelationship = "profile_relationship";
  static const String keySexuality = "profile_sexuality";
  static const String keyHeight = "profile_body_height";
  static const String keyBodyType = "profile_body_type";
  static const String keyLiving = "profile_living";
  static const String keyKids = "profile_kids";
  static const String keySmoking = "profile_smoking";
  static const String keyDrinking = "profile_drinking";
  static const String keyLanguage = "profile_language";

  static const String keyPassions = "profile_passions";
  static const String keySexualOrientations = "profile_sex_orientations";

  static const String keyShowGenderInProfile = "profile_show_gender";
  static const String keyShowSexualOrientationInProfile = "profile_show_sex_orientation";
  static const String keyDistanceInMiles = "profile_distance_miles";

  static const String keyFollowing = "following";
  static const String keyFollowers = "followers";
  static const String keyPayouts = "payouts";

  static const String keyReceiveChatRequest = "receiveChatRequest";
  static const String keyShowUpInSearch = "showUpInSearch";
  static const String keyShowVipLevel = "showVipLevel";
  static const String keyShowLocation = "showLocation";
  static const String keyShowLastTimeSeen = "showLastTimeSeen";
  static const String keyInvisibleMode = "invisibleMode";
  static const String keyShowMyPostsTo = "showMyPostsTo";

  static const String keySendReadReceipts = "sendReadReceipts";
  static const String keyEnableOneClickGifting = "enableOneClickGifting";
  static const String keyDenyBeInvitedToLiveParty = "denyBeInvitedToLiveParty";
  static const String keyDenyPictureInPictureMode = "denyPictureInPictureMode";
  static const String keyAllowViewersToPremiumStream = "allowViewersToPremiumStream";

  // Notifications
  static const String keyLiveNotification = "liveNotification";
  static const String keyMuteIncomingCalls = "muteIncomingCalls";
  static const String keyNotificationSounds = "notificationSounds";
  static const String keyInAppSound = "inAppSound";
  static const String keyInAppVibration = "inAppVibration";
  static const String keyGameNotification = "gameNotification";

  static const String keyReportedPostsIDs = "reportedPostsID";
  static const String keyReportedPostReason = "reportedPostReason";

  static const String keyPayoneerEmail= "payoneerEmail";
  static const String keyPaypalEmail= "paypalEmail";
  static const String keyIban= "Iban";
  static const String keyAccountName = "account_name";
  static const String keyBankName = "bank_name";

  static const String keyNeedsChangeName= "nameToChange";

  static const String keyInvitedUsers = "invitedUsers";
  static const String keyInvitedByUser = "invitedByUser";
  static const String keyInvitedAnswered = "inviteQuestion";

  static const String keyIsViewer = "isViewer";

  static const String keyChallenge = "challenges";
  static const String keyChallengePoint = "challenge_point";
  static const String keyGoldenCoin = "golden_coin";
  static const String keyVictories = "victories";

  static const String keyLosses = "losses";
  static const String keyDraws = "draws";
  static const String keyMedals = "medals";
  static const String keyTrophy = "trophy";

  static const String keyFriends = "friends";
  static const String keySaves = "saves";
  static const String keyCoinsSent = "creditSent";

  List<dynamic>? get getReportedVideos{
    List<dynamic>? videos = get<List<dynamic>>(keyReportedVideos);
    if(videos != null && videos.isNotEmpty){
      return videos;
    } else {
      return [];
    }
  }
  set setReportedVideos(String videoId) => setAddUnique(keyReportedVideos, videoId);

  int? get getChallenge => get<int>(keyChallenge);
  set setChallenge(int challenges) => set<int>(keyChallenge, challenges);

  int? get getChallengePoint => get<int>(keyChallengePoint);
  set setChallengePoint(int point) => set<int>(keyChallengePoint, point);

  int? get getGoldenCoin => get<int>(keyGoldenCoin);
  set setGoldenCoin(int coins) => set<int>(keyGoldenCoin, coins);

  int? get getVictories => get<int>(keyVictories);
  set setVictories(int victories) => set<int>(keyVictories, victories);

  int? get getLosses => get<int>(keyLosses);
  set setLosses(int losses) => set<int>(keyLosses, losses);

  int? get getDraws => get<int>(keyDraws);
  set setDraws(int draws) => set<int>(keyDraws, draws);

  int? get getMedals => get<int>(keyMedals);
  set setMedals(int medals) => set<int>(keyMedals, medals);

  int? get getTrophy => get<int>(keyTrophy);
  set setTrophy(int trophy) => set<int>(keyTrophy, trophy);

  String? get getSessionToken => get<String>(keySessionToken);

  int? get getUid => get<int>(keyUid);
  set setUid(int uid) => set<int>(keyUid, uid);

  String? get getUserRole => get<String>(keyRole);
  set setUserRole(String role) => set<String>(keyRole, role);

  String? get getUsername => get<String>(keyUsername);
  set setUsername(String username) => set<String>(keyUsername, username);

  String? get getEmail => get<String>(keyEmail);
  set setEmail(String email) => set<String>(keyEmail, email);

  String? get getEmailPublic => get<String>(keyEmailPublic);
  set setEmailPublic(String emailPublic) => set<String>(keyEmailPublic, emailPublic);

  String? get getFullName => get<String>(keyFullName);
  set setFullName(String fullName) => set<String>(keyFullName, fullName);

  String? get getFirstName => get<String>(keyFirstName);
  set setFirstName(String firstName) => set<String>(keyFirstName, firstName);

  CategoryModel? get getCategory => get<CategoryModel>(keyCategory);
  set setCategory(CategoryModel category) => set<CategoryModel>(keyCategory, category);

  String? get getCategoryId => get<String>(keyCategoryId);
  set setCategoryId(String categoryId) => set<String>(keyCategoryId, categoryId);

  List<dynamic>? get getFriends{

    List<dynamic>? friends = get<List<dynamic>>(keyFriends);
    if(friends != null && friends.isNotEmpty){
      return friends;
    } else {
      return [];
    }
  }
  set setFriends(String authorId) => setAddUnique(keyFriends, authorId);
  set removeFriends(String authorId) => setRemove(keyFriends, authorId);

  List<dynamic>? get getSaves{

    List<dynamic>? saves = get<List<dynamic>>(keySaves);
    if(saves != null && saves.isNotEmpty){
      return saves;
    } else {
      return [];
    }
  }
  set setSaves(String videoId) => setAddUnique(keySaves, videoId);
  set removeSaves(String videoId) => setRemove(keySaves, videoId);

  String? get getLastName => get<String>(keyLastName);
  set setLastName(String lastName) => set<String>(keyLastName, lastName);

  String? get getGender => get<String>(keyGender);
  set setGender(String gender) => set<String>(keyGender, gender);

  String? get getGenderPref {

    String? prefGender = get<String>(keyPrefGender);
    if(prefGender != null){
      return prefGender;
    } else {
      return keyGenderBoth;
    }
  }
  set setGenderPref(String genderPref) => set<String>(keyPrefGender, genderPref);

  int? get getPrefDistance {

    int? prefDistance = get<int>(keyPrefDistance);
    if(prefDistance != null){
      return prefDistance;
    } else {
      return Setup.maxDistanceBetweenUsers;
    }
  }
  set setPrefDistance(int prefDistance) => set<int>(keyPrefDistance, prefDistance);

  String? get getBio => get<String>(keyBio);
  set setBio(String bio) => set<String>(keyBio, bio);

  dynamic get getAvatar => get<dynamic>(keyAvatar);
  set setAvatar(ParseFileBase parseFileBase) => set<ParseFileBase>(keyAvatar, parseFileBase);

  ParseFileBase? get getCover => get<ParseFileBase>(keyCover);
  set setCover(ParseFileBase parseFileBase) => set<ParseFileBase>(keyCover, parseFileBase);

  DateTime? get getBirthday => get<DateTime>(keyBirthday);
  set setBirthday(DateTime birthday) => set<DateTime>(keyBirthday, birthday);

  DateTime? get getLastOnline => get<DateTime>(keyLastOnline);
  set setLastOnline(DateTime time) => set<DateTime>(keyLastOnline, time);

  bool? get getEmailVerified => get<bool>(keyEmailVerified);
  set setEmailVerified(bool emailVerified) => set<bool>(keyEmailVerified, emailVerified);

  bool? get getActivationStatus => get<bool>(keyUserStatus);
  set setActivationStatus(bool activated) => set<bool>(keyUserStatus, activated);

  bool? get getIsViewer => get<bool>(keyIsViewer);
  set setIsViewer(bool isViewer) => set<bool>(keyIsViewer, isViewer);

  bool? get getAccountDeleted => get<bool>(keyUserAccountDeleted);
  set setAccountDeleted(bool deleted) => set<bool>(keyUserAccountDeleted, deleted);

  String? get getFacebookId {
    String? content = get<String>(keyFacebookId);
    if(content != null && content.isNotEmpty){
      return content;
    } else {
      return "";
    }
  }
  set setFacebookId(String facebookId) => set<String>(keyFacebookId, facebookId);

  String? get getGoogleId {
    String? content = get<String>(keyGoogleId);
    if(content != null && content.isNotEmpty){
      return content;
    } else {
      return "";
    }
  }

  String? get getAccountDeletedReason => get<String>(keyUserAccountDeletedReason);
  set setAccountDeletedReason(String reason) => set<String>(keyUserAccountDeletedReason, reason);

  String? get getNationality => get<String>(keyNationality);
  set setNationality(String nationality) => set<String>(keyNationality, nationality);

  String? get getFavoriteFilm => get<String>(keyFavoriteFilm);
  set setFavoriteFilm(String film) => set<String>(keyFavoriteFilm, film);

  String? get getHobby => get<String>(keyHobby);
  set setHobby(String hobby) => set<String>(keyHobby, hobby);

  set setGoogleId(String googleId) => set<String>(keyGoogleId, googleId);

  String? get getAppleId => get<String>(keyAppleId);
  set setAppleId(String appleId) => set<String>(keyAppleId, appleId);

  String? get getInstagramId => get<String>(keyInstagramId);
  set setInstagramId(String instagramId) => set<String>(keyInstagramId, instagramId);

  bool? get getHasPassword => get<bool>(keyHasPassword);
  set setHasPassword(bool hasPassword) => set<bool>(keyHasPassword, hasPassword);

  bool? get getHasGeoPoint {

    bool? hasGeoPoint = get<bool>(keyHasGeoPoint);
    if(hasGeoPoint != null){
      return hasGeoPoint;
    } else {
      return false;
    }
  }
  set setHasGeoPoint(bool hasGeoPoint) => set<bool>(keyHasGeoPoint, hasGeoPoint);

  bool? get getLocationTypeNearBy {

    bool? locationPref = get<bool>(keyPrefLocationType);
    if(locationPref != null){
      return locationPref;
    } else {
      return true;
    }
  }
  set setLocationTypeNearBy(bool prefLocationType) => set<bool>(keyPrefLocationType, prefLocationType);

  String? get getLocation {
    String? location = get<String>(keyLocation);
    if(location != null && location.isNotEmpty){

      if(getHideMyLocation == true){
        return "edit_profile.city_hidden".tr();
      } else {
        return location;
      }

    } else {
        return "edit_profile.no_location_update".tr();
    }
  }

  String? get getLocationOrEmpty {
    String? location = get<String>(keyLocation);
    if(location != null && location.isNotEmpty){
      return location;
    } else {
      return "";
    }
  }
  String? get getLocationOnly {
    String? location = get<String>(keyLocation);
    if(location != null && location.isNotEmpty){
      return location;
    } else {
      return "edit_profile.add_city_name".tr();
    }
  }
  set setLocation(String locationName) => set<String>(keyLocation, locationName);

  String? get getCity {
    String? city = get<String>(keyCity);
    if(city != null && city.isNotEmpty){
      return city;
    } else {
      return "";
    }
  }
  set setCity(String city) => set<String>(keyCity, city);

  int? get getPopularity => get<int>(keyPopularity);
  set setPopularity(int popularity) => set<int>(keyPopularity, popularity);

  int? get getPrefMinAge {
    int? prefAge = get<int>(keyPrefMinimumAge);
    if(prefAge != null){
      return prefAge;
    } else {
      return Setup.minimumAgeToRegister;
    }
  }
  set setPrefMinAge(int minAge) => set<int>(keyPrefMinimumAge, minAge);

  int? get getPrefMaxAge {
    int? prefAge = get<int>(keyPrefMaximumAge);
    if(prefAge != null){
      return prefAge;
    } else {
      return Setup.maximumAgeToRegister;
    }
  }
  set setPrefMaxAge(int maxAge) => set<int>(keyPrefMaximumAge, maxAge);

  int? get getCredits => get<int>(keyCoins);
  set addCredit(int credits) => setIncrement(keyCoins, credits);
  set removeCredit(int credits) => setDecrement(keyCoins, credits);

  String? get getCountry {
    String? country = get<String>(keyCountry);
    if(country != null && country.isNotEmpty){
      return country;
    } else {
      return "";
    }
  }
  set setCountry(String country) => set<String>(keyCountry, country);

  String? get getCountryCode => get<String>(keyCountryCode);
  set setCountryCode(String countryCode) => set<String>(keyCountryCode, countryCode);

  String? get getCountryDialCode => get<String>(keyCountryDialCode);
  set setCountryDialCode(String countryDialCode) => set<String>(keyCountryDialCode, countryDialCode);

  String? get getPhoneNumber {
    String? phone = get<String>(keyPhoneNumber);
    if(phone != null && phone.isNotEmpty){
      return phone;
    } else {
      return "";
    }
  }

  set setPhoneNumber(String phoneNumber) => set<String>(keyPhoneNumber, phoneNumber);

  set setPhoneNumberFull(String phoneNumberFull) => set<String>(keyPhoneNumberFull, phoneNumberFull);

  String? get getPhoneNumberFull {
    String? phone = get<String>(keyPhoneNumberFull);
    if(phone != null && phone.isNotEmpty){
      return phone;
    } else {
      return "";
    }
  }

  String? get getCompanyName {
    String? company = get<String>(keyCompanyName);
    if(company != null && company.isNotEmpty){
      return company;
    } else {
      return "";
    }
  }
  set setCompanyName(String companyName) => set<String>(keyCompanyName, companyName);

  String? get getJobTitle {

    String? job = get<String>(keyJobTitle);
    if(job != null && job.isNotEmpty){
      return job;
    } else {
      return "";
    }
  }
  set setJobTitle(String jobTitle) => set<String>(keyJobTitle, jobTitle);

  String? get getSchool {

    String? school = get<String>(keySchool);
    if(school != null && school.isNotEmpty){
      return school;
    } else {
      return "";
    }

  }
  set setSchool(String school) => set<String>(keySchool, school);

  String? get getAboutYou {

    String? about = get<String>(keyAboutMe);

    if(about != null && about.isNotEmpty){
      return about;

    } else {
      return "";
    }

  }
  set setAboutYou(String about) => set<String>(keyAboutMe, about);

  String? get getMoodTitle{
    String? mood = get<String>(keyMoodTitle);
    if(mood != null && mood.isNotEmpty){
      return mood;
    } else {
      return "";
    }
  }
  set setMoodTitle(String moodTitle) => set<String>(keyMoodTitle, moodTitle);

  bool? get isPhotoVerified {
    bool? photoVerified = get<bool>(keyPhotoVerified);
    if(photoVerified != null){
      return photoVerified;
    } else {
      return false;
    }
  }

  set setPhotoVerified(bool photoVerified) => set<bool>(keyPhotoVerified, photoVerified);

  bool? get isPremium {
    //return true;
    bool? premium = get<bool>(keyPremium);
    if(premium != null){
      return premium;
    } else {
      return false;
    }
  }

  set setNeedsChangeName(bool nameNeedsChange) => set<bool>(keyNeedsChangeName, nameNeedsChange);

  bool? get getNeedsChangeName {
    bool? needChange = get<bool>(keyNeedsChangeName);
    if(needChange != null){
      return needChange;
    } else {
      return false;
    }
  }

  set setPremium(bool premium) => set<bool>(keyPremium, premium);

  DateTime? get getVipAdsDisabled => get<DateTime>(vipAdsDisabled);
  set setVipAdsDisabled(DateTime adsDisabled) => set<DateTime>(vipAdsDisabled, adsDisabled);

  DateTime? get getVip3xPopular => get<DateTime>(vip3xPopular);
  set setVip3xPopular(DateTime xPopular) => set<DateTime>(vip3xPopular, xPopular);

  DateTime? get getVipShowOnline => get<DateTime>(vipShowOnline);
  set setVipShowOnline(DateTime showOnline) => set<DateTime>(vipShowOnline, showOnline);

  DateTime? get getVipExtraShows => get<DateTime>(vipExtraShows);
  set setVipExtraShows(DateTime extraShows) => set<DateTime>(vipExtraShows, extraShows);

  DateTime? get getVipMoreVisits => get<DateTime>(vipMoreVisits);
  set setVipMoreVisits(DateTime moreVisits) => set<DateTime>(vipMoreVisits, moreVisits);

  DateTime? get getVipMoveToTop => get<DateTime>(vipMoveToTop);
  set setVipMoveToTop(DateTime moveToTop) => set<DateTime>(vipMoveToTop, moveToTop);

  bool? get getVipInvisibleMode => get<bool>(vipInvisibleMode);
  set setVipInvisibleMode(bool invisibleMode) => set<bool>(vipInvisibleMode, invisibleMode);

  bool? get getVipIsInvisible => get<bool>(vipIsInvisible);
  set setVipIsInvisible(bool isInvisible) => set<bool>(vipIsInvisible, isInvisible);

  set setNameChanged(bool nameChanged) => set<bool>(keyHasChangedName, nameChanged);

  bool? get getAccountHidden => get<bool>(keyAccountHidden);
  set setAccountHidden(bool accountHidden) => set<bool>(keyAccountHidden, accountHidden);

  List<dynamic>? get getBlockedUsers{

    List<dynamic>? users = get<List<dynamic>>(keyBlockedUsers);
    if(users != null){
      return users;
    } else {
      return [];
    }
  }
  set setBlockedUsers(List<UserModel> blockedUsers) => set<List<UserModel>>(keyBlockedUsers, blockedUsers);

  // ----------------------------------------------------------
  List<dynamic>? get getBlockedUsersIDs{

    List<dynamic>? users = get<List<dynamic>>(keyBlockedUserIDs);
    if(users != null){
      return users;
    } else {
      return [];
    }
  }

  set setBlockedUsersIDs(List<dynamic> blockedUsersIDs) => set<List<dynamic>>(keyBlockedUserIDs, blockedUsersIDs);

  set setBlockedUserIds(String blockedUser) {
    List<String> user = [];
    user.add(blockedUser);
    setAddAllUnique(keyBlockedUserIDs, user);
  }

  set removeBlockedUserIds(String blockedUser) {
    List<String> user = [];
    user.add(blockedUser);

    setRemoveAll(keyBlockedUserIDs, user);
  }
  // ----------------------------------------------------------'


  // ----------------------------------------------------------
  List<dynamic>? get getBlockedContentIDs{

    List<dynamic>? contents = get<List<dynamic>>(keyBlokedContentIDs);
    if(contents != null){
      return contents;
    } else {
      return [];
    }
  }

  /*set setBlockedContentIDs(List<dynamic> blockedContentIDs)
    => set<List<dynamic>>(keyBlokedContentIDs, blockedContentIDs);*/

  set setBlockedContentIds(String blockedContent) {
    List<String> content = [];
    content.add(blockedContent);
    setAddAllUnique(keyBlokedContentIDs, content);
  }

  set removeBlockedContentIds(String blockedContent) {
    List<String> content = [];
    content.add(blockedContent);

    setRemoveAll(keyBlokedContentIDs, content);
  }
  // ----------------------------------------------------------'


  set setBlockedUser(UserModel blockedUser) {
    setAddUnique(keyBlockedUsers, blockedUser.objectId!);
  }

  set removeBlockedUsers(List<UserModel> blockedUsers) {
    setRemoveAll(keyBlockedUsers, blockedUsers);
  }

  set removeBlockedUser(UserModel blockedUser) {
    List<UserModel> user = [];
    user.add(blockedUser);

    setRemoveAll(keyBlockedUsers, user);
  }

  bool? get getPrivacyShowDistance {

    bool? privacyShowDistance = get<bool>(keyPrivacyShowDistance);
    if(privacyShowDistance != null){
      return !privacyShowDistance;
    } else {
      return true;
    }
  }
  set setPrivacyShowDistance(bool privacyShowDistance) => set<bool>(keyPrivacyShowDistance, privacyShowDistance);

  bool? get getPrivacyShowStatusOnline {

    bool? privacyShowStatusOnline = get<bool>(keyPrivacyShowStatusOnline);
    if(privacyShowStatusOnline != null){
      return !privacyShowStatusOnline;
    } else {
      return true;
    }
  }
  set setPrivacyShowStatusOnline(bool privacyShowStatusOnline) => set<bool>(keyPrivacyShowStatusOnline, privacyShowStatusOnline);

  String? get getWhatIWant {

    String? what = get<String>(keyWhatIWant);
    if(what != null){
      return what;
    } else {
      return "";
    }
  }
  set setWhatIWant(String whatIWant) => set<String>(keyWhatIWant, whatIWant);

  String? get getLanguage {

    String? language = get<String>(keyLanguage);
    if(language != null){
      return language;
    } else {
      return "";
    }
  }
  set setLanguage(String language) => set<String>(keyLanguage, language);

  String? get getDrinking {

    String? drinking = get<String>(keyDrinking);
    if(drinking != null){
      return drinking;
    } else {
      return "";
    }
  }
  set setDrinking(String drinking) => set<String>(keyDrinking, drinking);

  String? get getSmoking {

    String? smoking = get<String>(keySmoking);
    if(smoking != null){
      return smoking;
    } else {
      return "";
    }
  }
  set setSmoking(String smoking) => set<String>(keySmoking, smoking);

  String? get getKids {

    String? kids = get<String>(keyKids);
    if(kids != null){
      return kids;
    } else {
      return "";
    }
  }
  set setKids(String kids) => set<String>(keyKids, kids);

  String? get getLiving {

    String? living = get<String>(keyLiving);
    if(living != null){
      return living;
    } else {
      return "";
    }
  }
  set setLiving(String living) => set<String>(keyLiving, living);

  String? get getBodyType {

    String? bodyType = get<String>(keyBodyType);
    if(bodyType != null){
      return bodyType;
    } else {
      return "";
    }
  }
  set setBodyType(String bodyType) => set<String>(keyBodyType, bodyType);

  int? get getHeight {

    int? height = get<int>(keyHeight);
    if(height != null){
      return height;
    } else {
      return 91;
    }
  }
  set setHeight(int height) => set<int>(keyHeight, height);

  String? get getSexuality {

    String? sexuality = get<String>(keySexuality);
    if(sexuality != null){
      return sexuality;
    } else {
      return "";
    }
  }
  set setSexuality(String sexuality) => set<String>(keySexuality, sexuality);

  String? get getRelationship {

    String? relationship = get<String>(keyRelationship);
    if(relationship != null){
      return relationship;
    } else {
      return "";
    }
  }
  set setRelationship(String relationship) => set<String>(keyRelationship, relationship);


  String? get getSecondaryPassword => get<String>(keySecondaryPassword);
  set setSecondaryPassword(String secondaryPassword) => set<String>(keySecondaryPassword, secondaryPassword);

  List<dynamic>? get getSexualOrientations {

    List<dynamic> sexualZero = [sexualityAskMe];

    List<dynamic>? sexualOrientation = get<List<dynamic>>(keySexualOrientations);
    if(sexualOrientation != null && sexualOrientation.isNotEmpty){
      return sexualOrientation;
    } else {
      return sexualZero;
    }
  }
  set setSexualOrientations(List<String> sexualOrientations) => set<List<String>>(keySexualOrientations, sexualOrientations);

  List<dynamic>? get getPassions {

    List<dynamic> passionsZero = ["none"];

    List<dynamic>? passions = get<List<dynamic>>(keyPassions);
    if(passions != null && passions.isNotEmpty){
      return passions;
    } else {
      return passionsZero;
    }
  }

  List<dynamic>? get getPassionsRealList {

    List<dynamic> passionsZero = [];

    List<dynamic>? passions = get<List<dynamic>>(keyPassions);
    if(passions != null && passions.isNotEmpty){
      return passions;
    } else {
      return passionsZero;
    }
  }
  set setPassions(List<String> passions) => set<List<String>>(keyPassions, passions);

  bool? get getShowSexualOrientation => get<bool>(keyShowSexualOrientationInProfile);
  set setShowSexualOrientation(bool showSexualOrientation) => set<bool>(keyShowSexualOrientationInProfile, showSexualOrientation);

  bool? get getShowGenderInProfile => get<bool>(keyShowGenderInProfile);
  set setShowGenderInProfile(bool showGenderInProfile) => set<bool>(keyShowGenderInProfile, showGenderInProfile);

  bool? get getDistanceInMiles {

    bool? distanceInMiles = get<bool>(keyDistanceInMiles);
    if(distanceInMiles != null){
      return distanceInMiles;
    } else {
      return false;
    }

  }
  set setDistanceInMiles(bool distanceInMiles) => set<bool>(keyDistanceInMiles, distanceInMiles);

  bool? get getHideMyLocation {

    bool? hideMyLocation = get<bool>(keyHideMyLocation);
    if(hideMyLocation != null){
      return hideMyLocation;
    } else {
      return false;
    }
  }
  set setHideMyLocation(bool hideMyLocation) => set<bool>(keyHideMyLocation, hideMyLocation);

  ParseGeoPoint? get getGeoPoint => get<ParseGeoPoint>(keyGeoPoint);
  set setGeoPoint(ParseGeoPoint geoPoint) => set<ParseGeoPoint>(keyGeoPoint, geoPoint);

  int? get getAge => get<int>(keyAge);
  set setAge(int age) => set<int>(keyAge, age);

  int? get getPoints {

    int? token = get<int>(keyPoints);
    if(token != null){
      return token;
    } else {
      return 0;
    }
  }
  set setPoints(int points) => setIncrement(keyPoints, points);
  int? get getCreditsSent => get<int>(keyCoinsSent);
  set removePoints(int points) => setDecrement(keyPoints, points);

  int? get getPointsTotal {

    int? token = get<int>(keyPointsTotal);
    if(token != null){
      return token;
    } else {
      return 0;
    }
  }
  set setPointsTotal(int pointsTotal) => setIncrement(keyPointsTotal, pointsTotal);

  int? get getPayouts {

    int? payout = get<int>(keyPayouts);
    if(payout != null){
      return payout;
    } else {
      return 0;
    }
  }
  set setPayouts(int incrementPayout) => setIncrement(keyPayouts, incrementPayout);


  List<dynamic>? get getFollowing{

    List<dynamic>? following = get<List>(keyFollowing);
    List<dynamic> followings = [];

    if(following != null && following.isNotEmpty){
      return following;
    } else {
      return followings;
    }
  }
  set setFollowing(String authorId) => setAddUnique(keyFollowing, authorId);
  set removeFollowing(String authorId) => setRemove(keyFollowing, authorId);

  List<dynamic>? get getFollowers{

    List<dynamic>? followers = get<List<dynamic>>(keyFollowers);
    if(followers != null && followers.isNotEmpty){
      return followers;
    } else {
      return [];
    }
  }
  set setFollowers(String authorId) => setAddUnique(keyFollowers, authorId);
  set removeFollowers(String authorId) => setRemove(keyFollowers, authorId);

  bool? get getReceiveChatRequest{
    bool? receiveChatRequest = get<bool>(keyReceiveChatRequest);
    if(receiveChatRequest != null){
      return receiveChatRequest;
    } else {
      return false;
    }
  }
  set setReceiveChatRequest(bool receiveChatRequest) => set<bool>(keyReceiveChatRequest, receiveChatRequest);

  bool? get getShowUpInSearch{
    bool? showUpInSearch = get<bool>(keyShowUpInSearch);
    if(showUpInSearch != null){
      return showUpInSearch;
    }else{
      return false;
    }

  }
  set setShowUpInSearch(bool showUpInSearch) => set<bool>(keyShowUpInSearch, showUpInSearch);

  bool? get getShowVipLevel {
    bool? showVipLevel = get<bool>(keyShowVipLevel);
    if(showVipLevel != null){
      return showVipLevel;
    }else{
      return false;
    }
  }
  set setShowVipLevel(bool showVipLevel) => set<bool>(keyShowVipLevel, showVipLevel);

  bool? get getShowLocation {
    bool? showLocation = get<bool>(keyShowLocation);
    if(showLocation != null){
      return showLocation;
    }else{
      return false;
    }
  }
  set setShowLocation(bool showLocation) => set<bool>(keyShowLocation, showLocation);

  bool? get getShowLastTimeSeen{
    bool? showLastTimeSeen = get<bool>(keyShowLastTimeSeen);
    if(showLastTimeSeen != null){
      return showLastTimeSeen;
    }else{
      return false;
    }
  }
  set setShowLastTimeSeen(bool showLastTimeSeen) => set<bool>(keyShowLastTimeSeen, showLastTimeSeen);

  bool? get getInvisibleMode {
    bool? invisibleMode = get<bool>(keyInvisibleMode);
    if(invisibleMode != null){
      return invisibleMode;
    }else{
      return false;
    }
  }
  set setInvisibleMode(bool invisibleMode) => set<bool>(keyInvisibleMode, invisibleMode);

  String? get getShowMyPostsTo {
    String? showMyPostsTo = get<String>(keyShowMyPostsTo);
    if(showMyPostsTo != null){
      return showMyPostsTo;
    }else{
      return anyUser;
    }
  }
  set setShowMyPostsTo(String showMyPostsTo) => set<String>(keyShowMyPostsTo, showMyPostsTo);

  set setSendReadReceipts(bool sendReadReceipts) => set<bool>(keySendReadReceipts, sendReadReceipts);

  bool? get getSendReadReceipts{
    bool? sendReadReceipts = get<bool>(keySendReadReceipts);
    if(sendReadReceipts != null){
      return sendReadReceipts;
    }else{
      return false;
    }
  }

  set setEnableOneClickGifting(bool enableOneClickGifting) => set<bool>(keyEnableOneClickGifting, enableOneClickGifting);

  bool? get getEnableOneClickGifting{
    bool? enableOneClickGifting = get<bool>(keyEnableOneClickGifting);
    if(enableOneClickGifting != null){
      return enableOneClickGifting;
    }else{
      return false;
    }
  }

  set setDenyBeInvitedToLiveParty(bool denyBeInvitedToLiveParty) => set<bool>(keyDenyBeInvitedToLiveParty, denyBeInvitedToLiveParty);

  bool? get getDenyBeInvitedToLiveParty{
    bool? denyBeInvitedToLiveParty = get<bool>(keyDenyBeInvitedToLiveParty);
    if(denyBeInvitedToLiveParty != null){
      return denyBeInvitedToLiveParty;
    }else{
      return false;
    }
  }

  set setDenyPictureInPictureMode(bool denyPictureInPictureMode) => set<bool>(keyDenyPictureInPictureMode, denyPictureInPictureMode);

  bool? get getDenyPictureInPictureMode{
    bool? denyPictureInPictureMode = get<bool>(keyDenyPictureInPictureMode);
    if(denyPictureInPictureMode != null){
      return denyPictureInPictureMode;
    }else{
      return false;
    }
  }

  set setAllowViewersToPremiumStream(bool allowViewersToPremiumStream) => set<bool>(keyAllowViewersToPremiumStream, allowViewersToPremiumStream);

  bool? get getAllowViewersToPremiumStream{
    bool? allowViewersToPremiumStream = get<bool>(keyAllowViewersToPremiumStream);
    if(allowViewersToPremiumStream != null){
      return allowViewersToPremiumStream;
    }else{
      return false;
    }
  }

  set setLiveNotification(bool liveNotification) => set<bool>(keyLiveNotification, liveNotification);

  bool? get getLiveNotification{
    bool? liveNotification = get<bool>(keyLiveNotification);
    if(liveNotification != null){
      return liveNotification;
    }else{
      return true;
    }
  }

  set setMuteIncomingCalls(bool muteIncomingCalls) => set<bool>(keyMuteIncomingCalls, muteIncomingCalls);

  bool? get getMuteIncomingCalls{
    bool? muteIncomingCalls = get<bool>(keyMuteIncomingCalls);
    if(muteIncomingCalls != null){
      return muteIncomingCalls;
    }else{
      return true;
    }
  }

  set setNotificationSounds(bool notificationSounds) => set<bool>(keyNotificationSounds, notificationSounds);

  bool? get getNotificationSounds{
    bool? notificationSounds = get<bool>(keyNotificationSounds);
    if(notificationSounds != null){
      return notificationSounds;
    }else{
      return true;
    }
  }

  set setInAppSound(bool inAppSound) => set<bool>(keyInAppSound, inAppSound);

  bool? get getInAppSound{
    bool? inAppSound = get<bool>(keyInAppSound);
    if(inAppSound != null){
      return inAppSound;
    }else{
      return true;
    }
  }


  set setInAppVibration(bool inAppVibration) => set<bool>(keyInAppVibration, inAppVibration);

  bool? get getInAppVibration{
    bool? inAppVibration = get<bool>(keyInAppVibration);
    if(inAppVibration != null){
      return inAppVibration;
    }else{
      return true;
    }
  }

  set setGameNotification(bool gameNotification) => set<bool>(keyGameNotification, gameNotification);

  bool? get getGameNotification{
    bool? gameNotification = get<bool>(keyGameNotification);
    if(gameNotification != null){
      return gameNotification;
    }else{
      return true;
    }
  }

  List<dynamic>? get getReportedPostIDs{

    List<dynamic>? postID = get<List<dynamic>>(keyReportedPostsIDs);
    if(postID != null){
      return postID;
    } else {
      return [];
    }
  }

  set setReportedPostIDs(dynamic postID) {
    List<dynamic> postIdArray = [];
    postIdArray.add(postID);
    setAddAllUnique(keyReportedPostsIDs, postIdArray);
  }

  String? get getReportedPostReason => get<String>(keyReportedPostReason);
  set setReportedPostReason(String reason) => set<String>(keyReportedPostReason, reason);

  String? get getPayEmail => get<String>(keyPayoneerEmail);
  set setPayEmail(String payEmail) => set<String>(keyPayoneerEmail, payEmail);

  String? get getPaypalEmail => get<String>(keyPaypalEmail);
  set setPaypalEmail(String payEmail) => set<String>(keyPaypalEmail, payEmail);

  String? get getIban => get<String>(keyIban);
  set setIban(String iban) => set<String>(keyIban, iban);

  String? get getAccountName => get<String>(keyAccountName);
  set setAccountName(String name) => set<String>(keyAccountName, name);

  String? get getBankName => get<String>(keyBankName);
  set setBankName(String bank) => set<String>(keyBankName, bank);

  dynamic get getInstallation => get(keyInstallation);
  set setInstallation(ParseInstallation installation) => set<ParseInstallation>(keyInstallation, installation);

  List? get getInvitedUsers{

    List? invited = get<List<dynamic>>(keyInvitedUsers);
    if(invited != null && invited.isNotEmpty){
      return invited;
    } else {
      return [];
    }
  }

  bool? get getInvitedByAnswer => get<bool>(keyInvitedAnswered);
  set setInvitedByAnswer(bool invitedAnswer) => set<bool>(keyInvitedAnswered, invitedAnswer);

  String? get getInvitedByUser => get<String>(keyInvitedByUser);
  set setInvitedByUser(String invitedBy) => set<String>(keyInvitedByUser, invitedBy);

  int? get getPointsAgency {

    int? token = get<int>(keyPointsAgency);
    if(token != null){
      return token;
    } else {
      return 0;
    }
  }
  set setPointsAgency(int points) => setIncrement(keyPointsAgency, points);
  set removePointsAgency(int points) => setDecrement(keyPointsAgency, points);

  int? get getPointsAgencyTotal {

    int? token = get<int>(keyPointsAgencyTotal);
    if(token != null){
      return token;
    } else {
      return 0;
    }
  }
  set setPointsAgencyTotal(int points) => setIncrement(keyPointsAgencyTotal, points);
  set removePointsAgencyTotal(int points) => setDecrement(keyPointsAgencyTotal, points);


  List<dynamic>? get getCategories{

    List<dynamic>? categories = get<List<dynamic>>(keyCategories);
    if(categories != null){
      return categories;
    } else {
      return [];
    }
  }
  set gstCategories(List<dynamic> category) => set<List<dynamic>>(keyCategories, category);

}