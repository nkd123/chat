// ignore_for_file: file_names

import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/models/UserModel.dart';

class LocalStoredMessages {
  String? name;
  ParseFileBase? userAvatar;
  String? lastMessage;
  DateTime? createdAt;
  UserModel? chatUser;
  int? unReadMessages;

  LocalStoredMessages({
    this.createdAt,
    this.chatUser,
    this.lastMessage,
    this.name,
    this.unReadMessages,
    this.userAvatar
  });

  toJSONEncode () {
    Map<String, dynamic> localMessage = {};
    localMessage["name"] = name;
    localMessage["UserAvatar"] = userAvatar;
    localMessage["lastMessage"] = lastMessage;
    localMessage["createdAt"] = createdAt;
    localMessage["chatUser"] = chatUser;
    localMessage["unReadMessages"] = unReadMessages;
  }
}

class LocalStoredListMessages {
  List<LocalStoredMessages> messages = [];

  toJSONEncode() {
    return messages.map((messages) {
      return messages.toJSONEncode();
    }).toList();
  }
}