// ignore_for_file: file_names

import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class CategoryModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Category";

  CategoryModel() : super(keyTableName);
  CategoryModel.clone() : this();

  @override
  CategoryModel clone(Map<String, dynamic> map) => CategoryModel.clone()..fromJson(map);


  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyName = "name";
  static String keyImage = "image";
  static String keyCode = "code";

  String? get getName => get<String>(keyName);
  set setName(String name) => set<String>(keyName, name);

  ParseFileBase? get getImage => get<ParseFileBase>(keyImage);
  set setImage(ParseFileBase image) => set<ParseFileBase>(keyImage, image);

  String? get getCode => get<String>(keyCode);
  set setCode(String code) => set<String>(keyCode, code);

}