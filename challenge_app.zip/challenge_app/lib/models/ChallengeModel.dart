// ignore_for_file: file_names
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/models/VideoModel.dart';

class ChallengeModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Challenge";

  ChallengeModel() : super(keyTableName);
  ChallengeModel.clone() : this();

  @override
  ChallengeModel clone(Map<String, dynamic> map) => ChallengeModel.clone()..fromJson(map);

  // Challenge Modes
  // static const modePOLL = "POL";
  static const mode1VS1 = "_1V1";
  static const modeLIVESTREAMING = "LIV";
  static const modeAUDIOROOM = "ADR";
  /*static const modeSINGLE = "SIG";
  static const modeGROUP = "GRP";
  static const modeTORNEO = "TRN";*/

  // Challenge Rewards
  static const rewardCHALLENGECOIN = "CLC";
  static const rewardGOLDENCOIN = "GLC";
  static const rewardSKIN = "SKN";
  static const rewardBOOSTER = "BST";
  static const rewardACCESSORIES = "ACR";
  static const rewardCRYPTO = "CRT";

  // challenge Category
  static const categoryDance = "DNC";
  static const categoryART = "ART";
  static const categoryJOKES = "JKS";
  static const categorySPORT = "SPT";
  static const categoryLOGIC = "LGC";
  static const categoryFUN = "FUN";
  static const categoryCOOK = "COK";
  static const categorySING = "SNG";
  static const categoryINVENTIVE = "INV";
  static const categoryFAMILY = "FAM";
  static const categorySNERVATING = "SNR";
  static const categoryPENANCE = "PEN";

  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyAuthor = "author";
  static String keyAuthorId = "authorId";

  static String keyChallenger = "challenger";
  static String keyChallengerId = "challengerId";

  static String keyAuthorVideo = "authorVideo";
  static String keyAuthorVideoId = "authorVideoId";

  static String keyChallengerVideo = "challengerVideo";
  static String keyChallengerVideoId = "challengerVideoId";

  static String keyLiveStreaming = "liveStreaming";
  static String keyLiveStreamingId = "liveStreamingId";

  static String keyCategory = "category";
  static String keyCategoryId = "categoryId";

  static String keyMode = "Mode";
  static String keyReward = "Reward";
  static String keyRound = "Rounds";
  static String keyPoint = "Point";

  static String keyExpiration = "expiration_date";
  static String keyDuration = "duration";

  static String keyRePropose = "re_proposes";
  static String keyWinner = "winner";

  static String keySelection = "selections";
  static String keyAuthorSelection = "authorSelection";
  static String keyChallengerSelection = "challengerSelection";

  static String keyInviteAccepted = "accepted";

  bool? get getInvitation => get<bool>(keyInviteAccepted);
  set setInvitation(bool accepted) => set<bool>(keyInviteAccepted, accepted);

  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  UserModel? get getChallenger => get<UserModel>(keyChallenger);
  set setChallenger(UserModel challenger) => set<UserModel>(keyChallenger, challenger);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  String? get getChallengerId => get<String>(keyChallengerId);
  set setChallengerId(String challengerId) => set<String>(keyChallengerId, challengerId);

  String? get getMode => get<String>(keyMode);
  set setMode(String challengeMode) => set<String>(keyMode, challengeMode);

  String? get getReward => get<String>(keyReward);
  set setReward(String challengeReward) => set<String>(keyReward, challengeReward);

  int? get getRound => get<int>(keyRound);
  set setRound(int challengeRound) => set<int>(keyRound, challengeRound);

  int? get getPoint => get<int>(keyPoint);
  set setPoint(int point) => set<int>(keyPoint, point);

  String? get getCategory => get<String>(keyCategory);
  set setCategory(String category) => set<String>(keyCategory, category);

  String? get getCategoryId => get<String>(keyCategoryId);
  set setCategoryId(String challengeCategory) => set<String>(keyCategoryId, challengeCategory);

  int? get getDuration => get<int>(keyDuration);
  set setDuration(int duration) => set<int>(keyDuration, duration);

  List<dynamic>? get getRePropose{

    List<dynamic> rePropose = [];

    List<dynamic>? reProposeList = get<List<dynamic>>(keyRePropose);
    if(reProposeList != null && reProposeList.isNotEmpty){
      return reProposeList;
    } else {
      return rePropose;
    }
  }
  set setRePropose(String reProposeAuthorId) => setAddUnique(keyRePropose, reProposeAuthorId);
  set removeRePropose(String reProposeAuthorId) => setRemove(keyRePropose, reProposeAuthorId);

  UserModel? get getWinner => get<UserModel>(keyWinner);
  set setWinner(UserModel winner) => set<UserModel>(keyWinner, winner);

  VideoModel? get getAuthorVideo => get<VideoModel>(keyAuthorVideo);
  set setAuthorVideo(VideoModel video) => set<VideoModel>(keyAuthorVideo, video);

  String? get getAuthorVideoId => get<String>(keyAuthorVideoId);
  set setAuthorVideoId(String authorVideoId) => set<String>(keyAuthorVideoId, authorVideoId);

  VideoModel? get getChallengerVideo => get<VideoModel>(keyChallengerVideo);
  set setChallengerVideo(VideoModel video) => set<VideoModel>(keyChallengerVideo, video);

  String? get getChallengerVideoId => get<String>(keyChallengerVideoId);
  set setChallengerVideoId(String challengerVideoId) => set<String>(keyChallengerVideoId, challengerVideoId);

  LiveStreamingModel? get getLiveStreaming => get<LiveStreamingModel>(keyLiveStreaming);
  set setLiveStreaming (LiveStreamingModel liveStreaming) => set<LiveStreamingModel>(keyLiveStreaming, liveStreaming);

  String? get getLiveStreamingId => get<String>(keyLiveStreamingId);
  set setLiveStreamingId(String liveStreamingId) => set<String>(keyLiveStreamingId, liveStreamingId);

  DateTime? get getExpireDate => get<DateTime>(keyExpiration);
  set setExpireDate(DateTime expireDate) => set<DateTime>(keyExpiration, expireDate);

  List<dynamic> get getSelection{

    List<dynamic> selections = [];

    List? selectionList = get<List<dynamic>>(keySelection);
    if(selectionList != null && selectionList.isNotEmpty){
      return selectionList;
    } else {
      return selections;
    }
  }
  set setSelection(String userId) => setAddUnique(keySelection, userId);
  set removeSelection(String userId) => setRemove(keySelection, userId);

  int? get getAuthorSelection => get<int>(keyAuthorSelection);
  set setAuthorSelection(int selection) => set<int>(keyAuthorSelection, selection);

  int? get getChallengeSelection => get<int>(keyChallengerSelection);
  set setChallengeSelection(int selection) => set<int>(keyChallengerSelection, selection);
}