// ignore_for_file: file_names

import 'package:challenge/models/CallsModel.dart';
import 'package:challenge/models/GroupMessageModel.dart';
import 'package:challenge/models/MessageListModel.dart';
import 'package:challenge/models/StoriesModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

class MessageModel extends ParseObject implements ParseCloneable {

  static const String keyTableName = "Message";

  MessageModel() : super(keyTableName);
  MessageModel.clone() : this();

  @override
  MessageModel clone(Map<String, dynamic> map) => MessageModel.clone()..fromJson(map);

  static String messageTypeText = "text";
  static String messageTypeGif = "gif";
  static String messageTypePicture = "picture";
  static String messageTypeCall = "call";
  static String messageStoryReply = "storyReply";
  static String messageGroupNotify = "groupNotify";
  static String textMessageForGroup = "textMessageForGroup";
  static String pictureMessageForGroup = "pictureMessageForGroup";

  static String keyCreatedAt = "createdAt";
  static String keyObjectId = "objectId";

  static String keyAuthor = "Author";
  static String keyAuthorId = "AuthorId";

  static String keyReceiver = "Receiver";
  static String keyReceiverId = "ReceiverId";

  static String keyGroupReceiver = "GroupReceiver";
  static String keyGroupReceiverId = "GroupReceiverId";

  static const String keyText = "text";
  static const String keyMessageFile = "messageFile";
  static const String keyIsMessageFile = "isMessageFile";

  static const String keyRead = "read";

  static const String keyListMessage = "messageList";
  static const String keyListMessageId = "messageListId";

  static const String keyGifMessage = "gifMessage";
  static const String keyPictureMessage = "pictureMessage";

  static const String keyMessageType = "messageType";

  static const String keyCall = "call";

  static const String keyStoryReplied = "storyReplied";

  static String keyMembersIDs = "membersIDs";

  List<dynamic>? get getMembersIDs{

    List<dynamic> members = [];

    List<dynamic>? membersIDs = get<List<dynamic>>(keyMembersIDs);
    if(membersIDs != null && membersIDs.isNotEmpty){
      return membersIDs;
    } else {
      return members;
    }
  }
  set setMemberID(String memberId) => setAddUnique(keyMembersIDs, memberId);
  set setMemberIDs(List<dynamic> memberIDs) => setAddAll(keyMembersIDs, memberIDs);
  set removeMemberID(String memberId) => setRemove(keyMembersIDs, memberId);

  MessageGroupModel? get getGroupReceiver => get<MessageGroupModel>(keyGroupReceiver);
  set setGroupReceiver(MessageGroupModel groupReceiver) => set<MessageGroupModel>(keyGroupReceiver, groupReceiver);

  String? get getGroupReceiverId => get<String>(keyGroupReceiverId);
  set setGroupReceiverId(String groupId) => set<String>(keyGroupReceiverId, groupId);


  UserModel? get getAuthor => get<UserModel>(keyAuthor);
  set setAuthor(UserModel author) => set<UserModel>(keyAuthor, author);

  String? get getAuthorId => get<String>(keyAuthorId);
  set setAuthorId(String authorId) => set<String>(keyAuthorId, authorId);

  UserModel? get getReceiver => get<UserModel>(keyReceiver);
  set setReceiver(UserModel author) => set<UserModel>(keyReceiver, author);

  String? get getReceiverId => get<String>(keyReceiverId);
  set setReceiverId(String authorId) => set<String>(keyReceiverId, authorId);

  String? get getMessageText => get<String>(keyText);
  set setMessageText(String message) => set<String>(keyText, message);

  ParseFileBase? get getMessageFile => get<ParseFileBase>(keyMessageFile);
  set setMessageFile(ParseFileBase messageFile) => set<ParseFileBase>(keyMessageFile, messageFile);

  bool? get isMessageFile => get<bool>(keyMessageFile);
  set setIsMessageFile(bool isMessageFile) => set<bool>(keyMessageFile, isMessageFile);

  bool? get isRead => get<bool>(keyRead);
  set setIsRead(bool isRead) => set<bool>(keyRead, isRead);

  MessageListModel? get getMessageList => get<MessageListModel>(keyListMessage);
  set setMessageList(MessageListModel messageListModel) => set<MessageListModel>(keyListMessage, messageListModel);

  String? get getMessageListId => get<String>(keyListMessageId);
  set setMessageListId(String messageListId) => set<String>(keyListMessageId, messageListId);

  ParseFileBase? get getGifMessage => get<ParseFileBase>(keyGifMessage);
  set setGifMessage(ParseFileBase gifMessage) => set<ParseFileBase>(keyGifMessage, gifMessage);

  StoriesModel? get getStoryReplied => get<StoriesModel>(keyStoryReplied);
  set setStoryReplied(StoriesModel storyReplied) => set<StoriesModel>(keyStoryReplied, storyReplied);

  String? get getMessageType => get<String>(keyMessageType);
  set setMessageType(String messageType) => set<String>(keyMessageType, messageType);

  ParseFileBase? get getPictureMessage => get<ParseFileBase>(keyPictureMessage);
  set setPictureMessage(ParseFileBase pictureMessage) => set<ParseFileBase>(keyPictureMessage, pictureMessage);

  CallsModel? get getCall => get<CallsModel>(keyCall);
  set setCall(CallsModel call) => set<CallsModel>(keyCall, call);

}