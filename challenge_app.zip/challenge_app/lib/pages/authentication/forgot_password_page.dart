// ignore_for_file: deprecated_member_use, library_private_types_in_public_api, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../../configurations/global_config.dart';
import '../../configurations/global_setup.dart';
import '../../models/UserModel.dart';
import '../../utilities/helper_classes/cloud_helper.dart';
import '../../widgets/custom_widgets/container_with_corner.dart';
import '../../widgets/custom_widgets/text_with_tap.dart';

class ForgotPasswordPage extends StatefulWidget {
  static const String route = '/forgot';

  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  _ForgotPasswordPageState createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  get size => MediaQuery.of(context).size;
  final TextEditingController _emailEditingController = TextEditingController();
  final TextEditingController _passwordEditingController = TextEditingController();
  final TextEditingController _pinCodeController = TextEditingController();
  StreamController<ErrorAnimationType>? errorController;
  bool hasError = false;

  int _pageIndex = 0;

  String _pinCode = "";
  bool _resend = false;
  UserModel? _user;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _emailEditingController.dispose();
    _passwordEditingController.dispose();
    _pinCodeController.dispose();
    super.dispose();
  }

  _validateEmail(String value){

    if(value.trim().isEmpty){
      MainHelper.showAppNotificationAdvanced(
        context: context,
        message: "auth.no_email_account".tr(),
        title: "error".tr(),
      );
    } else if(!MainHelper.isValidEmail(value.trim())){
      MainHelper.showAppNotificationAdvanced(
        context: context,
        message: "auth.invalid_email".tr(),
        title: "error".tr(),
      );
    } else {
      _sendCodeToEmail(value.trim());
    }

  }

  _showMessage(String title, String message, bool isError){
    MainHelper.showAppNotificationAdvanced(
        title: title,
        message: message,
        isError: isError,
        context: context
    );
  }

  Future<void> showSuccess() async {
    MainHelper.hideLoadingDialog(context);

    MainHelper.showAppNotificationAdvanced(context: context,
        title: "auth.forgot_sent".tr(),
        message: "auth.email_explain".tr(), isError: false);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: IndexedStack(
          index: _pageIndex,
          children: [
            _emailForm(),
            _pinCodeFormPage(),
            _passwordForm(),
          ],
        ),
    );
  }

  _moveToPage(int index){
    setState(() {
      _pageIndex = index;
    });
  }

  Widget _formPage({Widget? body}){
    return Scaffold(
      backgroundColor:
      MainHelper.isDarkMode(context) ? kWelcomeDarkMode : Colors.white,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          ContainerCorner(
            height: size.height,
            width: size.width,
            child:body!,
          ),
        ],
      ),
    );
  }

  // -- Email form ----
  Widget _emailForm(){
    return _formPage(
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            height: size.height,
            width: size.width,
            color: Colors.black.withOpacity(0.4),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextWithTap(
                  "forgot_password".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 15,
                  fontWeight: FontWeight.w900,
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/btn_design.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 7,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Center(
                      child: TextField(
                        autocorrect: false,
                        keyboardType: TextInputType.emailAddress,
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        controller: _emailEditingController,
                        style: const TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          hintText: "email_".tr().toLowerCase(),
                          hintStyle: GoogleFonts.azeretMono(
                              color: Colors.white,
                              fontSize: size.width / 20),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/white_btn.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 9,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  onTap: () {
                    _validateEmail(_emailEditingController.text.trim());
                  },
                  child: Center(
                    child: TextWithTap(
                      "send_code".tr().toUpperCase(),
                      color: kPrimaryColor,
                      fontWeight: FontWeight.w900,
                      fontSize: size.width / 20,
                    ),
                  ),
                ),
                TextWithTap(
                  "auth.return_login".tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 10,
                  onTap: () => MainHelper.goToNavigatorScreen(
                      context, const SignInPage()),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ------ Phone validate code form page ----------
  Widget _pinCodeFormPage() {
    return _formPage(
      body:  Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            height: size.height,
            width: size.width,
            color: Colors.black.withOpacity(0.4),
            child:Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextWithTap(
                  "verify_code".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 15,
                  fontWeight: FontWeight.w900,
                  marginBottom: 20,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal:25),
                  child: PinCodeTextField(
                    appContext: context,
                    length: Setup.verificationCodeDigits,
                    keyboardType: TextInputType.number,
                    obscureText: false,
                    animationType: AnimationType.fade,
                    autoFocus: false,
                    cursorColor: kPrimaryColor,
                    cursorHeight: 17,
                    textStyle: const TextStyle(
                      color: kPrimaryColor,
                    ),
                    pinTheme: PinTheme(
                      borderWidth: 2.0,
                      shape: PinCodeFieldShape.underline,
                      borderRadius: BorderRadius.zero,
                      fieldHeight: 40,
                      fieldWidth: 45,
                      activeFillColor: Colors.transparent,
                      inactiveFillColor: Colors.transparent,
                      selectedFillColor: Colors.transparent,
                      activeColor: kPrimaryColor,
                      inactiveColor: Colors.white,
                      selectedColor: kPrimaryColor,
                    ),
                    animationDuration: const Duration(milliseconds: 300),
                    backgroundColor: Colors.transparent,
                    enableActiveFill: true,
                    errorAnimationController: errorController,
                    controller: _pinCodeController,
                    autovalidateMode: AutovalidateMode.always,
                    validator: (value) {
                      return null;
                    },
                    useHapticFeedback: true,
                    hapticFeedbackTypes: HapticFeedbackTypes.selection,
                    onChanged: (value) {
                      setState(() {
                        if (value.length == Setup.verificationCodeDigits) {
                          //_isCodeEntered = true;
                        } else {
                          //_isCodeEntered = false;
                        }
                      });
                    },
                    onCompleted: (v) {
                      MainHelper.showLoadingDialog(context);
                      _pinCode = v;
                      _verifyCodeFromEmail(_pinCode);
                    },
                    beforeTextPaste: (text) {
                      //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                      //but you can show anything you want here, like your pop up saying wrong paste format or etc
                      return true;
                    },
                  ),
                ),
                TextWithTap(
                  'resent_code'.tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 15,
                  onTap: () {
                    // resend code method is called here
                    _sendCodeToEmail(_emailEditingController.text.trim());
                    _resend = true;
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // -- Password form ----
  Widget _passwordForm(){
    return _formPage(
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            height: size.height,
            width: size.width,
            color: Colors.black.withOpacity(0.4),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextWithTap(
                  "reset_password".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 15,
                  fontWeight: FontWeight.w900,
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/btn_design.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 7,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Center(
                      child: TextField(
                        autocorrect: false,
                        keyboardType: TextInputType.text,
                        obscureText: true,
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        controller: _passwordEditingController,
                        style: const TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          hintText: "new_password".tr().toLowerCase(),
                          hintStyle: GoogleFonts.azeretMono(
                              color: Colors.white,
                              fontSize: size.width / 20),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/white_btn.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 9,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  onTap: () {
                    _resetPassword();
                  },
                  child: Center(
                    child: TextWithTap(
                      "reset.reset_password".tr().toUpperCase(),
                      color: kPrimaryColor,
                      fontWeight: FontWeight.w900,
                      fontSize: size.width / 20,
                    ),
                  ),
                ),
                TextWithTap(
                  "auth.return_login".tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 10,
                  onTap: () => MainHelper.goToNavigatorScreen(
                      context, const SignInPage()),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // ----------- Email verification method ------------------------
  Future<void> _sendCodeToEmail(String emailAddress) async {
    MainHelper.showLoadingDialog(context);

    QueryBuilder<UserModel> query =
    QueryBuilder<UserModel>(UserModel.forQuery());
    query.whereEqualTo(UserModel.keyEmail, emailAddress);

    ParseResponse response = await query.query();

    if (response.success && response.results == null) {
      MainHelper.hideLoadingDialog(context);
      _showMessage('reset.unknown_email_title'.tr(),
          'reset.unknown_email_message'.tr(), true);
    } else {
      _user = response.results!.first as UserModel;
      ParseResponse parseResponse;

      parseResponse = await CloudCodeHelper.sendCodeToEmail(
          user: _user!,
          from: Config.appEmailAddress,
          to: _emailEditingController.text.trim(),
          appName: Config.appName,
          apiKey: Config.senderGridApiKey
      );

      if(parseResponse.success){
        MainHelper.hideLoadingDialog(context);

        if(parseResponse.result != null && parseResponse.result){
          // After the code is sent execute the lines bellow
          MainHelper.removeFocusOnTextField(context);
          _pinCodeController.text = "";

          if(!_resend){
            _moveToPage(1);
          }else{
            _resend = false;
          }

        }else{
          _showMessage("error".tr(), "try_again_later".tr(), true);
        }

      }else{
        MainHelper.hideLoadingDialog(context);
        _showMessage("error".tr(), "try_again_later".tr(), true);
      }
    }

  }

  Future<void> _verifyCodeFromEmail(String pinCode) async {
    ParseResponse parseResponse;

    parseResponse = await CloudCodeHelper.verifyCodeFromEmail(
      user: _user!,
      code: pinCode,
    );

    if(parseResponse.success){
      MainHelper.hideLoadingDialog(context);

      if(parseResponse.result != null && parseResponse.result){
        _moveToPage(2);
      }else{
        _pinCodeController.text = "";
        _showMessage("error".tr(), "auth.invalid_code".tr(), true);
      }

    }else{
      MainHelper.hideLoadingDialog(context);
      _showMessage("error".tr(), "try_again_later".tr(), true);
    }
  }


  // ---------- Reset Password Methods --------------
  Future<void> _resetPassword() async {
    MainHelper.showLoadingDialog(context);

    ParseResponse parseResponse;

    parseResponse = await CloudCodeHelper.resetUserPassword(
      user: _user!,
      password: _passwordEditingController.text.trim(),
    );

    if(parseResponse.success){
      MainHelper.hideLoadingDialog(context);

      MainHelper.showAppNotificationAdvanced(
          context: context,
          isError: false,
          title: "reset.password_updated_title".tr(),
          message: "reset.password_updated_message".tr());

      _emailEditingController.text = '';

      _moveToPage(0);
    }else{
      MainHelper.hideLoadingDialog(context);
      _showMessage("error".tr(), "try_again_later".tr(), true);
    }
  }
}
