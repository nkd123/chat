// ignore_for_file: close_sinks, prefer_function_declarations_over_variables, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:google_fonts/google_fonts.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:challenge/pages/authentication/signup_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/main_utilities/challenge_exeption.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../services/analytics_service.dart';
import '../../utilities/main_utilities/shared_manager.dart';
import '../../widgets/custom_widgets/text_with_tap.dart';
import '../global/global_loading_page.dart';
import 'forgot_password_page.dart';

class SignInPage extends StatefulWidget {
  const SignInPage({Key? key}) : super(key: key);

  static const String route = '/welcome';

  @override
  // ignore: library_private_types_in_public_api
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final Future<SharedPreferences> prefs = SharedPreferences.getInstance();

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  StreamController<ErrorAnimationType>? errorController;
  bool hasError = false;

  int position = 0;

  @override
  void initState() {
    errorController = StreamController<ErrorAnimationType>();
    super.initState();
  }

  @override
  void dispose() {
    errorController!.close();
    super.dispose();
  }

  Future<void> showSuccess() async {
    MainHelper.hideLoadingDialog(context);

    UserModel? currentUser = await ParseUser.currentUser();
    if (currentUser != null) {
      MainHelper.goToNavigatorScreen(
          context,
          GlobalLoadingPage(
            currentUser: currentUser,
          ),
          finish: true,
          back: false);
    }
  }

  void showError(int error) {
    MainHelper.hideLoadingDialog(context);

    if (error == ChallengeException.connectionFailed) {
      MainHelper.showAppNotificationAdvanced(
          context: context, title: "error".tr(), message: "not_connected".tr());
    } else if (error == ChallengeException.accountBlocked) {
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "auth.account_blocked".tr());
    } else if (error == ChallengeException.accountDeleted) {
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "auth.account_deleted".tr());
    } else {
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "auth.invalid_credentials".tr());
    }
  }

  @override
  Widget build(BuildContext context) {
    MainHelper.setWebPageTitle(context, "page_title.welcome_title".tr());
    var size = MediaQuery.of(context).size;

    return GestureDetector(
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: Scaffold(
          backgroundColor:
              MainHelper.isDarkMode(context) ? kWelcomeDarkMode : Colors.white,
          resizeToAvoidBottomInset: false,
          body: Stack(
            children: [
              ContainerCorner(
                borderWidth: 0,
                color: kTransparentColor,
                width: size.width,
                height: size.height,
                imageDecoration: "assets/images/app_bg.png",
              ),
              ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                  child: ContainerCorner(
                    width: size.width,
                    height: size.height,
                  ),
                ),
              ),
              ContainerCorner(
                height: size.height,
                width: size.width,
                child: Stack(
                  children: [
                    ContainerCorner(
                      borderWidth: 0,
                      height: size.height,
                      width: size.width,
                      color: Colors.black.withOpacity(0.4),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextWithTap(
                            "registration_".tr().toUpperCase(),
                            color: Colors.white,
                            fontSize: size.width / 15,
                            fontWeight: FontWeight.w900,
                          ),
                          ContainerCorner(
                            radiusBottomRight: 20,
                            borderWidth: 2,
                            imageDecoration: "assets/images/btn_design.png",
                            radiusTopLeft: 20,
                            marginTop: size.width / 15,
                            height: size.width / 7,
                            marginLeft: size.width / 10,
                            marginRight: size.width / 10,
                            width: size.width,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: Center(
                                child: TextField(
                                  autocorrect: false,
                                  keyboardType: TextInputType.emailAddress,
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  controller: emailController,
                                  style: const TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                    hintText: "email_".tr().toLowerCase(),
                                    hintStyle: GoogleFonts.azeretMono(
                                        color: Colors.white,
                                        fontSize: size.width / 20),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          ContainerCorner(
                            radiusBottomRight: 20,
                            borderWidth: 2,
                            imageDecoration: "assets/images/btn_design.png",
                            radiusTopLeft: 20,
                            marginTop: size.width / 30,
                            height: size.width / 7,
                            marginLeft: size.width / 10,
                            marginRight: size.width / 10,
                            width: size.width,
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: Center(
                                child: TextField(
                                  autocorrect: false,
                                  obscureText: true,
                                  keyboardType: TextInputType.visiblePassword,
                                  maxLines: 1,
                                  textAlign: TextAlign.center,
                                  controller: passwordController,
                                  style: const TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                    hintText: "password_".tr().toLowerCase(),
                                    hintStyle: GoogleFonts.azeretMono(
                                        color: Colors.white,
                                        fontSize: size.width / 20),
                                    border: InputBorder.none,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          ContainerCorner(
                            radiusBottomRight: 20,
                            borderWidth: 2,
                            imageDecoration: "assets/images/white_btn.png",
                            radiusTopLeft: 20,
                            marginTop: size.width / 15,
                            height: size.width / 9,
                            marginLeft: size.width / 10,
                            marginRight: size.width / 10,
                            width: size.width,
                            onTap: () {
                              if (emailController.text.isEmpty ||
                                  passwordController.text.isEmpty) {
                                MainHelper.showAppNotificationAdvanced(
                                  title: "auth.empty_fields_title".tr(),
                                  message: "auth.empty_fields_explain".tr(),
                                  context: context,
                                  isError: true,
                                );
                              } else {
                                _login(passwordController.text);
                              }
                            },
                            child: Center(
                              child: TextWithTap(
                                "login_".tr().toUpperCase(),
                                color: kPrimaryColor,
                                fontWeight: FontWeight.w900,
                                fontSize: size.width / 20,
                              ),
                            ),
                          ),
                          TextWithTap(
                            "auth.forgot_password".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            marginTop: size.width / 20,
                            onTap: () => MainHelper.goToNavigatorScreen(
                                context, const ForgotPasswordPage()),
                          ),
                          TextWithTap(
                            "auth.dont_you_have".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            marginTop: size.width / 10,
                            onTap: () => MainHelper.goToNavigatorScreen(
                                context, const SignUpPage()),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Padding(
                              padding: const EdgeInsets.all(40.0),
                              child: Wrap(
                                alignment: WrapAlignment.center,
                                runSpacing: 0,
                                spacing: 0,
                                children: [
                                  TextWithTap(
                                    "agree_with".tr(),
                                    color: Colors.white,
                                    fontSize: 12.5,
                                  ),
                                  TextWithTap(
                                      "policy".tr(),
                                      color: kPrimaryColor,
                                      fontSize: 12.5,
                                      onTap: () => MainHelper.goToWebPage(context,
                                          pageType: MainHelper.pageTypePrivacy),
                                  ),
                                  TextWithTap(
                                      "and".tr(),
                                      color: Colors.white,
                                      fontSize: 12.5,
                                  ),
                                  TextWithTap(
                                      "terms".tr(),
                                      color: kPrimaryColor,
                                      fontSize: 12.5,
                                      onTap: () => MainHelper.goToWebPage(context,
                                          pageType: MainHelper.pageTypeTerms)
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  _login(String password) async {
    MainHelper.showLoadingDialog(context);

    QueryBuilder<UserModel> queryBuilder =
        QueryBuilder<UserModel>(UserModel.forQuery());
    queryBuilder.whereEqualTo(UserModel.keyEmail, emailController.text);

    ParseResponse response0 = await queryBuilder.query();

    if (response0.success) {
      if (response0.results != null) {
        final user = ParseUser(
            emailController.text, password, null);
        var response = await user.login();
        // response0.results!.first[UserModel.keyUsername]

        if (response.success) {
          MainHelper.hideLoadingDialog(context);
          UserModel? currentUser = await ParseUser.currentUser();

          // updates current installation's user
          prefs.then((SharedPreferences sharedPreferences) {
            MainHelper.initInstallation(currentUser, SharedManager.getDeviceToken(sharedPreferences));
          });

          Analytics analytics = Analytics();
          analytics.seTUserId(currentUser!);
          analytics.newLogginEvent('Email/password');

          MainHelper.goToNavigatorScreen(
              context,
              GlobalLoadingPage(
                currentUser: currentUser,
              ),
              back: false,
              finish: true);
        } else {
          MainHelper.hideLoadingDialog(context);

          MainHelper.showAppNotificationAdvanced(
              isError: true,
              context: context,
              title: "phone_login.login_error_title".tr(),
              message: "phone_login.login_error_explain".tr());
        }
      } else {
        MainHelper.hideLoadingDialog(context);
        MainHelper.showAppNotificationAdvanced(
            isError: true,
            context: context,
            title: "phone_login.login_error_title".tr(),
            message: "phone_login.login_error_explain".tr());
      }
    }
  }
}
