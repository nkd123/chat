import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/material.dart';

class GlobalLoadingPage extends StatefulWidget {
  static String route = "/check";

  final UserModel? currentUser;

  const GlobalLoadingPage({Key? key, this.currentUser}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _GlobalLoadingPageState createState() => _GlobalLoadingPageState();
}

class _GlobalLoadingPageState extends State<GlobalLoadingPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<UserModel?>(
          future: MainHelper.getUser(widget.currentUser),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              return HomePage(
                currentUser: widget.currentUser,
              );
            } else if (snapshot.hasError) {
              return const SignInPage();
            } else {
              return MainHelper.appLoadingLogo();
            }
          }),
    );
  }
}
