// ignore_for_file: use_build_context_synchronously

import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_polygon_clipper/flutter_polygon_clipper.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/notifications_pages/notifications_page.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:challenge/pages/home/search_pages/search_user_challenge_page.dart';
import 'package:challenge/pages/home/stories_page/see_stories_page.dart';
import 'package:challenge/pages/home/stories_page/story_type_chooser_page.dart';
import 'package:challenge/pages/home/video_pages/watch_video_page.dart';
import 'package:challenge/models/StoriesAuthorsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../models/NotificationsModel.dart';
import '../../../models/ReportModel.dart';
import '../../../widgets/custom_widgets/button_with_icon.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../../../widgets/custome_drawer.dart';
import '../home_page.dart';

// This is the type used by the popup menu below.
enum Items { report, block }

class FriendsVideoPage extends StatefulWidget {
  static const String route = "/Video/Friends";
  final UserModel? currentUser;

  const FriendsVideoPage({Key? key, this.currentUser}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _FriendsVideoPageState createState() => _FriendsVideoPageState();
}

class _FriendsVideoPageState extends State<FriendsVideoPage> {
  get size => MediaQuery.of(context).size;
  Items? selectedMenu;

  int notifications = 0;
  LiveQuery liveQuery = LiveQuery();
  Subscription? subscription;
  // AnimationController? _animationController;

  @override
  void initState() {
    // _animationController = AnimationController.unbounded(vsync: this);
    _getAllAuthors();
    super.initState();

    checkUserNotifications();
    setupControlLiveQuery();
  }

  @override
  void dispose() {
    super.dispose();
  }

  checkUserNotifications() async {
    QueryBuilder<NotificationsModel> query = QueryBuilder<NotificationsModel>(NotificationsModel());
    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(NotificationsModel.keyRead, false);
    query.whereEqualTo(NotificationsModel.keyReceiverId, widget.currentUser!.objectId);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        setState((){
          notifications = parseResponse.results!.length;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      endDrawer: CustomDrawer(currentUser: widget.currentUser),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: kTransparentColor,
        leading: ContainerCorner(
          onTap: () {
            MainHelper.goToNavigatorScreen(
              context,
              ProfilePage(
                currentUser: widget.currentUser!,
              ),
              back: true,
            );
          },
          width: size.width / 30,
          height: size.width / 30,
          child: Padding(
            padding: const EdgeInsets.only(left: 8.0, top: 4.5, bottom: 4.5),
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:widget.currentUser!,
                fontSize: 13),
          ),
        ),
        titleSpacing: 2.0,
        title: TextWithTap(
          widget.currentUser!.getUsername!,
          fontSize: 13,
          color: kContentColorDarkTheme,
        ),
        actions: [
          Stack(
            children: [
              IconButton(
                onPressed: (){
                  MainHelper.goToNavigatorScreen(
                      context,
                      SearchPage(
                        currentUser: widget.currentUser,
                      ));
                },
                icon: SvgPicture.asset('assets/svg/ic_app_search.svg',
                  color: Colors.white,
                ),
              ),
            ],
          ),
          Stack(
            children: [
              IconButton(
                onPressed: (){
                  MainHelper.goToNavigatorScreen(
                    context,
                    NotificationsPage(currentUser: widget.currentUser!),
                  );
                },
                icon: SvgPicture.asset('assets/svg/ic_notifications.svg',
                  width: 22,
                  height: 22,
                  color:Colors.white,
                ),
              ),
              Visibility(
                visible: notifications != 0,
                child: const Positioned(
                    top: 11,
                    right: 13,
                    child: ContainerCorner(
                      width: 9.5,
                      height: 9.5,
                      borderRadius: 50,
                      color: Colors.red,
                    )),
              ),
            ],
          ),
          Builder(builder: (ctx) {
            return ContainerCorner(
              onTap: () => Scaffold.of(ctx).openEndDrawer(),
              imageDecoration: "assets/images/top_btn.png",
              width: size.width / 7,
              height: size.height / 5,
            );
          }),
        ],
      ),
      body: getBody(),
    );
  }

  Widget getBody() {
    return ContainerCorner(
      borderWidth: 0,
      height: size.height,
      width: size.width,
      imageDecoration: "assets/images/app_bg.png",
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _getAllStories(),
              Flexible(
                fit: FlexFit.loose,
                child: _getAllVideosFromFriends(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<StoriesAuthorsModel> authorsList = [];
  int startIndex = 0;

  _getAllAuthors() async {
    QueryBuilder<StoriesAuthorsModel> query =
        QueryBuilder<StoriesAuthorsModel>(StoriesAuthorsModel());

    query.includeObject([
      StoriesAuthorsModel.keyAuthor,
      StoriesAuthorsModel.keyLastStory,
      StoriesAuthorsModel.keyStoriesList,
    ]);

    query.whereGreaterThan(
        StoriesAuthorsModel.keyLastStoryExpiration, DateTime.now());
    query.orderByAscending(StoriesAuthorsModel.keyLastStorySeen);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        for (StoriesAuthorsModel storyAuthorModel in parseResponse.results!) {
          if (!authorsList.contains(storyAuthorModel)) {
            authorsList.add(storyAuthorModel);
          }
        }
      }
    }
  }

  Widget _getAllStories() {
    QueryBuilder<StoriesAuthorsModel> query =
        QueryBuilder<StoriesAuthorsModel>(StoriesAuthorsModel());

    query.whereGreaterThan(
        StoriesAuthorsModel.keyLastStoryExpiration, DateTime.now());
    query.orderByAscending(StoriesAuthorsModel.keyLastStorySeen);

    query.includeObject([
      StoriesAuthorsModel.keyAuthor,
      StoriesAuthorsModel.keyLastStory,
      StoriesAuthorsModel.keyStoriesList,
    ]);

    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ContainerCorner(
          width: size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    StoryTypeChooserPage(
                      currentUser: widget.currentUser,
                    )),
                child: Stack(
                  alignment: AlignmentDirectional.center,
                  children: [
                    ContainerCorner(
                      height: 60,
                      width: 60,
                      child: ActionsHelper.polygonAvatarWidget(
                          currentUser:widget.currentUser!),
                    ),
                    ContainerCorner(
                      height: 60,
                      width: 60,
                      child: FlutterClipPolygon(
                        sides: 6,
                        borderRadius: 0.0, // Defaults to 0.0 degrees
                        rotate: 0.0, // Defaults to 0.0 degree,
                        child: const ContainerCorner(
                          alignment: Alignment.topCenter,
                          borderWidth: 0,
                          /*marginLeft: 10,
                          marginTop: 4,*/
                          color: Colors.black45,
                          // borderRadius: 50,
                          height: 50,
                          width: 50,
                          borderColor: kPrimaryColor,
                          child: Center(
                              child: TextWithTap("+",
                                  color: kContentColorDarkTheme, fontSize: 28)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ContainerCorner(
                  width: size.width * 0.7,
                  height: 80,
                  child: ParseLiveListWidget<StoriesAuthorsModel>(
                    query: query,
                    reverse: false,
                    lazyLoading: false,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    duration: const Duration(milliseconds: 200),
                    childBuilder: (BuildContext context,
                        ParseLiveListElementSnapshot<StoriesAuthorsModel>
                            snapshot) {
                      if (snapshot.hasData) {
                        StoriesAuthorsModel storyAuthor = snapshot.loadedData!;

                        return GestureDetector(
                          onTap: () {
                            for (int i = 0; i < authorsList.length; i++) {
                              if (authorsList[i].objectId ==
                                  storyAuthor.objectId) {
                                startIndex = i;
                              }
                            }

                            MainHelper.goToNavigatorScreen(
                                context,
                                SeeStoriesPage(
                                  currentUser: widget.currentUser,
                                  storyAuthorPre: storyAuthor,
                                  authorsList: authorsList,
                                  firstUserIndex: startIndex,
                                  backPageIndex: 1,
                                ));
                          },
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(8.0, 0, 8.0, 0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                ContainerCorner(
                                    height: 60,
                                    width: 60,
                                    child: ActionsHelper.polygonAvatarWidget(
                                        currentUser:storyAuthor.getAuthor!,
                                        fontSize: 20,
                                        width: 55,
                                        height: 55)),
                              ],
                            ),
                          ),
                        );
                      } else {
                        return Center(
                          child: MainHelper.appLoading(),
                        );
                      }
                    },
                    listLoadingElement: Center(
                      child: ContainerCorner(
                          width: 30, height: 30, child: MainHelper.appLoading()),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _getAllVideosFromFriends() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(
        VideoModel.keyCurrentState, VideoModel.videoCurrentStatePublished);
    query.whereNotEqualTo(VideoModel.keyAuthor, widget.currentUser);
    query.whereContainedIn(
        VideoModel.keyAuthorId, widget.currentUser!.getFollowing!);
    query.orderByDescending(VideoModel.keyCreatedAt);
    query.whereNotContainedIn(VideoModel.keyObjectId, widget.currentUser!.getReportedVideos!);
    query.whereNotContainedIn(VideoModel.keyObjectId, widget.currentUser!.getBlockedContentIDs!);
    query.whereNotContainedIn(VideoModel.keyAuthorId, widget.currentUser!.getBlockedUsersIDs!);

    return ParseLiveListWidget<VideoModel>(
      query: query,
      reverse: false,
      /*crossAxisSpacing: 10,
      mainAxisSpacing: 10,*/
      scrollPhysics: const NeverScrollableScrollPhysics(),
      lazyLoading: false,
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {
          return ContainerCorner(
              height: size.height * 0.6, child: noConnectedMessage());
        } else if (snapshot.hasData) {
          VideoModel video = snapshot.loadedData!;
          return ContainerCorner(
            color: kButtonTextColor.withOpacity(0.2),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GestureDetector(
                  onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    video.getAuthor!.getUid == widget.currentUser!.getUid
                        ? ProfilePage(
                            currentUser: widget.currentUser!,
                          )
                        : UserProfilePage(
                            currentUser: widget.currentUser,
                            mUser: video.getAuthor!,
                          ),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(
                        left: size.width / 35, right: size.width / 35,
                      top:10,
                    ),
                    child: SizedBox(
                      height: size.height * 0.075,
                      width: size.width,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          ActionsHelper.polygonAvatarWidget(
                              currentUser:video.getAuthor!,
                              fontSize: 27),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(
                                  left: size.width / 70, bottom: size.width / 60),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  TextWithTap(
                                    video.getAuthor!.username.toString(),
                                    fontSize: size.width / 24,
                                    marginBottom: 3.0,
                                    color: kContentColorDarkTheme,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              PopupMenuButton<Items>(
                                icon: const Icon(
                                  Icons.more_horiz,
                                  color: Colors.white,
                                ),
                                position: PopupMenuPosition.under,
                                itemBuilder: (BuildContext context) => <PopupMenuEntry<Items>>[
                                  PopupMenuItem<Items>(
                                    value: Items.report,
                                    child: GestureDetector(
                                      onTap: () {
                                        MainHelper.hideLoadingDialog(context);
                                        report(video);
                                      },
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Icon(Icons.flag,
                                            color:MainHelper.getColorStandard(),),
                                          TextWithTap(
                                            'video.report_content'.tr(),
                                            marginLeft: 10,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  PopupMenuItem<Items>(
                                    value: Items.block,
                                    child: GestureDetector(
                                      onTap: (){
                                        MainHelper.hideLoadingDialog(context);
                                        showBlockContentAlert(video);
                                      },
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Icon(Icons.block,
                                            color:MainHelper.getColorStandard(),),
                                          TextWithTap(
                                            'video.block_content'.tr(),
                                            marginLeft: 10,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ]
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    WatchVideoPage(
                      currentUser: widget.currentUser!,
                      video: video,
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        width: double.infinity,
                        height: size.height * 0.53,
                        /*marginLeft: size.width / 35,
                        marginRight: size.width / 35,*/
                        marginTop: size.height / 60,
                        marginBottom: size.width / 18,
                        child: ActionsHelper.videoThumbnailWidget(
                            video, double.infinity, size.height * 0.62),
                      ),
                      ContainerCorner(
                        width: double.infinity,
                        height: size.height * 0.53,
                        /*marginLeft: size.width / 35,
                        marginRight: size.width / 35,*/
                        marginTop: 16,
                        marginBottom: size.width / 18,
                        color: Colors.black.withOpacity(0.15),
                        child: Center(
                          child: Icon(
                            Icons.play_arrow,
                            color: kContentColorDarkTheme.withOpacity(0.6),
                            size: size.width / 7,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          );
        } else {
          return ContainerCorner(
            width: size.width,
            height: size.height * 0.6,
            child: Center(
              child: MainHelper.appLoading(),
            ),
          );
        }
      },
      queryEmptyElement:
          ContainerCorner(height: size.height * 0.6, child: noVideosMessage()),
      listLoadingElement: ContainerCorner(
        width: size.width,
        height: size.height * 0.6,
        child: Center(
          child: MainHelper.appLoading(),
        ),
      ),
    );
  }

  Widget noConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget noVideosMessage() {
    return Center(
      child: TextWithTap(
        'video.no_friends_videos'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
        marginRight: size.width / 30,
        marginLeft: size.width / 30,
      ),
    );
  }

  setupControlLiveQuery() async {
    QueryBuilder<NotificationsModel> query = QueryBuilder<NotificationsModel>(NotificationsModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(NotificationsModel.keyRead, false);
    query.whereEqualTo(NotificationsModel.keyReceiverId, widget.currentUser!.objectId);

    subscription = await liveQuery.client.subscribe(query);

    subscription!.on(LiveQueryEvent.update, (List<NotificationsModel> value) async {
      if(value.isNotEmpty){
        setState(() {
          notifications = value.length;
        });
      }
    });

    subscription!.on(LiveQueryEvent.enter, (List<NotificationsModel> value) {
      setState(() {});
    });
  }


  // ------- Report and block content methods ----------
  showBlockContentAlert(VideoModel video){
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "video.block_content_confirm".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_"
                              .tr()
                              .toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          blockContent(video);
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  blockContent(VideoModel video) async {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showLoadingDialog(context);

    widget.currentUser!.setBlockedContentIds = video.objectId!;
    ParseResponse response = await widget.currentUser!.save();

    if(response.success){
      MainHelper.hideLoadingDialog(context);

      MainHelper.goToNavigatorScreen(
        context,
        HomePage(
          currentUser: widget.currentUser,
          showPageWithIndex: 1,
        ),
        back: false,
        finish: true,
      );
    }else{
      MainHelper.hideLoadingDialog(context);

      MainHelper.showAppNotificationAdvanced(
        title: 'video.something_wrong'.tr(),
        context: context,
        isError: false,
      );
    }
  }

  report(VideoModel video) {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: kTransparentColor,// Colors.black.withOpacity(0.4),
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPostOptionsAndReportAuthor(video);
        });
  }

  Widget _showPostOptionsAndReportAuthor(VideoModel video) {
    List<dynamic> reportReason = [
      ReportModel.thisPosHasSexualContents,
      ReportModel.fakeProfileSpan,
      ReportModel.inappropriateMessage,
      ReportModel.someoneIsInDanger,
    ];

    return GestureDetector(
      onTap: () => MainHelper.goBackToPreviousPage(context),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        height: size.height,
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: size.height <= 570 ? 0.6 : 0.5,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                var size = MediaQuery.of(context).size;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        borderWidth: 0,
                        color: Colors.black.withOpacity(0.4),
                        width: size.width,
                        height: size.height,
                        radiusTopRight: 25,
                        radiusTopLeft: 25,
                        imageDecoration: "assets/images/app_bg.png",
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(25),
                          topLeft: Radius.circular(25),
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: ContainerCorner(
                              color: kTransparentColor,
                              height: size.height,
                              width: size.width),
                        ),
                      ),
                      Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kTransparentColor,
                          centerTitle: true,
                          actions: [
                            IconButton(
                                onPressed: () =>
                                    MainHelper.goBackToPreviousPage(context),
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 25,
                                ))
                          ],
                          title: TextWithTap(
                            "video.report_reason_title".tr(),
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        body: ContainerCorner(
                          radiusTopRight: 20.0,
                          radiusTopLeft: 20.0,
                          color: kTransparentColor,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: List.generate(
                                  reportReason.length,
                                      (index) => Column(
                                    children: [
                                      ButtonWithIcon(
                                        text: MainHelper.getReportMessage(reportReason[index]),
                                        iconColor: kPrimaryColor,
                                        height: 50,
                                        marginLeft: 10,
                                        marginRight: 10,
                                        backgroundColor: Colors.white.withOpacity(0.1),
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        textColor: Colors.white,
                                        fontSize: 17,
                                        fontWeight: FontWeight.w500,
                                        onTap: () {
                                          createReport(
                                            video: video,
                                            message: MainHelper.getReportMessage(reportReason[index])
                                          );
                                        },
                                      ),
                                      const Divider(),
                                    ],
                                  )
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  createReport({
    String? message,
    VideoModel? video
  }) async {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showLoadingDialog(context);

    ReportModel report = ReportModel();

    report.setAccuser = widget.currentUser!;
    report.setAccusedId = widget.currentUser!.objectId!;

    report.setAccused = video!.getAuthor!;
    report.setAccuserId = video.getAuthor!.objectId!;

    report.setVideo = video;
    report.setVideoId = video.objectId!;

    report.setMessage = message!;

    ParseResponse response = await report.save();

    if(response.success){
      widget.currentUser!.setReportedVideos = video.objectId!;
      widget.currentUser!.save();

      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title:'report_message'.tr(),
        context: context,
        isError: false,
      );
    }else{
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title:'video.report_failed_title'.tr(),
        message: 'video.report_failed_message'.tr(),
        context: context,
        isError: true,
      );
    }
  }

}
