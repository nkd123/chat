// ignore_for_file: must_be_immutable

import 'dart:ui';

import 'package:challenge/pages/home/video_pages/upload_video_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock/wakelock.dart';

import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class AcceptChallengePage extends StatefulWidget {
  static const String route = "/Video/Accept";

  final UserModel? currentUser;
  final VideoModel? video;
  ChallengeModel? challenge;
  bool? isAuthor = true;

  AcceptChallengePage(
      {Key? key,
       this.currentUser,
       this.video,
       this.challenge,
       this.isAuthor,
  }) : super(key: key);

  @override
  State<AcceptChallengePage> createState() => _AcceptChallengePageState();
}

class _AcceptChallengePageState extends State<AcceptChallengePage> {
  get size => MediaQuery.of(context).size;
  late VideoPlayerController _controller;
  bool videoApproved = false;
  bool isPlaying = false;

  late VideoModel video;
  bool loaded = false;

  getVideoInfo() async {
    QueryBuilder<VideoModel> query =
    QueryBuilder<VideoModel>(VideoModel());

    query.whereEqualTo(VideoModel.keyObjectId, widget.video!.getObjectId);

    ParseResponse response = await query.query();
    if(response.success && response.result != null){
      setState((){
        video = response.results?.first as VideoModel;
        initController();
        loaded = true;
      });
    }
  }

  initController(){
    _controller = VideoPlayerController.network(
      video.getVideo != null
          ? '${video.getVideo!.url}'
          : '${video.getUrl}',
    )
      ..addListener(() {})
      ..setLooping(false)
      ..initialize().then((_) {
        //_controller.play();
      });
  }

  @override
  void initState() {
    super.initState();
    getVideoInfo();

    Wakelock.enable();
  }

  @override
  void dispose() {
    Wakelock.disable();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: loaded
        ? _getBody()
        : initialLoading(),
    );
  }

  playOrPauseVideo(){
    setState((){
      if(_controller.value.isPlaying){
        _controller.pause();
        isPlaying = false;
      }else{
        _controller.play();
        isPlaying = true;
      }
    });
  }

  Widget initialLoading(){
    return Stack(
      children: [
        ContainerCorner(
          borderWidth: 0,
          color: kTransparentColor,
          width: size.width,
          height: size.height,
          imageDecoration: "assets/images/app_bg.png",
        ),
        ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: ContainerCorner(
              width: size.width,
              height: size.height,
            ),
          ),
        ),
        const SafeArea(
            child: Center(
              child: CircularProgressIndicator(),
            )
        )
      ],
    );
  }

  Widget _getBody() {
    return Stack(
      children: [
        ContainerCorner(
          onTap: (){
            playOrPauseVideo();
          },
          width: size.width,
          height: size.height,
          imageDecoration: "assets/images/app_bg.png",
          child: videoPlayer(),
        ),
        Visibility(
          visible: !_controller.value.isPlaying,
            child: ContainerCorner(
              onTap: (){
                playOrPauseVideo();
              },
              width: size.width,
              height: size.height,
              child: Center(
                child: ContainerCorner(
                  onTap: (){
                    playOrPauseVideo();
                  },
                  width: size.width*0.20,
                  height: size.width*0.20,
                  color: Colors.black.withOpacity(0.3),
                  borderRadius: 50,
                  child: Center(
                    child: Icon(
                      Icons.play_arrow,
                      color: Colors.white,
                      size: size.width*0.16,
                    ),
                  ),
                ),
              ),
            )
        ),
        Visibility(
            visible: true,
            child:Column(
              children: [
                showCallToAction(),
                ContainerCorner(
                  width: size.width,
                  height: size.height*0.15,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ContainerCorner(
                            onTap: () {
                              cancelUpload();
                            },
                            width:size.width/8,
                            height:size.width/8,
                            marginLeft: 10,
                            marginRight: 10,
                            marginTop:16,
                            marginBottom:16,
                            color: kButtonTextColor,
                            borderRadius: 50,
                            child: Center(
                              child: Icon(Icons.close, size: size.width/15,color: kContentColorDarkTheme,),
                            ),
                          ),
                          ContainerCorner(
                            onTap: () {
                              acceptChallenge();
                            },
                            width:size.width/8,
                            height:size.width/8,
                            marginLeft: 10,
                            marginRight: 10,
                            marginTop:16,
                            marginBottom:16,
                            color: kButtonTextColor,
                            borderRadius: 50,
                            child: Center(
                              child: Icon(Icons.check, size: size.width/15,color: kContentColorDarkTheme,),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            )
        ),
      ],
    );
  }

  Widget videoPlayer(){
    return _controller.value.isInitialized
        ? AspectRatio(
        aspectRatio: _controller.value.aspectRatio,
        child: VideoPlayer(_controller))
        : Image.network(video.getThumbnail!.url!,fit: BoxFit.fill,);
  }

  Widget showCallToAction(){
    return SafeArea(
        child: TextWithTap(
          "challenges.accept_challenge_message".tr(),
          fontSize: 17,
          fontWeight: FontWeight.bold,
          marginRight: 10,
          marginLeft: 15,
          marginTop: 15,
          color: Colors.white,
        )
    );
  }

  acceptChallenge(){
    if(isPlaying){
      _controller.pause();
      isPlaying = false;
    }

    MainHelper.goToNavigatorScreen(
      context,
      UploadVideoPage(
        currentUser: widget.currentUser!,
        challenge: widget.challenge,
        isRePropose: false,
        isAuthor: false,
      )
    );
  }

  cancelUpload(){
    MainHelper.goBackToPreviousPage(context);
  }
}
