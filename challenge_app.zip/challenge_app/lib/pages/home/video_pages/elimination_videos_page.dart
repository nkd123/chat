// ignore_for_file: use_build_context_synchronously

import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:wakelock/wakelock.dart';

import '../../../configurations/constants_config.dart';
import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../utilities/helper_classes/cloud_helper.dart';
import '../../../widgets/custom_video_player.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class VideoEliminationPage extends StatefulWidget {
  static const String route = "/video/elimination";
  final UserModel? currentUser;
  const VideoEliminationPage({Key? key, this.currentUser}) : super(key: key);

  @override
  State<VideoEliminationPage> createState() => _VideoEliminationPageState();
}

class _VideoEliminationPageState extends State<VideoEliminationPage> {
  get size => MediaQuery.of(context).size;
  late Map<String, dynamic> challengeMap;
  List<dynamic> challengesList = [];
  List<dynamic> allChallengesList = [];
  late final PageController controller = PageController();

  List<int> selectedChallengesIndex = [];

  bool noResult = false;
  bool error = false;

  late int nextPosition;

  _getChallenges() async {
    QueryBuilder<ChallengeModel> query =
    QueryBuilder<ChallengeModel>(ChallengeModel());

    query.whereEqualTo(
        ChallengeModel.keyMode, ChallengeModel.mode1VS1);
    query.whereValueExists(ChallengeModel.keyAuthorVideo, true);
    query.whereValueExists(ChallengeModel.keyChallengerVideo, true);

    query.whereNotContainedIn(ChallengeModel.keyAuthorVideoId, widget.currentUser!.getReportedVideos!);
    query.whereNotContainedIn(ChallengeModel.keyChallengerVideoId, widget.currentUser!.getReportedVideos!);

    query.whereNotContainedIn(ChallengeModel.keyAuthorVideoId, widget.currentUser!.getBlockedContentIDs!);
    query.whereNotContainedIn(ChallengeModel.keyChallengerVideoId, widget.currentUser!.getBlockedContentIDs!);

    query.whereNotContainedIn(ChallengeModel.keyChallengerId, widget.currentUser!.getBlockedUsersIDs!);
    query.whereNotContainedIn(ChallengeModel.keyAuthorId, widget.currentUser!.getBlockedUsersIDs!);

    query.includeObject([
      ChallengeModel.keyAuthor,
      ChallengeModel.keyChallenger,
      ChallengeModel.keyAuthorVideo,
      ChallengeModel.keyChallengerVideo
    ]);

    ParseResponse apiResponse = await query.query();

    if (apiResponse.success) {
      if (apiResponse.results != null) {
        setState((){
          allChallengesList = apiResponse.results as List<dynamic>;
        });
      } else {
        setState((){
          allChallengesList = const AsyncSnapshot.nothing() as List<dynamic>;
          noResult = true;
        });
      }
    } else {
      setState((){
        error = true;
      });
    }
  }

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerInit = false;

  loadBanner(){
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);

    isBannerInit = true;
  }

  @override
  void initState() {
    super.initState();

    Wakelock.enable();
    _getChallenges();
  }

  @override
  void dispose() {
    Wakelock.disable();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if(!isBannerInit){
      loadBanner();
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      body: getBody(),
    );
  }

  Widget getBody(){
    return Stack(
      children: [
        ContainerCorner(
          width: size.width,
          height: size.height,
          imageDecoration: "assets/images/app_bg.png",
        ),
        ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: ContainerCorner(
              width: size.width,
              height: size.height,
            ),
          ),
        ),
        ContainerCorner(
          width: size.width,
          height: size.height,
          color: Colors.black.withOpacity(0.6),
          child: showAllChallenges(),
        ),
      ],
    );
  }

  showAllChallenges(){
    if(allChallengesList.isNotEmpty){
      for(ChallengeModel challenge in allChallengesList){
        if(!challenge.getSelection.contains(widget.currentUser!.objectId)
          /*&& widget.currentUser!.getCategories!.contains(challenge.getCategory)*/
        ){
          challengesList.add(challenge);
        }
      }

      return challengesList.isNotEmpty
       ? Stack(
        children: [
          loadAllChallenges(),
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: ContainerCorner(
                onTap: () => MainHelper.goBackToPreviousPage(context),
                width:size.width/15,
                height:size.width/15,
                marginLeft: 10,
                marginRight: 10,
                marginTop: 20,
                color: kPrimaryColor,
                borderRadius: 50,
                child: Center(
                  child: Icon(Icons.close, size: size.width/25,color:kContentColorDarkTheme,),
                ),
              ),
            ),
          ),
          showBanner(),
        ],)
      : Stack(
        children: [
          noResultFound(),
          SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: ContainerCorner(
                onTap: () => MainHelper.goBackToPreviousPage(context),
                width:size.width/15,
                height:size.width/15,
                marginLeft: 10,
                marginRight: 10,
                marginTop: 20,
                color: kPrimaryColor,
                borderRadius: 50,
                child: Center(
                  child: Icon(Icons.close, size: size.width/25,color:kContentColorDarkTheme,),
                ),
              ),
            ),
          ),
          showBanner(),
        ],
      );

    } else if(error) {
      noConnectedMessage();
    } else if(noResult) {
      noResultFound();
    } else {
      return Center(
        child: MainHelper.appLoading(),
      );
    }
  }

  Widget showBanner(){
    return Visibility(
      visible: isBannerInit,
      child: Align(
        alignment: Alignment.bottomCenter,
        child: ContainerCorner(
          marginBottom: size.height * 0.03,
          width: size.width,
          height: size.height * 0.08,
          child: adWidget,
        ),
      ),
    );
  }

  Widget noConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 17,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget noResultFound() {
    return Center(
      child: TextWithTap(
        'video.no_challenge'.tr(),
        fontSize: size.width / 25,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
        marginRight: size.width / 30,
        marginLeft: size.width / 30,
      ),
    );
  }

  loadAllChallenges(){
    return PageView(
      controller: controller,
      scrollDirection: Axis.vertical,
      children: List.generate(challengesList.length, 
              (index) => getVideos(index)),
    );
  }

  Widget getVideos(int index){
    ChallengeModel challenge = challengesList[index];

    return ContainerCorner(
      width:size.width,
      height:size.height,
      child: Center(
        child: ContainerCorner(
          width: size.width,
          height: size.height * 0.55,
          child: Center(
            child: Stack(
              children: [
                Row(
                  children: [
                    Flexible(
                        flex:1,
                        child: ContainerCorner(
                          width:size.width * 0.5,
                          height: size.height * 0.55,
                          child: Center(
                              child: ContainerCorner(
                                  width: size.width * 0.5,
                                  child: CustomVideoPlayer(
                                      challenge.getAuthorVideo!)
                              ),
                          ),
                        )
                    ),
                    Flexible(
                        flex:1,
                        child: ContainerCorner(
                          width:size.width * 0.5,
                          height: size.height * 0.55,
                          child: Center(
                              child: ContainerCorner(
                                width: size.width * 0.5,
                                child: CustomVideoPlayer(
                                    challenge.getChallengerVideo!),
                              )
                          ),
                        )
                    ),
                  ],
                ),
                Visibility(
                  visible: true,
                  child: Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ContainerCorner(
                            marginTop: 15,
                            marginRight: 6,
                            color: kPrimaryColor,
                            width: size.width * 0.15,
                            height: size.height * 0.07,
                            borderRadius: 50,
                            onTap:() {
                              goToNextPage(index);
                              oneMoreSelection(
                                  index,
                                  challenger: challenge.getAuthor!,
                                  challenge: challenge
                              );
                            },
                            child: Icon(
                              Icons.check,
                              color: Colors.white,
                              size:size.width * 0.09,
                            ),
                          ),
                          ContainerCorner(
                            marginTop: 15,
                            marginLeft: 6,
                            color: kButtonTextColor,
                            width: size.width * 0.15,
                            height: size.height * 0.07,
                            borderRadius: 50,
                            onTap:() {
                              goToNextPage(index);
                              oneMoreSelection(
                                  index,
                                  challenger: challenge.getChallenger!,
                                  challenge: challenge
                              );
                            },
                            child: Icon(
                              Icons.check,
                              color: Colors.white,
                              size:size.width * 0.09,
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  oneMoreSelection(index,{
    UserModel? challenger,
    ChallengeModel? challenge
  }){
    if(selectedChallengesIndex.contains(index)){
      MainHelper.showAppNotificationAdvanced(
        title: 'challenges.challenge_selected_title'.tr(),
        message: 'challenges.challenge_selected_message'.tr(),
        context: context,
      );
    }else{
      updateChallenge(challenge!);
      rewardChallenger(challenger!);
      removeElement(index);
    }
  }

  removeElement(int index){
    selectedChallengesIndex.add(index);
  }

  rewardChallenger(UserModel challenger) async {
    ParseResponse parseResponse = await CloudCodeHelper.rewardChallenger(
       challenger: challenger,
       points: Config.challengerSelectionReward);

    if(parseResponse.success){
      if(Setup.isDebug){
        MainHelper.showAppNotificationAdvanced(
            title: 'Challenger rewarded successfully', context: context);
      }
    }else{
      if(Setup.isDebug){
        MainHelper.showAppNotificationAdvanced(
            title: 'Challenger has not been rewarded successfully',
            context: context
        );
      }
    }
  }

  updateChallenge(ChallengeModel challenge) async {
    challenge.setSelection = widget.currentUser!.objectId!;
    await challenge.save();
  }

  rewardUser() async {
    int count = 0;
    count = widget.currentUser!.getGoldenCoin ?? 0;
    widget.currentUser!.setGoldenCoin = count + Config.userSelectionReward;

    await widget.currentUser!.save();
  }

  double getSelectionPercentage(int totalSelection, int singleSelection){
    return totalSelection == 0 || singleSelection == 0 ? 0 : singleSelection * 100 / totalSelection;
  }

  goToNextPage(int index){
    controller.animateToPage(++index,
        duration: const Duration(milliseconds: 100), curve: Curves.linear);
  }

}
