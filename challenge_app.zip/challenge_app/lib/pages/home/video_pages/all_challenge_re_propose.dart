// ignore_for_file: must_be_immutable

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock/wakelock.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';

class AllChallengeRePropose extends StatefulWidget {
  VideoModel? video;
  UserModel? currentUser;
  VideoPlayerController? videoController;
  BuildContext ctx;
  AllChallengeRePropose(this.ctx, {Key? key, this.video, this.currentUser, this.videoController}) : super(key: key);

  @override
  State<AllChallengeRePropose> createState() => _AllChallengeReProposeState();
}

class _AllChallengeReProposeState extends State<AllChallengeRePropose> with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;

  @override
  void initState() {
    super.initState();

    Wakelock.enable();
  }

  @override
  Widget build(BuildContext context) {
    /*QueryBuilder<UserModel> query =
    QueryBuilder<UserModel>(UserModel.forQuery());

    query.whereContainedIn(UserModel.keyObjectId, widget.video!.getViews!);
    query.orderByAscending(UserModel.keyCreatedAt);*/

    return Padding(
      padding: EdgeInsets.only(left: size.width/20, right: size.width/20, top: 10.0),
      child: /*Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          TextWithTap(
            'video.all_re_proposed_message'.tr(),
            color: kContentColorDarkTheme,
            fontSize: 11.0,
            marginBottom: size.height/25,
          ),
          Expanded(
            child: ParseLiveGridWidget<UserModel>(
              query: query,
              crossAxisCount: 5,
              reverse: false,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              lazyLoading: false,
              childAspectRatio: .7,
              shrinkWrap: true,
              duration: const Duration(milliseconds: 200),
              animationController: _animationController,
              childBuilder: (BuildContext context,
                  ParseLiveListElementSnapshot<UserModel> snapshot) {
                if (snapshot.failed) {
                  return notConnectedMessage();
                } else if (snapshot.hasData) {
                  UserModel viewer = snapshot.loadedData!;
                  return ContainerCorner(
                    onTap: () {
                      QuickHelp.hideLoadingDialog(context);

                      Wakelock.disable();
                      widget.videoController!.pause();

                      QuickHelp.goToNavigatorScreen(
                          widget.ctx,
                          viewer.getUid == widget.currentUser!.getUid
                              ? ProfileScreen(
                            currentUser: widget.currentUser!,
                          )
                              : UserProfileScreen(
                            currentUser: widget.currentUser,
                            mUser: viewer,
                          ),
                        );
                      },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        QuickActions.polygonAvatarWidget(viewer,
                            fontSize: 30),
                        TextWithTap(
                          '@${viewer.getUsername!}',
                          color: kContentColorDarkTheme,
                          fontSize: 10.0,
                          marginLeft: 3.0,
                          marginTop: 5.0,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  );
                } else {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: kContentColorDarkTheme,
                    ),
                  );
                }
              },
              queryEmptyElement: noReProposesMessage(),
              gridLoadingElement: const Center(
                child: CircularProgressIndicator(
                  color: kContentColorDarkTheme,
                ),
              ),
            ),
          ),
        ],
      ),*/
      noReProposesMessage(),
    );
  }

  Widget noReProposesMessage() {
    return Center(
      child: TextWithTap(
        'video.no_re_propose'.tr(),
        fontSize: size.width / 30,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget notConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 17,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }
}
