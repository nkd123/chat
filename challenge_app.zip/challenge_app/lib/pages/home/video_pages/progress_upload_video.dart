import 'package:flutter/material.dart';
import 'package:video_compress/video_compress.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';

class ProgressBarOnUploadingVideo extends StatefulWidget {
  const ProgressBarOnUploadingVideo({Key? key}) : super(key: key);

  @override
  State<ProgressBarOnUploadingVideo> createState() => _ProgressBarOnUploadingVideoState();
}

class _ProgressBarOnUploadingVideoState extends State<ProgressBarOnUploadingVideo> {
  late Subscription subscription;
  double? seenProgress;

  @override
  void initState() {
    subscription = VideoCompress.compressProgress$.subscribe((progress) {
      setState(() {
        seenProgress = progress;
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    VideoCompress.cancelCompression();
    subscription.unsubscribe();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // final value = seenProgress == null ? seenProgress : seenProgress! / 100;
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: const [
        TextWithTap(""),
      ],
    );
  }
}
