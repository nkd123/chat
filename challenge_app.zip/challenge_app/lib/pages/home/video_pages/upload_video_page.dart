// ignore_for_file: must_be_immutable, use_build_context_synchronously
import 'dart:io';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/video_pages/approve_upload.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:video_compress/video_compress.dart';

import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class UploadVideoPage extends StatefulWidget {
  UserModel? currentUser;
  ChallengeModel? challenge;
  ChallengeModel? originalChallenge;
  bool? isRePropose = false;
  bool? isAuthor = true;

  UploadVideoPage({
    this.currentUser,
    this.challenge,
    this.isRePropose,
    this.originalChallenge,
    this.isAuthor,
    Key? key}) : super(key: key);

  static const String route = "/Video/Upload";

  @override
  State<UploadVideoPage> createState() => _UploadVideoPageState();
}

class _UploadVideoPageState extends State<UploadVideoPage> {
  final ImagePicker picker = ImagePicker();
  XFile? video;
  File? thumbnailFile;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: kTransparentColor,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: kTransparentColor,
        automaticallyImplyLeading: false,
        leading: const BackButton(
          color: Colors.white,
        ),
        centerTitle: true,
        title: TextWithTap(
          "video.upload_video".tr(),
          color: Colors.white,
          fontSize: size.width / 17,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: Stack(
        alignment: AlignmentDirectional.center,
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ContainerCorner(
                radiusBottomRight: 20,
                borderWidth: 2,
                imageDecoration: "assets/images/btn_design.png",
                radiusTopLeft: 20,
                marginTop: size.width / 15,
                height: size.width / 7,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  MainHelper.showDialogPermission(
                    context: context,
                    confirmButtonText: 'ok'.tr(),
                    message: 'video.upload_agreement'.tr(),
                    onPressed: () {
                      MainHelper.hideLoadingDialog(context);
                      checkPermission(false);
                    },
                  );
                },
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        "assets/svg/foto.svg",
                        color: Colors.white,
                        width: size.width / 20,
                        height: size.width / 20,
                      ),
                      TextWithTap(
                        "video.gallery_".tr().toUpperCase(),
                        color: Colors.white,
                        fontSize: size.width / 20,
                        marginLeft: size.width / 30,
                        fontWeight: FontWeight.w100,
                      ),
                    ],
                  ),
                ),
              ),
              ContainerCorner(
                radiusBottomRight: 20,
                borderWidth: 2,
                imageDecoration: "assets/images/btn_design.png",
                radiusTopLeft: 20,
                marginTop: size.width / 15,
                height: size.width / 7,
                marginLeft: size.width / 15,
                marginRight: size.width / 15,
                width: size.width,
                onTap: () {
                  MainHelper.showDialogPermission(
                      context: context,
                      confirmButtonText: 'ok'.tr(),
                      message: 'video.upload_agreement'.tr(),
                      onPressed: () {
                        MainHelper.hideLoadingDialog(context);
                        checkPermission(true);
                      },
                  );
                },
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.camera_alt,
                        color: Colors.white,
                        size: size.width / 20,
                      ),
                      TextWithTap(
                        "video.camera_".tr().toUpperCase(),
                        color: Colors.white,
                        fontSize: size.width / 20,
                        marginLeft: size.width / 30,
                        fontWeight: FontWeight.w600,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  checkPermission(bool record) async {
    if (MainHelper.isMobile()) {

      if(record){
        if (await Permission.camera.isGranted) {
          //Choose video
          getVideo(record);
        } else if (await Permission.camera.isDenied) {
          MainHelper.showDialogPermission(
              context: context,
              title: "permissions.video_access".tr(),
              confirmButtonText: "permissions.okay_".tr().toUpperCase(),
              message: "permissions.video_access_explain"
                  .tr(namedArgs: {"app_name": Setup.appName}),
              onPressed: () async {
                MainHelper.hideLoadingDialog(context);

                // You can request multiple permissions at once.
                Map<Permission, PermissionStatus> statuses =
                await [Permission.camera].request();

                if (statuses[Permission.camera]!.isGranted) {
                  //Choose video
                  getVideo(record);
                } else {
                  MainHelper.showAppNotificationAdvanced(
                      title: "permissions.video_access_denied".tr(),
                      message: "permissions.video_access_denied_explain"
                          .tr(namedArgs: {"app_name": Setup.appName}),
                      context: context,
                      isError: true);
                }
              });
        } else if (await Permission.camera.isPermanentlyDenied) {
          openAppSettings();
        }
      } else {
        if (await Permission.storage.isGranted
          || await Permission.videos.isGranted
        ) {
          getVideo(record);
        } else if (await Permission.storage.isDenied
          && await Permission.videos.isDenied
        ) {
          MainHelper.showDialogPermission(
              context: context,
              title: "permissions.gallery_access".tr(),
              confirmButtonText: "permissions.okay_".tr().toUpperCase(),
              message: "permissions.gallery_access_explain"
                  .tr(namedArgs: {"app_name": Setup.appName}),
              onPressed: () async {
                MainHelper.hideLoadingDialog(context);

                // You can request multiple permissions at once.
                Map<Permission, PermissionStatus> statuses =
                await [
                  Permission.storage,
                  Permission.videos
                ].request();

                if (statuses[Permission.storage]!.isGranted
                  || statuses[Permission.videos]!.isGranted
                ) {
                  getVideo(record);
                } else {
                  MainHelper.showAppNotificationAdvanced(
                      title: "permissions.gallery_access_denied".tr(),
                      message: "permissions.gallery_access_denied_explain"
                          .tr(namedArgs: {"app_name": Setup.appName}),
                      context: context,
                      isError: true);
                }
              });
        } else if (await Permission.storage.isPermanentlyDenied) {
          openAppSettings();
        }
      }

    } else {
      getVideo(record);
    }
  }

  getVideo(bool record) async {

    if (record) {
      video = await picker.pickVideo(
          source: ImageSource.camera,
          maxDuration: const Duration(seconds: Config.videoMaxDuration));
    } else {
      video = await picker.pickVideo(
          source: ImageSource.gallery,
          maxDuration: const Duration(seconds: Config.videoMaxDuration));
    }

    if (video != null) {
      thumbnailFile = await VideoCompress.getFileThumbnail(video!.path);
      compressVideo(video!);
    } else {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "video.cancelled_by_user".tr(),
        message: "video.video_not_selected".tr(),
      );
    }
  }

  void compressVideo(XFile video) {

    MainHelper.showLoadingDialogWithText(context,
        description: "video.optimizing_video".tr(), useLogo: false);

    Future.delayed(const Duration(seconds: 1), () async {

      var result = await MainHelper.compressVideo(video);

      if (result != null) {
        MainHelper.hideLoadingDialog(context);
        MainHelper.showLoadingDialogWithText(context,
            description: "video.optimizing_video_uploading".tr());
        uploadFile(result.file!);
      } else {
        MainHelper.hideLoadingDialog(context);

        MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "video.cancelled_by_user".tr(),
          message: "video.video_not_compression_error".tr(),
        );
      }
    });

  }

  uploadFile(File videoFile) async {
    MainHelper.hideLoadingDialog(context);
    MainHelper.goToNavigatorScreen(context,
      ApproveVideoPage(
        currentUser: widget.currentUser,
        video: videoFile,
        challenge: widget.challenge,
        originalChallenge: widget.originalChallenge,
        isRePropose:widget.isRePropose,
        thumbnail: thumbnailFile,
        isAuthor: widget.isAuthor,
      ),
    );

  }
}
