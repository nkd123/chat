import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custome_drawer.dart';

import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class DailyRewardPage extends StatefulWidget {
  static const String route = "/coins/daily";
  final UserModel? currentUser;
  const DailyRewardPage({Key? key, this.currentUser}) : super(key: key);

  @override
  State<DailyRewardPage> createState() => _DailyRewardPageState();
}

class _DailyRewardPageState extends State<DailyRewardPage> {
  get size => MediaQuery.of(context).size;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      endDrawer: CustomDrawer(currentUser: widget.currentUser,),
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: kTransparentColor,
        actions: [
          Builder(builder: (ctx) {
            return ContainerCorner(
              onTap: () => Scaffold.of(ctx).openEndDrawer(),
              imageDecoration: "assets/images/top_btn.png",
              width: size.width / 7,
              height: size.height / 5,
            );
          }),
        ],
      ),
      body: Stack(alignment: Alignment.center, children: [
        ContainerCorner(
          borderWidth: 0,
          height: size.height,
          width: size.width,
          imageDecoration: "assets/images/app_bg.png",
        ),
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            getBody(),
            ContainerCorner(
              imageDecoration: 'assets/images/white_btn.png',
              onTap: (){
                MainHelper.goToNavigatorScreen(
                  context,
                  HomePage(currentUser: widget.currentUser,),
                  finish: true,
                  back: false
                );
              },
              height: size.height / 15,
              width: size.width * 0.70,
              child: TextWithTap(
                "daily_reward.continue".tr(),
                fontSize: size.width/17.5,
                fontWeight: FontWeight.w800,
                textAlign: TextAlign.center,
                marginTop: size.width/30,
                color: kButtonTextColor,
              ),
            )
          ],
        ),

      ]),
    );
  }

  Widget getBody() {
    return ContainerCorner(
      width: size.width*0.85,
      height: size.height * 0.75,
      marginTop: size.height/30,
      imageDecoration: "assets/images/invite_bg.png",
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextWithTap(
              "daily_reward.title".tr().toUpperCase(),
              fontSize: 25,
              fontWeight: FontWeight.bold,
              color: Colors.white,
              marginTop: size.height/20,
            ),
            TextWithTap(
              "daily_reward.subtitle".tr(namedArgs: {'times':'6'}).toUpperCase(),
              fontSize: 25,
              color: Colors.white,
              marginBottom: size.height/30,
            ),
            Column(
              children: List.generate(6, (index) => button("${index+1}".toUpperCase(), () {}, position:index)),
            )
          ],
        ),
      ),
    );
  }

  Widget button(String btnText, VoidCallback btnAction, {int? position}) {
    return ContainerCorner(
      height: size.height / 18,
      width: size.width * 0.75,
      marginLeft: size.width/20,
      marginRight: size.width/20,
      marginBottom: size.height/80,
      imageDecoration: position == 0 ? "assets/images/reward_btn.png" : "assets/images/reward_btn_inactive.png",
      child: SizedBox(
        width: size.width * 0.75,
        height: size.height / 18,
        child: ContainerCorner(
          marginAll: 8,
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: size.width/45,right: size.width/30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "daily_reward.day".tr(),
                      textAlign: TextAlign.center,
                      color: kWelcomeDarkMode,
                      fontSize: size.width/40,
                      marginLeft: size.width / 50,
                    ),
                    TextWithTap(
                      btnText,
                      textAlign: TextAlign.center,
                      color: kWelcomeDarkMode,
                      fontSize: size.width/37,
                      marginLeft: size.width / 50,
                    ),
                  ],
                ),
              ),
              TextWithTap(
                'coins.reward_coins'.tr(namedArgs: {'number':getNumber(position!).toString()}),
                //' Golden Coins',
                textAlign: TextAlign.center,
                color: kContentColorDarkTheme,
                fontSize: size.width/30,
                marginLeft: size.width / 9,
              ),
            ],
          ),
        ),
      ),
    );
  }

  getNumber(int index){
    switch(index){
      case 0:
        return 5;
      case 1:
        return 7;
      case 2:
        return 14;
      case 3:
        return 17;
      case 4:
        return 20;
      case 5:
        return 25;
    }
  }
}
