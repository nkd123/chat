// ignore_for_file: must_be_immutable, library_private_types_in_public_api

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/coins_pages/coins_page.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';

import '../../../models/UserModel.dart';
import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../settings_pages/get_money_page.dart';

class RefillCoinsPage extends StatefulWidget {

  static String route = "/menu/refill";

  UserModel? currentUser;

  RefillCoinsPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _RefillCoinsPageState createState() => _RefillCoinsPageState();
}

class _RefillCoinsPageState extends State<RefillCoinsPage> {

  @override
  Widget build(BuildContext context) {
    return ToolBar(
      extendBodyBehindAppBar: true,
      backgroundColor: kTransparentColor,
      titleChild: TextWithTap(
        "page_title.refill_coins_title".tr(),
        color:Colors.white,
      ),
      centerTitle: MainHelper.isAndroidPlatform() ? false : true,
      leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
      rightButtonIcon: Icons.money,
      rightButtonPress: () => MainHelper.goToNavigatorScreen(
        context,
        GetMoneyPage(
          currentUser: widget.currentUser,
        )),
      child: CoinsPage(currentUser: widget.currentUser,),
    );
  }
}
