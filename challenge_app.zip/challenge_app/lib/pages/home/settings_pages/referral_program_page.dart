// ignore_for_file: must_be_immutable, use_build_context_synchronously, library_private_types_in_public_api

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:share_plus/share_plus.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/services/dynamic_link_service.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../configurations/global_config.dart';
import '../../../widgets/custom_widgets/button_with_gradient.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';


class ReferralPage extends StatefulWidget {
  UserModel? currentUser;

  ReferralPage({Key? key, this.currentUser}) : super(key: key);

  static String route = "/menu/referral";

  @override
  _ReferralPageState createState() => _ReferralPageState();
}

class _ReferralPageState extends State<ReferralPage> {
  final DynamicLinkService _dynamicLinkService = DynamicLinkService();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ToolBar(
      title: "page_title.referral_title".tr(),
      centerTitle: MainHelper.isAndroidPlatform() ? false : true,
      leftButtonIcon: Icons.arrow_back_ios,
      onLeftButtonTap: () => MainHelper.goBackToPreviousPage(context),
      child: SafeArea(
        child: body(),
      ),
    );
  }

  Widget body() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Center(
            child: ContainerCorner(
                color: kTransparentColor,
                marginTop: 70,
                marginBottom: 40,
                child: Image.asset("assets/images/ic_coins_4000.png")),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextWithTap(
                "invite_friends.get_".tr(),
                color: Colors.black,
                marginRight: 5,
                fontSize: 30,
                fontWeight: FontWeight.w900,
              ),
              SvgPicture.asset(
                "assets/svg/dolar_diamond.svg",
                width: 40,
                height: 40,
              ),
              TextWithTap(
                "invite_friends.for_free".tr(),
                color: Colors.black,
                marginLeft: 5,
                fontSize: 30,
                fontWeight: FontWeight.w900,
              ),
            ],
          ),
          ContainerCorner(
            color: kTransparentColor,
            marginTop: 50,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextWithTap(
                  "invite_friends.invite_friends".tr(),
                  fontSize: 16,
                  color: Colors.black,
                ),
                SvgPicture.asset(
                  "assets/svg/ic_diamond.svg",
                  width: 20,
                  height: 20,
                ),
                TextWithTap(
                  "invite_friends.ten_percent".tr(),
                  color: Colors.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 16,
                ),
              ],
            ),
          ),
          ContainerCorner(
            color: kTransparentColor,
            marginTop: 10,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextWithTap(
                  "invite_friends.earnings_as_gift".tr(),
                  fontSize: 16,
                  color: Colors.black,
                ),
                Image.asset(
                  "assets/images/ic_logo.png",
                  height: 30,
                  width: 30,
                )
              ],
            ),
          ),
          ButtonWithGradient(
            activeBoxShadow: true,
            shadowColorOpacity: 0.3,
            height: 40,
            marginTop: 60,
            text: "invite_friends.share_link".tr(),
            beginColor: kWarninngColor,
            endColor: kPrimaryColor,
            marginRight: 40,
            svgURL: "assets/svg/ic_tips_share.svg",
            marginLeft: 40,
            onTap: () {
              createLink();
              //MainHelper.goToNavigatorScreen(context, InvitedUsers(currentUser: widget.currentUser,));
            },
            borderRadius: 50,
          ),
        ],
      ),
    );
  }

  createLink() async {
    MainHelper.showLoadingDialog(context);

    Uri? uri = await _dynamicLinkService
        .createDynamicLink(widget.currentUser!.objectId);

    if (uri != null) {
      MainHelper.hideLoadingDialog(context);
      Share.share("settings_screen.share_app_url".tr(namedArgs: {
        "app_name": Config.appName,
        "url": uri.toString(),
        "id": widget.currentUser!.objectId!
      }));
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "settings_screen.app_could_not_gen_uri".tr(),
          user: widget.currentUser);
    }
  }
}
