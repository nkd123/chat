// ignore_for_file: library_private_types_in_public_api

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../widgets/custom_widgets/container_with_corner.dart';

class ConnectedAccountsPage extends StatefulWidget {
   const ConnectedAccountsPage({ Key? key }) : super(key: key);
  static String route = "/menu/settings/ConnectedAccounts";

  @override
  _ConnectedAccountsPageState createState() => _ConnectedAccountsPageState();
}

class _ConnectedAccountsPageState extends State<ConnectedAccountsPage> {

  bool isFacebookAccountConnected = false;
  bool isGoogleAccountConnected = true;
  bool isInstagramAccountConnected = false;

  String facebookConnectedAccountCode = "123212343546464204623";
  String googleConnectedAccountCode = "123212343546464644677";
  String instagramConnectedAccountCode = "123212343546464638267";

  @override
  Widget build(BuildContext context) {

    return ToolBar(
      title: "connected_accounts.screen_title".tr(),
      leftButtonWidget: const BackButton(),
      child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        settingsWidget("facebook_".tr(),isFacebookAccountConnected),
        settingsWidget("google_".tr(),isGoogleAccountConnected),
        settingsWidget("instagram_".tr(),isInstagramAccountConnected),
      ],
    ),);
  }

  Widget settingsWidget(String type, bool isConnected) {
    //String image = _getImage(type);
    String code = isConnected ? _getCode(type):"";

    return ContainerCorner(
      width: double.infinity,
      color: kTransparentColor,
      borderColor: defaultColor.withOpacity(0.3),
      borderWidth: 0.5,
      onTap:(){
        setState(() {
          _onPressEvent(type, isConnected);
        });
      },
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: const BoxDecoration(
                    shape: BoxShape.rectangle,
                  ),
                  child: const Icon(Icons.facebook, color: kBlueColor1, size: 30,),
                ),
                const SizedBox(width: 4,),
                Text(
                  type,
                  style: const TextStyle(
                    //color: kSecondaryColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            isConnected
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    "connected_accounts.click_to_copy".tr(),
                    style: const TextStyle(
                      color: defaultColor,
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700
                    ),
                  ),
                  Text(
                    code,
                    style: const TextStyle(
                      color: defaultColor,
                      fontSize: 8,
                      fontWeight: FontWeight.w500
                    ),
                  ),
                ],
              )
            :Container(
              padding: const EdgeInsets.symmetric(vertical:1),
              width: MediaQuery.of(context).size.width * 0.26,
              height: 26,
              decoration: BoxDecoration(
                color: kPrimaryColor.withOpacity(0.8),
                borderRadius: BorderRadius.circular(15),
              ),
              child: Text(
                "connect_".tr(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  _onPressEvent(String type,bool isConnected){
    switch (type) {
      case "Facebook":
          // facebook connect account or copy code goes here
          isFacebookAccountConnected = !isConnected ? !isFacebookAccountConnected:isFacebookAccountConnected;
      break;

      case "Instagram":
        // instagram connect account or copy code goes here
        isInstagramAccountConnected = !isConnected ? !isInstagramAccountConnected:isInstagramAccountConnected;
      break;

      default:
        // google connect account or copy code goes here
        isGoogleAccountConnected = !isConnected ? !isGoogleAccountConnected:isGoogleAccountConnected;
    }
  }

  String _getCode(type){
    switch (type) {
      case "Facebook":
        return facebookConnectedAccountCode;
      case "Instagram":
        return instagramConnectedAccountCode;
      default:
        return googleConnectedAccountCode;
    }
  }
}