// ignore_for_file: must_be_immutable, use_build_context_synchronously, library_private_types_in_public_api

import 'dart:ui';

import 'package:fade_shimmer/fade_shimmer.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';

class BlockedUsersPage extends StatefulWidget {
  static const String route = '/users/blocked';

  UserModel? currentUser;

  BlockedUsersPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _BlockedUsersPageState createState() => _BlockedUsersPageState();
}

class _BlockedUsersPageState extends State<BlockedUsersPage> {
  get size => MediaQuery.of(context).size;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    //MainHelper.setWebPageTitle(context, "page_title.blocked_users_title".tr());

    return ToolBar(
        extendBodyBehindAppBar: true,
        backgroundColor: kTransparentColor,
        titleChild: TextWithTap(
          "page_title.blocked_users_title".tr(),
          color:Colors.white,
        ),
        centerTitle: MainHelper.isAndroidPlatform() ? false : true,
        leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(child: blockedUsers()),
            ),
          ],
        ));
  }

  Widget blockedUsers() {
    return FutureBuilder(
        future: _loadBlockedUsers(),
        builder: (BuildContext context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return ListView.builder(
              itemCount: 20,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: FadeShimmer(
                    height: 60,
                    width: 60,
                    radius: 4,
                    highlightColor: const Color(0xff000000).withOpacity(0.4),
                    baseColor: const Color(0xff000000).withOpacity(0.3),
                  ),
                );
              },
            );
          }
          if (snapshot.hasData) {
            var results = snapshot.data as List<dynamic>;
            return ListView.builder(
              itemCount: results.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          ContainerCorner(
                            height: 60,
                            width: 60,
                            child: ActionsHelper.polygonAvatarWidget(
                                currentUser:results[index], fontSize: 13),
                          ),
                          Expanded(
                              child: TextWithTap(
                                results[index].getFullName!,
                                fontSize: 16,
                                marginLeft: 10,
                                color: Colors.white,
                              )),
                          ContainerCorner(
                            height: 25,
                            width: 25,
                            borderRadius: 50,
                            color: kGreenColor,
                            child: const Icon(
                              Icons.vpn_key,
                              color: Colors.white,
                              size: 16,
                            ),
                            onTap: () {
                              showUnblockUserAlert(results[index]);
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            );
          } else {
            return noMessage();
          }
        });
  }

  Widget noMessage() {
    return ContainerCorner(
      width: size.width,
      height: size.height * 0.7,
      child: Center(
        child: TextWithTap(
          'no_blocked_users'.tr(),
          fontSize: size.width / 22,
          textAlign: TextAlign.center,
          marginTop: size.height * 0.17,
          color:Colors.white,
        ),
      ),
    );
  }

  Future<List<dynamic>?> _loadBlockedUsers() async {
    List<String> usersIds = [];

    for (String userId in widget.currentUser!.getBlockedUsersIDs!) {
      usersIds.add(userId);
    }

    if (kDebugMode) {
      print(widget.currentUser!.getBlockedUsersIDs!);
    }

    QueryBuilder<UserModel> queryBuilder =
    QueryBuilder<UserModel>(UserModel.forQuery());
    queryBuilder.whereContainedIn(UserModel.keyId, widget.currentUser!.getBlockedUsersIDs!);

    ParseResponse apiResponse = await queryBuilder.query();

    if (apiResponse.success) {
      if (apiResponse.results != null) {
        return apiResponse.results;
      } else {
        return const AsyncSnapshot.nothing() as dynamic;
      }
    } else {
      return apiResponse.error as dynamic;
    }
  }

  _unlockUser(UserModel author) async {
    MainHelper.showLoadingDialog(context);

    //widget.currentUser!.removeBlockedUser = author;
    widget.currentUser!.removeBlockedUserIds = author.objectId!;

    ParseResponse response = await widget.currentUser!.save();
    if (response.success) {
      Navigator.of(context).pop();
      MainHelper.hideLoadingDialog(context);
      setState(() {});
    }
  }

  showUnblockUserAlert(UserModel user){
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                      top: 15.0, bottom: 10.0),
                  child: ContainerCorner(
                    width: 130,
                    height: 130,
                    child: ActionsHelper.polygonAvatarWidget(
                      currentUser:user, fontSize: 20
                    ),
                  ),
                ),
                TextWithTap(
                  user.getFullName!,
                  textAlign: TextAlign.center,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
                TextWithTap(
                  "feed.unlock_user_confirm".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_"
                              .tr()
                              .toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => _unlockUser(
                            user),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }
}