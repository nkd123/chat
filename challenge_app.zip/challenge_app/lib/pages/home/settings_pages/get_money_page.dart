// ignore_for_file: use_build_context_synchronously, must_be_immutable, library_private_types_in_public_api

import 'dart:ui';

import 'package:challenge/pages/home/settings_pages/widrawal_history_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/livestreaming_pages/live_creation_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/WithdrawModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:iban/iban.dart';

import '../../../configurations/constants_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class GetMoneyPage extends StatefulWidget {
  static String route = "/menu/payout";

  UserModel? currentUser;

  GetMoneyPage({Key? key, this.currentUser}) : super(key: key);

  @override
  _GetMoneyPageState createState() => _GetMoneyPageState();
}

class _GetMoneyPageState extends State<GetMoneyPage> {
  get size => MediaQuery.of(context).size;

  double numberOfPoints = 0;
  double? totalMoney;
  double? minQuantityToWithdraw;
  double widthOfContainer = 350;

  TextEditingController payoonerEmailController = TextEditingController();
  TextEditingController paypalEmailController = TextEditingController();
  TextEditingController moneyToTransferController = TextEditingController();
  TextEditingController ibanTextEditingController = TextEditingController();
  TextEditingController accountNameTextEditingController =
      TextEditingController();
  TextEditingController bankNameTextEditingController = TextEditingController();

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerInit = false;

  loadBanner() {
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);
    isBannerInit = true;
  }

  @override
  dispose() {
    super.dispose();
    banner.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!isBannerInit) {
      loadBanner();
    }

    var size = MediaQuery.of(context).size;
    var coins = widget.currentUser!.getCredits ?? 0;

    numberOfPoints =
        coins.toDouble() * (widthOfContainer / Setup.diamondsNeededToRedeem);

    totalMoney =
        MainHelper.convertDiamondsToMoney(widget.currentUser!.getPoints ?? 0);

    minQuantityToWithdraw =
        MainHelper.convertDiamondsToMoney(Setup.diamondsNeededToRedeem);

    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: kTransparentColor,
      appBar: AppBar(
        backgroundColor: kTransparentColor,
        automaticallyImplyLeading: false,
        leading: const BackButton(
          color: Colors.white,
        ),
        centerTitle: true,
        title: TextWithTap(
          "page_title.payout_title".tr(),
          color: Colors.white,
          fontSize: 25,
          fontWeight: FontWeight.w700,
        ),
        actions: [
          IconButton(
            onPressed: () => MainHelper.goToNavigatorScreen(
                context,
                WithdrawHistoryPage(
                  currentUser: widget.currentUser,
                )),
            icon: const Icon(
              Icons.list_alt,
              color: Colors.white,
            ),
          )
        ],
      ),
      body: ContainerCorner(
        borderWidth: 0,
        child: Stack(
          children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                ),
              ),
            ),
            body(),
          ],
        ),
      ),
    );
  }

  Widget infoCard() {
    return ContainerCorner(
      color: kButtonTextColor,
      borderRadius: 5,
      width: size.width * 0.9,
      marginTop: 20,
      marginBottom: 10,
      child: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "points".tr(),
                      color: Colors.white.withOpacity(0.5),
                      fontSize: size.width / 18,
                      fontWeight: FontWeight.w700,
                    ),
                    TextWithTap(
                      "${widget.currentUser!.getPoints ?? 0}",
                      color: Colors.white.withOpacity(0.8),
                      fontSize: size.width / 22,
                      marginTop: 2,
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "credits".tr(),
                      color: Colors.white.withOpacity(0.5),
                      fontSize: size.width / 18,
                      fontWeight: FontWeight.w700,
                    ),
                    Row(
                      children: [
                        TextWithTap(
                          "${widget.currentUser!.getCredits ?? 0}",
                          color: Colors.white.withOpacity(0.8),
                          fontSize: size.width / 22,
                          marginTop: 2,
                          marginRight: 2,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(top: 2.0),
                          child: SvgPicture.asset(
                            "assets/svg/ic_coin_inactive.svg",
                            height: 15,
                            width: 15,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 35),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "Balance".tr(),
                      color: Colors.white.withOpacity(0.5),
                      fontSize: size.width / 18,
                      fontWeight: FontWeight.w700,
                    ),
                    TextWithTap(
                      "\$${totalMoney!.toStringAsFixed(2)}",
                      color: Colors.white.withOpacity(0.8),
                      fontSize: size.width / 22,
                      marginTop: 2,
                    ),
                  ],
                ),
                Expanded(
                    child: ContainerCorner(
                  color: kPrimaryColor.withOpacity(0.8),
                  height: size.width * 0.1,
                  marginLeft: 50,
                  borderRadius: 5,
                  onTap: () => _showEditPaymentAccountsBottomSheet(),
                  child: Center(
                    child: TextWithTap(
                      "get_money.edit_payment".tr().toUpperCase(),
                      color: Colors.white,
                      fontSize: size.width / 35,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                )),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget userCard() {
    var size = MediaQuery.of(context).size;

    return ContainerCorner(
      child: Stack(
        alignment: AlignmentDirectional.center,
        children: [
          Transform.rotate(
            angle: -0.09,
            child: ContainerCorner(
              width: size.width,
              height: 220,
              color: Colors.black.withOpacity(0.1),
              borderRadius: 4,
              marginRight: size.width / 30,
              marginLeft: size.width / 30,
            ),
          ),
          Transform.rotate(
            angle: 0.09,
            child: ContainerCorner(
              width: size.width,
              height: 220,
              color: Colors.white.withOpacity(0.1),
              borderRadius: 4,
              marginRight: size.width / 30,
              marginLeft: size.width / 30,
            ),
          ),
          ContainerCorner(
            width: size.width,
            height: 220,
            borderRadius: 10,
            marginRight: size.width / 30,
            marginLeft: size.width / 30,
            imageDecoration: "assets/images/nacure.png",
          ),
          Padding(
            padding:
                EdgeInsets.only(left: size.width / 30, right: size.width / 30),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 40, sigmaY: 40),
                child: SizedBox(
                  width: size.width,
                  height: 220,
                ),
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextWithTap(
                  widget.currentUser!.getFirstName!,
                  color: Colors.white.withOpacity(0.5),
                  fontSize: size.width / 18,
                  marginLeft: size.width / 15,
                  marginTop: 10,
                  fontWeight: FontWeight.w700,
                ),
                TextWithTap(
                  "${widget.currentUser!.getUid!}",
                  color: Colors.white.withOpacity(0.3),
                  fontSize: size.width / 22,
                  marginLeft: size.width / 15,
                  marginTop: 2,
                ),
              ],
            ),
          ),
          Positioned(
            top: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.only(right: 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  SvgPicture.asset(
                    "assets/svg/visa_logo.svg",
                    color: Colors.white.withOpacity(0.5),
                    height: 60,
                  ),
                  Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: SvgPicture.asset("assets/svg/chip_logo.svg")),
                  Padding(
                    padding: const EdgeInsets.only(top: 35),
                    child: SvgPicture.asset(
                      "assets/svg/wifi_logo.svg",
                      color: Colors.white.withOpacity(0.5),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            child: Row(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "Balance".tr(),
                      color: Colors.white.withOpacity(0.5),
                      fontSize: size.width / 18,
                      marginLeft: size.width / 15,
                      marginTop: 10,
                      fontWeight: FontWeight.w700,
                    ),
                    TextWithTap(
                      "\$ ${totalMoney!.toStringAsFixed(2)}",
                      color: Colors.white.withOpacity(0.7),
                      fontSize: size.width / 22,
                      marginLeft: size.width / 15,
                      marginBottom: 10,
                      marginTop: 2,
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      "Exp".tr(),
                      color: Colors.white.withOpacity(0.5),
                      fontSize: size.width / 18,
                      marginLeft: size.width / 10,
                      marginTop: 10,
                      fontWeight: FontWeight.w700,
                    ),
                    TextWithTap(
                      "08/${MainHelper.getTwoLastDigit()}",
                      color: Colors.white.withOpacity(0.7),
                      fontSize: size.width / 22,
                      marginLeft: size.width / 10,
                      marginBottom: 10,
                      marginTop: 2,
                    ),
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget body() {
    var size = MediaQuery.of(context).size;

    return SafeArea(
      child: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                infoCard(),
                SizedBox(
                  height: size.height / 10,
                ),
                // slider,
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.currentUser!.getPoints! < 6000)
                      TextWithTap(
                        "get_money.earn_diamonds".tr(namedArgs: {
                          "diamonds": Setup.diamondsNeededToRedeem.toString(),
                          "dolar": MainHelper.convertDiamondsToMoney(
                                  Setup.diamondsNeededToRedeem)
                              .toString()
                        }),
                        textAlign: TextAlign.center,
                        color: Colors.white,
                        marginLeft: size.width / 20,
                        marginRight: size.width / 20,
                        marginBottom: size.width / 20,
                      ),
                    Visibility(
                      visible: widget.currentUser!.getPoints! >= 6000,
                      child: Column(
                        children: [
                          TextWithTap(
                            "get_money.great_job".tr(),
                            fontSize: 27,
                            fontWeight: FontWeight.w900,
                            marginBottom: 15,
                            color: Colors.white,
                          ),
                          TextWithTap(
                            "get_money.only_".tr(),
                            color: Colors.white,
                            overflow: TextOverflow.ellipsis,
                            maxLines: 3,
                            marginLeft: 20,
                            marginRight: 20,
                            textAlign: TextAlign.center,
                          ),
                          TextWithTap(
                            "\$ ${MainHelper.convertDiamondsToMoney(Setup.diamondsNeededToRedeem)}",
                            fontSize: 27,
                            fontWeight: FontWeight.w900,
                            marginTop: 10,
                            color: Colors.white,
                          ),
                          TextWithTap(
                            "get_money.get_remain".tr(),
                            color: Colors.white,
                            marginTop: 10,
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                    Visibility(
                      visible: widget.currentUser!.getPoints! <
                        Setup.diamondsNeededToRedeem
                        && !widget.currentUser!.getIsViewer!,
                      child: ContainerCorner(
                        radiusBottomRight: 20,
                        borderWidth: 2,
                        imageDecoration: "assets/images/btn_design.png",
                        radiusTopLeft: 20,
                        marginTop: size.height / 10,
                        height: size.width / 6,
                        marginLeft: size.width / 13,
                        marginRight: size.width / 13,
                        width: size.width,
                        onTap: () => MainHelper.goToNavigatorScreen(context,
                            LiveCreationPage(currentUser: widget.currentUser!)),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextWithTap(
                                "live_streaming.btn_go_live".tr(),
                                color: Colors.white,
                                marginLeft: 10,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: widget.currentUser!.getPoints! >=
                          Setup.diamondsNeededToRedeem,
                      child: ContainerCorner(
                        radiusBottomRight: 20,
                        borderWidth: 2,
                        imageDecoration: "assets/images/btn_design.png",
                        radiusTopLeft: 20,
                        marginTop: size.height / 15,
                        height: size.width / 6,
                        marginLeft: size.width / 13,
                        marginRight: size.width / 13,
                        width: size.width,
                        onTap: () {
                          if (widget.currentUser!.getPayEmail != null ||
                              widget.currentUser!.getIban != null) {
                            showHowMuchForm();
                            // showNoPaymentMethod();
                          } else {
                            showNoPaymentMethod();
                          }
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    right: 10, left: 10, top: 5, bottom: 5),
                                child: SvgPicture.asset(
                                  "assets/svg/dolar_diamond.svg",
                                  color: Colors.white,
                                  height: 25,
                                  width: 25,
                                ),
                              ),
                              TextWithTap(
                                "get_money.widrawn_money".tr(),
                                color: Colors.white,
                                marginLeft: 10,
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                ContainerCorner(
                  marginTop: 10,
                  width: size.width,
                  height: size.height * 0.08,
                  child: adWidget,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  withdrawMoney(double money, String? email, String method) async {
    MainHelper.showLoadingDialog(context);

    int points = MainHelper.convertMoneyToDiamonds(money).toInt();

    WithdrawModel withdraw = WithdrawModel();

    withdraw.setAuthor = widget.currentUser!;
    withdraw.setStatus = WithdrawModel.pending;

    withdraw.setCompleted = false;
    withdraw.setMethod = method;
    withdraw.setPoints = points;
    withdraw.setAmount = money;
    withdraw.setAmountString = money.toString();
    withdraw.setCurrency = WithdrawModel.currency;

    if (method == WithdrawModel.payoneer) {
      withdraw.setEmail = email!;
    }

    if (method == WithdrawModel.paypal) {
      withdraw.setEmail = email!;
    }

    if (method == WithdrawModel.iban) {
      withdraw.setIBAN = widget.currentUser!.getIban!;
      withdraw.setAccountName = widget.currentUser!.getAccountName!;
      withdraw.setBankName = widget.currentUser!.getBankName!;
    }

    widget.currentUser!.removePoints = points;
    await widget.currentUser!.save().then((value) async {
      ParseResponse response = await withdraw.save();

      if (response.success) {
        moneyToTransferController.clear();

        setState(() {
          widget.currentUser = value.results!.first! as UserModel;
        });
        MainHelper.hideLoadingDialog(context, result: widget.currentUser);
        Navigator.of(context).pop(widget.currentUser);

        MainHelper.showAppNotificationAdvanced(
          title: "get_money.withdraw_title".tr(),
          message: "get_money.withdraw_message".tr(),
          context: context,
          isError: false,
        );
      }
    });
  }

  _showListOfPaymentsMode() {
    return showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return GestureDetector(
            onTap: () => Navigator.of(context).pop(),
            child: Container(
              color: const Color.fromRGBO(0, 0, 0, 0.001),
              child: GestureDetector(
                onTap: () {},
                child: DraggableScrollableSheet(
                  initialChildSize: 0.60,
                  minChildSize: 0.1,
                  maxChildSize: 1.0,
                  builder: (_, controller) {
                    return StatefulBuilder(builder: (context, setState) {
                      return Stack(
                        children: [
                          ContainerCorner(
                            borderWidth: 0,
                            color: Colors.black.withOpacity(0.4),
                            width: size.width,
                            height: size.height,
                            radiusTopRight: 25,
                            radiusTopLeft: 25,
                            imageDecoration: "assets/images/app_bg.png",
                          ),
                          ClipRRect(
                            borderRadius: const BorderRadius.only(
                              topRight: Radius.circular(25),
                              topLeft: Radius.circular(25),
                            ),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                              child: ContainerCorner(
                                  color: kTransparentColor,
                                  height: size.height,
                                  width: size.width),
                            ),
                          ),
                          Container(
                            decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(25.0),
                                topRight: Radius.circular(25.0),
                              ),
                            ),
                            child: Scaffold(
                                backgroundColor: kTransparentColor,
                                appBar: AppBar(
                                  backgroundColor: kTransparentColor,
                                  automaticallyImplyLeading: false,
                                  centerTitle: true,
                                  title: TextWithTap(
                                    "get_money.select_payment".tr(),
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700,
                                  ),
                                  leading: IconButton(
                                    icon: const Icon(Icons.close,
                                        color: Colors.white),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                ),
                                body: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 15.0),
                                  child: Column(
                                    children: [
                                      if (widget.currentUser!.getPayEmail !=
                                          null)
                                        ContainerCorner(
                                          color:kButtonTextColor,
                                          marginBottom: 15,
                                          borderRadius: 10,
                                          child: TextButton(
                                            onPressed: () {
                                              Navigator.pop(context);
                                              withdrawMoney(
                                                  double.parse(
                                                      moneyToTransferController
                                                          .text),
                                                  widget.currentUser!
                                                      .getPayEmail!,
                                                  WithdrawModel.payoneer);
                                            },
                                            child: Padding(
                                              padding: const EdgeInsets.only(left: 5),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  SvgPicture.asset(
                                                    "assets/svg/Payoneer-Logo.wine.svg",
                                                    height: 40,
                                                    color: Colors.white,
                                                  ),
                                                  const ContainerCorner(
                                                    child: Icon(
                                                      Icons.arrow_forward_ios_rounded,
                                                      size: 20,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (widget.currentUser!.getPaypalEmail !=
                                          null)
                                        ContainerCorner(
                                          color:kButtonTextColor,
                                          marginBottom: 15,
                                          borderRadius: 10,
                                          child: TextButton(
                                            onPressed: () {
                                              Navigator.pop(context);
                                              withdrawMoney(
                                                  double.parse(
                                                      moneyToTransferController
                                                          .text),
                                                  widget.currentUser!
                                                      .getPaypalEmail!,
                                                  WithdrawModel.paypal);
                                            },
                                            child: Padding(
                                              padding: const EdgeInsets.only(top:5,bottom: 5,left: 5),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  SvgPicture.asset(
                                                    "assets/svg/paypal-seeklogo.com.svg",
                                                    height: 25,
                                                    color: Colors.white,
                                                  ),
                                                  const ContainerCorner(
                                                    child: Icon(
                                                      Icons.arrow_forward_ios_rounded,
                                                      size: 20,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (widget.currentUser!.getIban != null)
                                        ContainerCorner(
                                          color:kButtonTextColor,
                                          marginBottom: 15,
                                          borderRadius: 10,
                                          child: TextButton(
                                            onPressed: () {
                                              Navigator.pop(context);
                                              withdrawMoney(
                                                  double.parse(
                                                      moneyToTransferController
                                                          .text),
                                                  "IBAN",
                                                  WithdrawModel.iban);
                                            },
                                            child: Padding(
                                              padding: const EdgeInsets.only(top:10,bottom: 10,left: 5),
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  TextWithTap(
                                                    "get_money.bank_account_title"
                                                        .tr()
                                                        .toUpperCase(),
                                                    color: Colors.white,
                                                    fontSize: 17,
                                                    fontWeight: FontWeight.w700,
                                                  ),
                                                  const ContainerCorner(
                                                    child: Icon(
                                                      Icons.arrow_forward_ios_rounded,
                                                      size: 20,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      Visibility(
                                        visible: widget.currentUser!.getIban ==
                                                null &&
                                            widget.currentUser!.getPayEmail ==
                                                null &&
                                            widget.currentUser!.getPaypalEmail ==
                                                null,
                                        child: Column(
                                          children: [
                                            TextButton(
                                              onPressed: () {
                                                Navigator.pop(context);
                                                _showEditPaymentAccountsBottomSheet();
                                              },
                                              child: TextWithTap(
                                                "get_money.payment_account"
                                                    .tr(),
                                                color: Colors.white,
                                                fontSize: 16,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                )),
                          ),
                        ],
                      );
                    });
                  },
                ),
              ),
            ),
          );
        });
  }

  _showEditPaymentAccountsBottomSheet() {
    return showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return StatefulBuilder(
            builder: (context, stateSetter) {
              return GestureDetector(
                onTap: () => Navigator.of(context).pop(),
                child: Container(
                  color: const Color.fromRGBO(0, 0, 0, 0.001),
                  child: GestureDetector(
                    onTap: () {},
                    child: DraggableScrollableSheet(
                      initialChildSize: 0.60,
                      minChildSize: 0.1,
                      maxChildSize: 1.0,
                      builder: (_, controller) {
                        return StatefulBuilder(builder: (context, setState) {
                          return bottomSheetContent();
                        });
                      },
                    ),
                  ),
                ),
              );
            },
          );
        });
  }

  Widget bottomSheetContent(){
    return Stack(
      children: [
        ContainerCorner(
          borderWidth: 0,
          color: Colors.black.withOpacity(0.4),
          width: size.width,
          height: size.height,
          radiusTopRight: 25,
          radiusTopLeft: 25,
          imageDecoration: "assets/images/app_bg.png",
        ),
        ClipRRect(
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(25),
            topLeft: Radius.circular(25),
          ),
          child: BackdropFilter(
            filter:
            ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: ContainerCorner(
                color: kTransparentColor,
                height: size.height,
                width: size.width),
          ),
        ),
        Container(
            decoration: const BoxDecoration(
              color: kTransparentColor,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15.0),
                topRight: Radius.circular(15.0),
              ),
            ),
            child: ContainerCorner(
                color: kTransparentColor,
                child: ListView(
                  children: [
                    TextWithTap(
                      "get_money.payment_account"
                          .tr(),
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                      marginTop: 20,
                      textAlign: TextAlign.center,
                    ),
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 20,
                      marginRight: 20,
                      marginTop: 20,
                      onTap: () {
                        showIbanAddMethodForm();
                      },
                      child: Row(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding:
                            EdgeInsets.only(
                                top: 15.0,
                                left: 7),
                            child: Icon(
                              Icons.account_balance,
                              size: 40,
                              color: Colors.white,
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,
                              children: [
                                TextWithTap(
                                  "get_money.bank_account_title"
                                      .tr(),
                                  color: Colors.white,
                                  marginRight: 10,
                                  marginTop: 15,
                                  fontWeight:
                                  FontWeight.w700,
                                  marginLeft: 15,
                                  fontSize: 18,
                                ),
                                TextWithTap(
                                  "get_money.bank_account_text"
                                      .tr(),
                                  color: Colors.white,
                                  marginRight: 10,
                                  marginBottom: 15,
                                  marginTop: 7,
                                  fontWeight:
                                  FontWeight.w700,
                                  marginLeft: 15,
                                  fontSize: 12,
                                ),
                              ],
                            ),
                          ),
                          ContainerCorner(
                            marginRight: 10,
                            marginTop: 15,
                            child: widget.currentUser!
                                .getIban ==
                                null
                                ? const Icon(
                              Icons.add_circle,
                              color:
                              Colors.white,
                            )
                                : const Icon(
                              Icons
                                  .check_circle,
                              color:
                              Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 20,
                      marginRight: 20,
                      marginTop: 15,
                      onTap: () {
                        showAddMethodForm(WithdrawModel.paypal);
                      },
                      child: Row(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          const Padding(
                            padding:
                            EdgeInsets.only(
                                top: 15.0,
                                left: 7),
                            child: Icon(
                              Icons.paypal,
                              size: 40,
                              color: Colors.white,
                            ),
                          ),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment
                                  .start,
                              children: [
                                TextWithTap(
                                  "get_money.paypal_account_title"
                                      .tr(),
                                  color: Colors.white,
                                  marginRight: 10,
                                  marginTop: 15,
                                  fontWeight:
                                  FontWeight.w700,
                                  marginLeft: 15,
                                  fontSize: 18,
                                ),
                                TextWithTap(
                                  "get_money.paypal_account_text"
                                      .tr(),
                                  color: Colors.white,
                                  marginRight: 10,
                                  marginBottom: 15,
                                  marginTop: 7,
                                  fontWeight:
                                  FontWeight.w700,
                                  marginLeft: 15,
                                  fontSize: 12,
                                ),
                              ],
                            ),
                          ),
                          ContainerCorner(
                            marginRight: 10,
                            marginTop: 15,
                            child: widget.currentUser!
                                .getPaypalEmail ==
                                null
                                ? const Icon(
                              Icons.add_circle,
                              color:
                              Colors.white,
                            )
                                : const Icon(
                              Icons
                                  .check_circle,
                              color:
                              Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ),
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 20,
                      marginRight: 20,
                      marginTop: 15,
                      onTap: () {
                        showAddMethodForm(WithdrawModel.payoneer);
                      },
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding:
                            const EdgeInsets.only(
                                top: 6.0,right: 10,left: 12),
                            child: SvgPicture.asset(
                              "assets/svg/Payoneer-Logo.wine.svg",
                              height: 45,
                              color: Colors.white,
                            ),
                          ),
                          Row(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment
                                      .start,
                                  children: [
                                    TextWithTap(
                                      "get_money.payoneer_account_title"
                                          .tr(),
                                      color: Colors.white,
                                      marginRight: 10,
                                      fontWeight:
                                      FontWeight.w700,
                                      marginLeft: 60,
                                      fontSize: 18,
                                    ),
                                    TextWithTap(
                                      "get_money.payoneer_account_text"
                                          .tr(),
                                      color: Colors.white,
                                      marginRight: 10,
                                      marginBottom: 15,
                                      marginTop: 7,
                                      fontWeight:
                                      FontWeight.w700,
                                      marginLeft: 60,
                                      fontSize: 12,
                                    ),
                                  ],
                                ),
                              ),
                              ContainerCorner(
                                marginRight: 10,
                                child: widget.currentUser!
                                    .getPayEmail ==
                                    null
                                    ? const Icon(
                                  Icons.add_circle,
                                  color:
                                  Colors.white,
                                )
                                    : const Icon(
                                  Icons
                                      .check_circle,
                                  color:
                                  Colors.green,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ))),
      ],
    );
  }

  showAddMethodForm(String type) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextWithTap(
                    type == WithdrawModel.payoneer
                      ? "get_money.payoneer_email".tr()
                      : "get_money.paypal_email".tr(),
                    textAlign: TextAlign.center,
                    marginTop: 20,
                    color: Colors.white,
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  TextField(
                    autocorrect: false,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    controller: type == WithdrawModel.payoneer
                      ? payoonerEmailController
                      : paypalEmailController,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: type == WithdrawModel.payoneer
                          ? widget.currentUser!.getPayEmail ??
                          "get_money.your_email".tr()
                          : widget.currentUser!.getPaypalEmail ??
                          "get_money.your_email".tr(),
                      hintStyle: const TextStyle(
                        color: Colors.white,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  const Divider(
                    color: kGrayColor,
                  ),
                  const SizedBox(
                    height: 35,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ContainerCorner(
                        color: kButtonTextColor,
                        borderRadius: 10,
                        marginLeft: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "cancel".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ),
                      ContainerCorner(
                        color: kPrimaryColor,
                        borderRadius: 10,
                        marginRight: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "get_money.connect_".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                          onPressed: () {
                            if(type == WithdrawModel.payoneer){
                              if (payoonerEmailController.text.isEmpty) {
                                showEmailEmpty(type);
                              } else {
                                checkEmailAndSave(
                                    payoonerEmailController.text, type);
                              }
                            }else{
                              if (paypalEmailController.text.isEmpty) {
                                showEmailEmpty(type);
                              } else {
                                checkEmailAndSave(
                                    paypalEmailController.text, type);
                              }
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        });
  }

  showEmailEmpty(String type) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.empty_email".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.try_again".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showIbanAddMethodForm() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextWithTap(
                    "get_money.insert_iban".tr(),
                    textAlign: TextAlign.center,
                    marginTop: 20,
                    color: Colors.white,
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  TextField(
                    autocorrect: false,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    controller: accountNameTextEditingController,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: widget.currentUser!.getAccountName ??
                          "get_money.type_account_name".tr(),
                      hintStyle: const TextStyle(
                        color: Colors.white,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  const Divider(
                    color: kGrayColor,
                  ),
                  TextField(
                    autocorrect: false,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    controller: bankNameTextEditingController,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: widget.currentUser!.getBankName ??
                          "get_money.type_bank_name".tr(),
                      hintStyle: const TextStyle(
                        color: Colors.white,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  const Divider(
                    color: kGrayColor,
                  ),
                  TextField(
                    autocorrect: false,
                    keyboardType: TextInputType.multiline,
                    maxLines: null,
                    controller: ibanTextEditingController,
                    style: const TextStyle(
                      color: Colors.white,
                    ),
                    decoration: InputDecoration(
                      hintText: widget.currentUser!.getIban ??
                          "get_money.type_iban".tr(),
                      hintStyle: const TextStyle(
                        color: Colors.white,
                      ),
                      border: InputBorder.none,
                    ),
                  ),
                  const Divider(
                    color: kGrayColor,
                  ),
                  const SizedBox(
                    height: 35,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ContainerCorner(
                        color: kButtonTextColor,
                        borderRadius: 10,
                        marginLeft: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "cancel".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                      ),
                      ContainerCorner(
                        color: kPrimaryColor,
                        borderRadius: 10,
                        marginRight: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "get_money.connect_".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () {
                            if (ibanTextEditingController.text.isEmpty ||
                                bankNameTextEditingController.text.isEmpty ||
                                accountNameTextEditingController.text.isEmpty) {
                              showEmptyFieldsError();
                            } else {
                              checkIbanAndSave(
                                  ibanTextEditingController.text,
                                  accountNameTextEditingController.text,
                                  bankNameTextEditingController.text);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          );
        });
  }

  showEmptyFieldsError() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.empty_iban".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.try_again".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showHowMuchForm() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.how_much"
                      .tr(namedArgs: {"money": totalMoney.toString()}),
                  textAlign: TextAlign.center,
                  marginTop: 20,
                  color: Colors.white,
                ),
                TextField(
                  autocorrect: false,
                  keyboardType: TextInputType.number,
                  maxLines: null,
                  controller: moneyToTransferController,
                  style: const TextStyle(
                    color: Colors.white,
                  ),
                  decoration: InputDecoration(
                    hintText: "get_money.transfer_".tr(),
                    hintStyle: const TextStyle(
                      color: Colors.white,
                    ),
                    border: InputBorder.none,
                  ),
                ),
                const Divider(
                  color: kGrayColor,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "confirm_".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          if (moneyToTransferController.text.isEmpty) {
                            showPaymetAmountEmptyError();
                          } else if (double.parse(
                                  moneyToTransferController.text) >
                              double.parse(totalMoney!.toStringAsFixed(0))) {
                            showPaymentLessAmountError();
                          } else if (double.parse(
                                  moneyToTransferController.text) <
                              minQuantityToWithdraw!) {
                            showPaymentMinAmountLimit();
                          } else {
                            _showListOfPaymentsMode();
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showNoPaymentMethod() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.bank_account".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.set_bank".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          _showEditPaymentAccountsBottomSheet();
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showPaymetAmountEmptyError() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.empty_field".tr(),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.try_again".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showPaymentLessAmountError() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.not_enough"
                      .tr(namedArgs: {"money": totalMoney!.toStringAsFixed(0)}),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.try_again".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  showPaymentMinAmountLimit() {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: kButtonTextColor.withOpacity(0.6),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextWithTap(
                  "get_money.less_quantity".tr(
                      namedArgs: {"amount": minQuantityToWithdraw.toString()}),
                  textAlign: TextAlign.center,
                  color: Colors.white,
                  marginTop: 20,
                ),
                const SizedBox(
                  height: 35,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ContainerCorner(
                      color: kButtonTextColor,
                      borderRadius: 10,
                      marginLeft: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "cancel".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                    ContainerCorner(
                      color: kPrimaryColor,
                      borderRadius: 10,
                      marginRight: 5,
                      width: size.width * 0.27,
                      child: TextButton(
                        child: TextWithTap(
                          "get_money.try_again".tr().toUpperCase(),
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
              ],
            ),
          );
        });
  }

  bool _validateEmail(String email) {
    return RegExp(
            r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(email);
  }

  checkEmailAndSave(String email, String type) {
    if (_validateEmail(email)) {
      if(type == WithdrawModel.payoneer){
        createPayoneerEmail(email);
      }else{
        createPaypalEmail(email);
      }
    } else {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: kButtonTextColor.withOpacity(0.6),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextWithTap(
                    "account_settings.invalid_email".tr(),
                    textAlign: TextAlign.center,
                    color: Colors.white,
                    marginTop: 20,
                  ),
                  const SizedBox(
                    height: 35,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ContainerCorner(
                        color: kButtonTextColor,
                        borderRadius: 10,
                        marginLeft: 5,
                        width: size.width * 0.25,
                        child: TextButton(
                          child: TextWithTap(
                            "cancel".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                            Navigator.of(context).pop();
                          },
                        ),
                      ),
                      ContainerCorner(
                        color: kPrimaryColor,
                        borderRadius: 10,
                        marginRight: 5,
                        width: size.width * 0.25,
                        child: TextButton(
                          child: TextWithTap(
                            "get_money.try_again".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            );
          });
    }
  }

  checkIbanAndSave(String iban, String accountName, String bankName) {
    if (isValid(iban)) {
      createIban(iban, accountName, bankName);
    } else {
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              backgroundColor: kButtonTextColor.withOpacity(0.6),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextWithTap(
                    "get_money.invalid_iban".tr(),
                    textAlign: TextAlign.center,
                    color: Colors.white,
                    marginTop: 20,
                  ),
                  const SizedBox(
                    height: 35,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ContainerCorner(
                        color: kButtonTextColor,
                        borderRadius: 10,
                        marginLeft: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "cancel".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                            Navigator.of(context).pop();
                          },
                        ),
                      ),
                      ContainerCorner(
                        color: kPrimaryColor,
                        borderRadius: 10,
                        marginRight: 5,
                        width: size.width * 0.27,
                        child: TextButton(
                          child: TextWithTap(
                            "get_money.try_again".tr().toUpperCase(),
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            );
          });
    }
  }

  void createIban(String iban, String accountName, String bankName) async {
    MainHelper.showLoadingDialog(context);

    widget.currentUser!.setIban = iban;
    widget.currentUser!.setAccountName = accountName;
    widget.currentUser!.setBankName = bankName;

    ParseResponse response = await widget.currentUser!.save();

    if (response.success) {
      widget.currentUser = response.results!.first! as UserModel;

      MainHelper.hideLoadingDialog(context);
      Navigator.of(context).pop();
      Navigator.of(context).pop();
    }
  }

  void createPayoneerEmail(String email) async {
    MainHelper.showLoadingDialog(context);

    widget.currentUser!.setPayEmail = email;
    ParseResponse response = await widget.currentUser!.save();

    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      Navigator.of(context).pop();
      Navigator.of(context).pop();

      MainHelper.showAppNotificationAdvanced(
        title: 'get_money.payoneer_added_title'.tr(),
        message: 'get_money.payoneer_added_message'.tr(),
        context: context,
        isError: false
      );
    }
  }

  void createPaypalEmail(String email) async {
    MainHelper.showLoadingDialog(context);

    widget.currentUser!.setPaypalEmail = email;
    ParseResponse response = await widget.currentUser!.save();

    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      Navigator.of(context).pop();
      Navigator.of(context).pop();

      MainHelper.showAppNotificationAdvanced(
          title: 'get_money.paypal_added_title'.tr(),
          message: 'get_money.paypal_added_message'.tr(),
          context: context,
          isError: false
      );
    }
  }

  Widget settingsOptions(String text, String route) {
    return ContainerCorner(
      color: kTransparentColor,
      height: 60,
      child: TextButton(
          onPressed: () {
            MainHelper.goToWebPage(context, pageType: route);
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextWithTap(
                text,
                color: Colors.black,
              ),
              const Icon(
                Icons.arrow_forward,
                color: kPrimaryColor,
              )
            ],
          )),
    );
  }
}
