// ignore_for_file: implementation_imports, use_build_context_synchronously, library_private_types_in_public_api

import 'dart:ui';

import 'package:easy_localization/src/public_ext.dart';
import 'package:flutter/material.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/pages/authentication/signin_page.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../configurations/global_config.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

enum Reason {
  doNotknowHowToUseTango,
  myAccountWasSuspended,
  iNoLongerHaveAnInterest,
  iDoNotWantAnyoneToKnow,
  iDoNotHaveEnoughFriends,
  iReceivedTooManyFriendRequests,
  imetInappropritedOrAbusiveUsers,
  receivedTooManyNotifications,
  poorAudioOrVideoQuality,
  toDeleteOldAccountHistoryAndCreateANewOne
}

class DeleteAccountPage extends StatefulWidget {
  const DeleteAccountPage({Key? key}) : super(key: key);
  static String route = "/menu/settings/AccountSettings/DeleteAccount";

  @override
  _DeleteAccountPageState createState() => _DeleteAccountPageState();
}

class _DeleteAccountPageState extends State<DeleteAccountPage> {
  get size => MediaQuery.of(context).size;
  UserModel? currentUser;

  List options = [
    "account_settings.option_how_to_use"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_suspended_account".tr(),
    "account_settings.option_interest_waste"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_none_knows"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_enough_friends"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_many_friends_request".tr(),
    "account_settings.option_inappropriate_user".tr(),
    "account_settings.option_many_notifications".tr(),
    "account_settings.option_poor_quality".tr(),
    "account_settings.option_delete_and_create"
        .tr(namedArgs: {"app_name": Config.appName}),
  ];
  List values = [
    Reason.doNotknowHowToUseTango,
    Reason.myAccountWasSuspended,
    Reason.iNoLongerHaveAnInterest,
    Reason.iDoNotWantAnyoneToKnow,
    Reason.iDoNotHaveEnoughFriends,
    Reason.iReceivedTooManyFriendRequests,
    Reason.imetInappropritedOrAbusiveUsers,
    Reason.receivedTooManyNotifications,
    Reason.poorAudioOrVideoQuality,
    Reason.toDeleteOldAccountHistoryAndCreateANewOne,
  ];

  Reason? _reason = Reason.doNotknowHowToUseTango;

  String reason = "";

  @override
  Widget build(BuildContext context) {
    currentUser = ModalRoute.of(context)!.settings.arguments as UserModel;

    return ToolBar(
      extendBodyBehindAppBar: true,
      backgroundColor: kTransparentColor,
      titleChild: TextWithTap(
        "account_settings.account_settings".tr(),
        color: Colors.white,
      ),
      leftButtonWidget: const BackButton(color: kContentColorDarkTheme),
      child: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: Colors.black.withOpacity(0.4),
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topRight: Radius.circular(25),
              topLeft: Radius.circular(25),
            ),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                  color: kTransparentColor,
                  height: size.height,
                  width: size.width),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: List.generate(options.length, (index) {
                        return ListTile(
                            iconColor: Colors.white,
                            textColor: Colors.white,
                            title: TextWithTap(
                              options[index],
                              color: Colors.white,
                              fontSize: 12,
                            ),
                            leading: Radio<Reason>(
                              value: values[index],
                              activeColor: kPrimaryColor,
                              hoverColor: kContentColorDarkTheme,
                              groupValue: _reason,
                              onChanged: (Reason? value) {
                                setState(() {
                                  _reason = value;
                                  reason = value.toString();
                                });
                              },
                            ));
                      })),
                  ContainerCorner(
                    radiusBottomRight: 20,
                    borderWidth: 2,
                    imageDecoration: "assets/images/btn_design.png",
                    radiusTopLeft: 20,
                    marginTop: size.width / 15,
                    marginBottom: size.height * 0.01,
                    height: size.width / 6,
                    marginLeft: size.width / 7,
                    marginRight: size.width / 7,
                    width: size.width,
                    onTap: () {
                      _deleteAccount(reason);
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextWithTap(
                            "account_settings.delete_account"
                                .tr()
                                .toUpperCase(),
                            fontSize: 13,
                            textAlign: TextAlign.center,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                    ),
                  ),
                  ContainerCorner(
                    radiusBottomRight: 20,
                    borderWidth: 2,
                    imageDecoration: "assets/images/btn_design.png",
                    radiusTopLeft: 20,
                    // marginTop: size.width / 15,
                    marginBottom: size.height * 0.07,
                    height: size.width / 6,
                    marginLeft: size.width / 7,
                    marginRight: size.width / 7,
                    width: size.width,
                    onTap: () {
                      Navigator.of(context).pop();
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextWithTap(
                            "cancel".tr().toUpperCase(),
                            fontSize: 13,
                            textAlign: TextAlign.center,
                            color: Colors.white,
                            fontWeight: FontWeight.w500,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void doUserLogout(UserModel? userModel) async {
    MainHelper.showLoadingDialog(context);

    ParseResponse response = await userModel!.logout(deleteLocalUserData: true);
    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      MainHelper.goToNavigatorScreen(context, const SignInPage(),
          finish: true, back: false);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showError(context: context, message: response.error!.message);
    }
  }

  _deleteAccount(String reason) async {
    MainHelper.hideLoadingDialog(context);
    MainHelper.showLoadingDialog(context);

    currentUser!.setAccountDeleted = true;
    currentUser!.setAccountDeletedReason = reason;
    var response = await currentUser!.save();

    if (response.success) {
      doUserLogout(currentUser);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showErrorResult(context, response.error!.code);
    }
  }
}
