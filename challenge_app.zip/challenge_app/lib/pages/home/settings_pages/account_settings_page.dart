// ignore_for_file: library_private_types_in_public_api, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/settings_pages/delete_account_page.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:intl_phone_number_input/intl_phone_number_input.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../../../configurations/global_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../utilities/helper_classes/cloud_helper.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

enum Reason {
  doNotknowHowToUseTango,
  myAccountWasSuspended,
  iNoLongerHaveAnInterest,
  iDoNotWantAnyoneToKnow,
  iDoNotHaveEnoughFriends,
  iReceivedTooManyFriendRequests,
  imetInappropritedOrAbusiveUsers,
  receivedTooManyNotifications,
  poorAudioOrVideoQuality,
  toDeleteOldAccountHistoryAndCreateANewOne
}

class AccountSettingsPage extends StatefulWidget {
  static String route = "/menu/settings/AccountSettings";
  const AccountSettingsPage({Key? key}) : super(key: key);

  @override
  _AccountSettingsPageState createState() => _AccountSettingsPageState();
}

class _AccountSettingsPageState extends State<AccountSettingsPage> {
  get size => MediaQuery.of(context).size;

  final TextEditingController _emailEditingController = TextEditingController();
  final TextEditingController _passwordEditingController = TextEditingController();
  final TextEditingController _pinCodeController = TextEditingController();
  StreamController<ErrorAnimationType>? errorController;
  bool hasError = false;

  int _pageIndex = 0;

  String _pinCode = "";
  bool _resend = false;
  UserModel? _user;

  UserModel? currentUser;
  PhoneNumber number = PhoneNumber(isoCode: Config.initialCountry);

  TextEditingController emailController = TextEditingController();

  List options = [
    "account_settings.option_how_to_use"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_suspended_account".tr(),
    "account_settings.option_interest_waste"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_none_knows"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_enough_friends"
        .tr(namedArgs: {"app_name": Config.appName}),
    "account_settings.option_many_friends_request".tr(),
    "account_settings.option_inappropriate_user".tr(),
    "account_settings.option_many_notifications".tr(),
    "account_settings.option_poor_quality".tr(),
    "account_settings.option_delete_and_create"
        .tr(namedArgs: {"app_name": Config.appName}),
  ];
  List values = [
    Reason.doNotknowHowToUseTango,
    Reason.myAccountWasSuspended,
    Reason.iNoLongerHaveAnInterest,
    Reason.iDoNotWantAnyoneToKnow,
    Reason.iDoNotHaveEnoughFriends,
    Reason.iReceivedTooManyFriendRequests,
    Reason.imetInappropritedOrAbusiveUsers,
    Reason.receivedTooManyNotifications,
    Reason.poorAudioOrVideoQuality,
    Reason.toDeleteOldAccountHistoryAndCreateANewOne,
  ];

  bool isSafeAddressEnabled = true;

  //bool _isCodeEntered = false;
  bool _isNumberValid = false;
  String showInvalidEmailMessage = "";
  TextEditingController phoneNumberEditingController = TextEditingController();

  String typePhone = "phone";
  String typeEmail = "email";
  String typeDelete = "delete";
  String typeAddress = "address";
  String typeReset = "reset";

  String userEmail = "";
  String userPhoneNumber = "";
  String countryIsoCode = "";
  String initialCountry = Config.initialCountry;

  //Reason? _reason = Reason.doNotknowHowToUseTango;

  _getUser() async {
    UserModel? userModel = await ParseUser.currentUser();

    currentUser = userModel;

    setState(() {
      userEmail = currentUser!.getEmail!;
      userPhoneNumber = currentUser!.getPhoneNumberFull!;

      if (currentUser!.getCountryCode != null) {
        initialCountry = currentUser!.getCountryCode!;
      }
    });
  }

  @override
  void initState() {
    _getUser();
    super.initState();
  }

  @override
  void dispose() {
    _emailEditingController.dispose();
    _passwordEditingController.dispose();
    super.dispose();
  }

  _validateEmail(String value){

    if(value.trim().isEmpty){
      MainHelper.showAppNotificationAdvanced(
        context: context,
        message: "auth.no_email_account".tr(),
        title: "error".tr(),
      );
    } else if(!MainHelper.isValidEmail(value.trim())){
      MainHelper.showAppNotificationAdvanced(
        context: context,
        message: "auth.invalid_email".tr(),
        title: "error".tr(),
      );
    } else {
      _sendCodeToEmail(value.trim());
    }

  }

  _showMessage(String title, String message, bool isError){
    MainHelper.showAppNotificationAdvanced(
        title: title,
        message: message,
        isError: isError,
        context: context
    );
  }

  Future<void> showSuccess() async {
    MainHelper.hideLoadingDialog(context);

    MainHelper.showAppNotificationAdvanced(context: context,
        title: "auth.forgot_sent".tr(),
        message: "auth.email_explain".tr(), isError: false);
  }
  
  @override
  Widget build(BuildContext context) {
    currentUser = ModalRoute.of(context)!.settings.arguments as UserModel;

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: IndexedStack(
        index: _pageIndex,
        children: [
          _mainPage(),
          _pinCodeFormPage(),
          _passwordForm(),
        ],
      ),
    );
  }

  Widget _mainPage(){
    return ToolBar(
      extendBodyBehindAppBar: true,
      backgroundColor: kTransparentColor,
      iconColor: Colors.white,
      titleChild: TextWithTap(
        "account_settings.account_settings".tr(),
        color:Colors.white,
      ),
      leftButtonWidget: const BackButton(color:kContentColorDarkTheme),
      child: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                /*settingsWidget(
                    "account_settings.phone_number".tr(), userPhoneNumber, typePhone),
                settingsWidget("account_settings.email_".tr(), userEmail, typeEmail),*/
                settingsWidget(
                    "account_settings.password_change".tr(),
                    "account_settings.password_message".tr(),
                    typeReset),
                settingsWidget(
                    "account_settings.delete_account".tr(),
                    "account_settings.your_account"
                        .tr(namedArgs: {"app_name": Config.appName}),
                    typeDelete),
              ],
            ),
          ),
        ],
      ),
    );
  }

  ContainerCorner settingsWidget(String text, String value, String type) {
    return ContainerCorner(
      width: double.infinity,
      color: kTransparentColor,
      borderColor: defaultColor.withOpacity(0.3),
      borderWidth: 0.5,
      onTap: () {
        _goToPage(type);
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          type == typeAddress
              ? Row(
                  children: [
                    Expanded(
                        child: TextWithTap(
                      text,
                      marginLeft: 10,
                      marginRight: 10,
                      marginTop: 10,
                      marginBottom: 10,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      overflow: TextOverflow.ellipsis
                    )),
                    Padding(
                      padding: const EdgeInsets.only(right: 10.0),
                      child: Checkbox(
                        value: isSafeAddressEnabled,
                        onChanged: (value) => _changeSetting(),
                        activeColor: kPrimaryColor,
                      ),
                    ),
                  ],
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextWithTap(
                      text,
                      marginLeft: 10,
                      marginRight: 10,
                      marginTop: 8,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color:kContentColorDarkTheme,
                    ),
                    TextWithTap(
                      value.isEmpty ? "account_settings.unset_".tr() : value,
                      marginLeft: 10,
                      marginRight: 10,
                      marginBottom: 8,
                      marginTop: 5,
                      fontSize: 14,
                      color: defaultColor,
                      fontWeight: FontWeight.w400,
                    )
                  ],
                ),
        ],
      ),
    );
  }

  _goToPage(String type) {
    if (type == typeAddress) {
      _changeSetting();
    } else {
      switch (type) {
        case "phone":
          showPhoneDialog(context, currentUser!);
          break;

        case "email":
          showEmailDialog(context, currentUser!);
          break;

        case "delete":
          MainHelper.goToNavigator(context, DeleteAccountPage.route,
              arguments: currentUser);
          break;

        case "reset":
          _sendCodeToEmail(userEmail);
          _moveToPage(1);
          break;

        default:
      }
    }
  }

  void showPhoneDialog(BuildContext context, UserModel currentUser) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        actionsAlignment: MainAxisAlignment.end,
        titleTextStyle: const TextStyle(
          fontSize: 14,
        ),
        titlePadding: const EdgeInsets.only(left: 20, top: 15),
        title: Text(
          "account_settings.mobile_".tr(),
          style: TextStyle(
              color:
                  MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w600),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14),
        content: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ContainerCorner(
                      width: 250,
                      child: InternationalPhoneNumberInput(
                        inputDecoration: InputDecoration(
                          hintText: "auth.phone_number_hint".tr(),
                          hintStyle: MainHelper.isDarkMode(context)
                              ? const TextStyle(color: kColorsGrey500)
                              : const TextStyle(color: kColorsGrey500),
                        ),
                        //countries: Setup.allowedCountries,
                        errorMessage: "auth.invalid_phone_number".tr(),
                        searchBoxDecoration: InputDecoration(
                          hintText: "auth.country_input_hint".tr(),
                        ),
                        onInputChanged: (PhoneNumber number) {
                          setState(() {
                            userPhoneNumber = number.phoneNumber.toString();
                            countryIsoCode = number.isoCode.toString();
                          });
                          //this.number = number;
                          //this._phoneNumber = number.phoneNumber!;
                        },
                        onInputValidated: (bool value) {
                          //print(value);
                          setState(() {
                            _isNumberValid = value;
                          });
                        },
                        countrySelectorScrollControlled: true,
                        locale: initialCountry,
                        selectorConfig: SelectorConfig(
                            selectorType: PhoneInputSelectorType.DIALOG,
                            showFlags: true,
                            useEmoji: MainHelper.isWebPlatform() ? false : true,
                            setSelectorButtonAsPrefixIcon: true,
                            trailingSpace: true,
                            leadingPadding: 5),
                        ignoreBlank: false,
                        spaceBetweenSelectorAndTextField: 10,
                        autoValidateMode: AutovalidateMode.onUserInteraction,
                        textStyle: const TextStyle(color: Colors.black),
                        selectorTextStyle: const TextStyle(
                            color: kPrimaryColor,
                            fontSize: 16,
                            fontWeight: FontWeight.normal),
                        initialValue: currentUser.getCountryCode != null &&
                                currentUser.getCountryCode!.isNotEmpty
                            ? PhoneNumber(isoCode: currentUser.getCountryCode)
                            : number,
                        countries: Setup.allowedCountries,
                        textFieldController: phoneNumberEditingController,
                        formatInput: true,
                        autoFocus: true,
                        autoFocusSearch: true,
                        //hintText: number.phoneNumber,
                        keyboardType: const TextInputType.numberWithOptions(
                            signed: false, decimal: false),
                        inputBorder: const OutlineInputBorder(),
                        onSaved: (PhoneNumber number) {
                          //print('On Saved: $number');
                        },
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    "account_settings.phone_number_required"
                        .tr(namedArgs: {"app_name": Config.appName}),
                    style: const TextStyle(
                      fontSize: 13.5,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        actionsPadding: const EdgeInsets.symmetric(vertical: 5.0),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "cancel".tr().toUpperCase(),
              style: TextStyle(
                color:
                    MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
                fontSize: 12,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              updatePhoneNumber();
            },
            child: Text(
              "save".tr().toUpperCase(),
              style: TextStyle(
                color:
                    MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void showEmailDialog(BuildContext context, UserModel currentUser) {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        actionsAlignment: MainAxisAlignment.end,
        titleTextStyle: TextStyle(
          fontSize: 14,
          color: MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
        ),
        titlePadding: const EdgeInsets.only(left: 20, top: 15),
        title: Text(
          "email_".tr(),
          style: TextStyle(
              color:
                  MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
              fontSize: 16,
              fontWeight: FontWeight.w600),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12),
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                      alignLabelWithHint: true,
                      labelText: currentUser.getEmail,
                      hintText: currentUser.getEmail,
                      focusColor: kSecondaryColor,
                      labelStyle: const TextStyle(
                        fontSize: 15,
                        //color: defaultColor,
                      )),
                  autocorrect: false,
                  style: const TextStyle(
                      fontSize: 14, fontWeight: FontWeight.w400),
                  onChanged: (email) {
                    _alertInvalidEmail(email);
                  },
                ),
                TextWithTap(
                  showInvalidEmailMessage,
                  color: kRedColor1,
                ),
              ],
            );
          },
        ),
        actionsPadding: const EdgeInsets.symmetric(vertical: 5.0),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "cancel".tr().toUpperCase(),
              style: TextStyle(
                color:
                    MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
                fontSize: 12,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              _updateEmail(emailController.text);
            },
            child: Text(
              "save".tr().toUpperCase(),
              style: TextStyle(
                color:
                    MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /*bool _validateEmail(String email) {
    return RegExp(
            r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(email);
  }*/

  _alertInvalidEmail(String email) {
    setState(() {
      if (email.isNotEmpty) {
        if (_validateEmail(email)) {
          showInvalidEmailMessage = "";
        } else {
          showInvalidEmailMessage = "account_settings.invalid_email".tr();
        }
      } else {
        showInvalidEmailMessage = "";
      }
    });
  }

  _updateEmail(String email) async {
    if (_validateEmail(email)) {
      MainHelper.showLoadingDialog(context);
      currentUser!.setEmail = email;

      ParseResponse userResult = await currentUser!.save();

      _updateCurrentUser(userResult);
    } else {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "account_settings.error_email_title".tr(),
        message: "account_settings.error_email_explain".tr(),
      );
    }
  }

  updatePhoneNumber() async {
    if (_isNumberValid) {
      MainHelper.showLoadingDialog(context);

      if (userPhoneNumber.isNotEmpty && countryIsoCode.isNotEmpty) {
        currentUser?.setPhoneNumberFull = userPhoneNumber;
        currentUser?.setCountryCode = countryIsoCode;

        ParseResponse userResult = await currentUser!.save();

        _updateCurrentUser(userResult);
      }
    }
  }

  _changeSetting() {
    setState(() {
      isSafeAddressEnabled = !isSafeAddressEnabled;
      // The rest of the code goes here
    });
  }

  _updateCurrentUser(ParseResponse userResult) {
    if (userResult.success) {
      MainHelper.hideLoadingDialog(context);
      MainHelper.hideLoadingDialog(context);

      currentUser = userResult.results!.first as UserModel;

      _getUser();
    } else if (userResult.error!.code == 100) {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context, title: "error".tr(), message: "not_connected".tr());
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context,
          title: "error".tr(),
          message: "try_again_later".tr());
    }
  }

  _moveToPage(int index){
    setState(() {
      _pageIndex = index;
    });
  }

  Widget _formPage({Widget? body}){
    return Scaffold(
      backgroundColor:
      MainHelper.isDarkMode(context) ? kWelcomeDarkMode : Colors.white,
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          ContainerCorner(
            height: size.height,
            width: size.width,
            child:body!,
          ),
        ],
      ),
    );
  }

  // ------ Phone validate code form page ----------
  Widget _pinCodeFormPage() {
    return _formPage(
      body:  Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            height: size.height,
            width: size.width,
            color: Colors.black.withOpacity(0.4),
            child:Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TextWithTap(
                  "verify_code".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 15,
                  fontWeight: FontWeight.w900,
                  marginBottom: 20,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal:25),
                  child: PinCodeTextField(
                    appContext: context,
                    length: Setup.verificationCodeDigits,
                    keyboardType: TextInputType.number,
                    obscureText: false,
                    animationType: AnimationType.fade,
                    autoFocus: false,
                    cursorColor: kPrimaryColor,
                    cursorHeight: 17,
                    textStyle: const TextStyle(
                      color: kPrimaryColor,
                    ),
                    pinTheme: PinTheme(
                      borderWidth: 2.0,
                      shape: PinCodeFieldShape.underline,
                      borderRadius: BorderRadius.zero,
                      fieldHeight: 40,
                      fieldWidth: 45,
                      activeFillColor: Colors.transparent,
                      inactiveFillColor: Colors.transparent,
                      selectedFillColor: Colors.transparent,
                      activeColor: kPrimaryColor,
                      inactiveColor: Colors.white,
                      selectedColor: kPrimaryColor,
                    ),
                    animationDuration: const Duration(milliseconds: 300),
                    backgroundColor: Colors.transparent,
                    enableActiveFill: true,
                    errorAnimationController: errorController,
                    controller: _pinCodeController,
                    autovalidateMode: AutovalidateMode.always,
                    validator: (value) {
                      return null;
                    },
                    useHapticFeedback: true,
                    hapticFeedbackTypes: HapticFeedbackTypes.selection,
                    onChanged: (value) {
                      setState(() {
                        if (value.length == Setup.verificationCodeDigits) {
                          //_isCodeEntered = true;
                        } else {
                          //_isCodeEntered = false;
                        }
                      });
                    },
                    onCompleted: (v) {
                      MainHelper.showLoadingDialog(context);
                      _pinCode = v;
                      _verifyCodeFromEmail(_pinCode);
                    },
                    beforeTextPaste: (text) {
                      //if you return true then it will show the paste confirmation dialog. Otherwise if false, then nothing will happen.
                      //but you can show anything you want here, like your pop up saying wrong paste format or etc
                      return true;
                    },
                  ),
                ),
                TextWithTap(
                  'resent_code'.tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 15,
                  onTap: () {
                    // resend code method is called here
                    _sendCodeToEmail(_emailEditingController.text.trim());
                    _resend = true;
                  },
                ),
                TextWithTap(
                  "cancel".tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 20,
                  onTap: () {
                    _moveToPage(0);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // -- Password form ----
  Widget _passwordForm(){
    return _formPage(
      body: Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            height: size.height,
            width: size.width,
            color: Colors.black.withOpacity(0.4),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextWithTap(
                  "reset_password".tr().toUpperCase(),
                  color: Colors.white,
                  fontSize: size.width / 15,
                  fontWeight: FontWeight.w900,
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/btn_design.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 7,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 20, right: 20),
                    child: Center(
                      child: TextField(
                        autocorrect: false,
                        keyboardType: TextInputType.text,
                        obscureText: true,
                        maxLines: 1,
                        textAlign: TextAlign.center,
                        controller: _passwordEditingController,
                        style: const TextStyle(
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          hintText: "new_password".tr().toLowerCase(),
                          hintStyle: GoogleFonts.azeretMono(
                              color: Colors.white,
                              fontSize: size.width / 20),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                ),
                ContainerCorner(
                  radiusBottomRight: 20,
                  borderWidth: 2,
                  imageDecoration: "assets/images/white_btn.png",
                  radiusTopLeft: 20,
                  marginTop: size.width / 15,
                  height: size.width / 9,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                  width: size.width,
                  onTap: () {
                    _resetPassword();
                  },
                  child: Center(
                    child: TextWithTap(
                      "reset.reset_password".tr().toUpperCase(),
                      color: kPrimaryColor,
                      fontWeight: FontWeight.w900,
                      fontSize: size.width / 20,
                    ),
                  ),
                ),
                TextWithTap(
                  "cancel".tr().toUpperCase(),
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  marginTop: size.width / 10,
                  onTap: () {
                    _moveToPage(0);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }


  // ----------- Email verification method ------------------------
  Future<void> _sendCodeToEmail(String emailAddress) async {
    MainHelper.showLoadingDialog(context);
    _user = await ParseUser.currentUser();

     ParseResponse parseResponse;

      parseResponse = await CloudCodeHelper.sendCodeToEmail(
          user: _user!,
          from: Config.appEmailAddress,
          to: _user!.getEmail!,
          appName: Config.appName,
          apiKey: Config.senderGridApiKey
      );

      if(parseResponse.success){
        MainHelper.hideLoadingDialog(context);

        if(parseResponse.result != null && parseResponse.result){
          // After the code is sent execute the lines bellow
          MainHelper.removeFocusOnTextField(context);
          _pinCodeController.text = "";

          if(!_resend){
            _moveToPage(1);
          }else{
            _resend = false;
          }

        }else{
          _showMessage("error".tr(), "try_again_later".tr(), true);
        }

      }else{
        MainHelper.hideLoadingDialog(context);
        _showMessage("error".tr(), "try_again_later".tr(), true);
      }
  }

  Future<void> _verifyCodeFromEmail(String pinCode) async {
    ParseResponse parseResponse;

    parseResponse = await CloudCodeHelper.verifyCodeFromEmail(
      user: _user!,
      code: pinCode,
    );

    if(parseResponse.success){
      MainHelper.hideLoadingDialog(context);

      if(parseResponse.result != null && parseResponse.result){
        _moveToPage(2);
      }else{
        _pinCodeController.text = "";
        _showMessage("error".tr(), "auth.invalid_code".tr(), true);
      }

    }else{
      MainHelper.hideLoadingDialog(context);
      _showMessage("error".tr(), "try_again_later".tr(), true);
    }
  }


  // ---------- Reset Password Methods --------------
  Future<void> _resetPassword() async {
    MainHelper.showLoadingDialog(context);
    FocusManager.instance.primaryFocus?.unfocus();

    ParseResponse parseResponse;

    parseResponse = await CloudCodeHelper.resetUserPassword(
      user: _user!,
      password: _passwordEditingController.text.trim(),
    );

    if(parseResponse.success){
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
          context: context,
          isError: false,
          title: "reset.password_updated_title".tr(),
          message: "reset.password_updated_message".tr());

      _emailEditingController.text = '';

      _moveToPage(0);
    }else{
      MainHelper.hideLoadingDialog(context);
      _showMessage("error".tr(), "try_again_later".tr(), true);
    }
  }
}
