// ignore_for_file: library_private_types_in_public_api

import 'package:challenge/widgets/custom_widgets/app_bar.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../configurations/global_config.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class WebViewPage extends StatefulWidget {
  final String pageType;

  const WebViewPage({Key? key, required this.pageType}) : super(key: key);

  @override
  _WebViewPageState createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  String? pageUrl;
  String? pageTitle;

  int position = 1;

  final key = UniqueKey();

  doneLoading(String A) {
    setState(() {
      position = 0;
    });
  }

  startLoading(String A) {
    setState(() {
      position = 1;
    });
  }

  @override
  void initState() {
    super.initState();
    // Enable hybrid composition.
    //if (MainHelper.isAndroidPlatform()) WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.pageType == MainHelper.pageTypePrivacy) {
      pageUrl = Config.privacyPolicyUrl;
      pageTitle = "page_title.privacy_policy".tr();
    } else if (widget.pageType == MainHelper.pageTypeTerms) {
      pageUrl = Config.termsOfUseUrl;
      pageTitle = "page_title.terms_of_use".tr();
    } else if (widget.pageType == MainHelper.pageTypeHelpCenter) {
      pageUrl = Config.helpCenterUrl;
      pageTitle = "page_title.help_center_title".tr();
    } else if (widget.pageType == MainHelper.pageTypeCommunity) {
      pageTitle = "page_title.community_title".tr();
    } else if (widget.pageType == MainHelper.pageTypeWhatsapp) {
      pageTitle = "page_title.whatsapp_title".tr();
    }

    return ToolBar(
        leftButtonWidget: BackButton(
          color: MainHelper.isDarkMode(context)
              ? kContentColorDarkTheme
              : kContentColorLightTheme,
        ),
        iconHeight: 30,
        iconWidth: 30,
        centerTitle: true,
        onLeftButtonTap: () {
          MainHelper.goBackToPreviousPage(context);
        },
        titleChild: TextWithTap(
          pageTitle!,
          color: MainHelper.isDarkMode(context)
              ? kContentColorDarkTheme
              : kContentColorLightTheme,
        ),
        elevation: 2,
        child: IndexedStack(
          index: position,
          children: [
            WebView(
              initialUrl: pageUrl,
              key: key,
              javascriptMode: JavascriptMode.unrestricted,
              onPageFinished: doneLoading,
              onPageStarted: startLoading,
              gestureNavigationEnabled: true,
            ),
            Container(
              color: MainHelper.isDarkMode(context)
                  ? kContentColorLightTheme
                  : kContentColorDarkTheme,
              child: const Center(child: CircularProgressIndicator()),
            ),
          ],
        ));
  }
}
