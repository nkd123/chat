// ignore_for_file: use_build_context_synchronously

import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:challenge/pages/home/video_pages/watch_video_page.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/VideoModel.dart';

import '../../../utilities/helper_classes/actions_helper.dart';
import '../../../utilities/helper_classes/main_helper.dart';
import '../../../models/UserModel.dart';
import '../../../widgets/custom_widgets/container_with_corner.dart';
import '../../../utilities/main_utilities/colors.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

// ignore: must_be_immutable
class SearchPage extends StatefulWidget {
  UserModel? currentUser;
  static const String route = "/search";
  SearchPage({Key? key, this.currentUser}) : super(key: key);

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  TextEditingController userSearchController = TextEditingController();
  bool isSearchActive = false;
  String searchTerm = '';
  List<String> userIdsList = [];

  List<dynamic> usersList = [];
  List<dynamic> challengesList = [];

  int tabsLength = 2;
  int tabUsers = 0;
  int tabChallenges = 1;
  late TabController _tabController;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(vsync: this, length: tabsLength)
      ..addListener(() {
        setState(() {
          tabIndex = _tabController.index;
        });
      });
  }

  @override
  void dispose() {
    userSearchController.dispose();
    super.dispose();
  }

  Future<List<dynamic>?> _getUsers() async {
      QueryBuilder<UserModel> usersByUsername =
      QueryBuilder<UserModel>(UserModel.forQuery());

      usersByUsername.whereNotEqualTo(
          UserModel.keyObjectId, widget.currentUser!.objectId);
      usersByUsername.whereNotEqualTo(UserModel.keyUsername,
          UserModel.roleAdmin);
      usersByUsername.whereStartsWith(UserModel.keyUsername, searchTerm);
      /*usersByUsername.whereNotContainedIn(UserModel.keyObjectId,
          widget.currentUser!.getBlockedUsersIDs!);*/

      QueryBuilder<UserModel> usersByFullName =
      QueryBuilder<UserModel>(UserModel.forQuery());

      usersByFullName.whereNotEqualTo(
          UserModel.keyObjectId, widget.currentUser!.objectId);
      usersByFullName.whereNotEqualTo(UserModel.keyUsername,
          UserModel.roleAdmin);
      usersByFullName.whereStartsWith(UserModel.keyFullName, searchTerm);
      /*usersByFullName.whereNotContainedIn(UserModel.keyObjectId,
          widget.currentUser!.getBlockedUsersIDs!);*/

      QueryBuilder<UserModel> usersByFullNameParts =
      QueryBuilder<UserModel>(UserModel.forQuery());

      usersByFullNameParts.whereNotEqualTo(
          UserModel.keyObjectId, widget.currentUser!.objectId);
      usersByFullNameParts.whereNotEqualTo(UserModel.keyUsername,
          UserModel.roleAdmin);
      usersByFullNameParts.whereContains(UserModel.keyFullName, searchTerm);
      /*usersByFullNameParts.whereNotContainedIn(UserModel.keyObjectId,
          widget.currentUser!.getBlockedUsersIDs!);*/

      QueryBuilder<ParseObject> users = QueryBuilder.or(
        UserModel.forQuery(),
        [usersByFullName, usersByUsername, usersByFullNameParts],
      );

      ParseResponse apiResponse = await users.query();

      if (apiResponse.success) {
        if (apiResponse.results != null) {
          return apiResponse.results;
        } else {
          return const AsyncSnapshot.nothing() as List<dynamic>;
        }
      } else {
        return apiResponse.error as dynamic;
      }
  }

  Future<List<dynamic>?> _getChallenges() async {
    QueryBuilder<UserModel> usersByUsername =
    QueryBuilder<UserModel>(UserModel.forQuery());

    usersByUsername.whereNotEqualTo(
        UserModel.keyObjectId, widget.currentUser!.objectId);
    usersByUsername.whereStartsWith(UserModel.keyUsername, searchTerm);

    QueryBuilder<UserModel> usersByFullName =
    QueryBuilder<UserModel>(UserModel.forQuery());

    usersByFullName.whereNotEqualTo(
        UserModel.keyObjectId, widget.currentUser!.objectId);
    usersByFullName.whereStartsWith(UserModel.keyFullName, searchTerm);

    QueryBuilder<UserModel> usersByFullNameParts =
    QueryBuilder<UserModel>(UserModel.forQuery());

    usersByFullNameParts.whereNotEqualTo(
        UserModel.keyObjectId, widget.currentUser!.objectId);
    usersByFullNameParts.whereContains(UserModel.keyFullName, searchTerm);

    QueryBuilder<ParseObject> users = QueryBuilder.or(
      UserModel.forQuery(),
      [usersByFullName, usersByUsername, usersByFullNameParts],
    );

    ParseResponse apiResponse = await users.query();

    if (apiResponse.success) {
      if (apiResponse.results != null &&
          apiResponse.results!.isNotEmpty) {
        for (UserModel user in apiResponse.results!) {
          if (!userIdsList.contains(user.objectId)) {
            userIdsList.add(user.objectId!);
          }
        }
      }

      QueryBuilder<ChallengeModel> challenge =
      QueryBuilder<ChallengeModel>(ChallengeModel());
      challenge.includeObject([
        ChallengeModel.keyAuthor,
      ]);

      challenge.whereContainedIn(ChallengeModel.keyAuthorId, userIdsList);
      challenge.whereNotEqualTo(ChallengeModel.keyMode, ChallengeModel.modeLIVESTREAMING);

      ParseResponse challengeResponse = await challenge.query();

      if (challengeResponse.success) {
        if (challengeResponse.results != null) {
          return challengeResponse.results;
        } else {
          return const AsyncSnapshot.nothing() as List<dynamic>;
        }
      } else {
        return apiResponse.error as dynamic;
      }
    } else {
      return apiResponse.error as dynamic;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => MainHelper.removeFocusOnTextField(context),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        body: getBody(),
      ),
    );
  }

  Widget getBody() {
    return Stack(
      children: [
        ContainerCorner(
          borderWidth: 0,
          color: kTransparentColor,
          width: size.width,
          height: size.height,
          imageDecoration: "assets/images/app_bg.png",
        ),
        ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: ContainerCorner(
              width: size.width,
              height: size.height,
            ),
          ),
        ),
        SafeArea(
          child: Column(
            children: [
              chatInputField(),
              !isSearchActive
                ? Container()
                : /*TabBar(
                isScrollable: true,
                enableFeedback: false,
                controller: _tabController,
                indicatorColor: Colors.transparent,
                unselectedLabelColor: kTabIconDefaultColor,
                labelColor: kTabIconSelectedColor,
                labelStyle: const TextStyle(fontWeight: FontWeight.bold),
                labelPadding: const EdgeInsets.only(right: 14),
                unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
                tabs: [
                  tabsRows("search_screen.search_people", tabUsers,),
                  tabsRows("search_screen.search_challenge", tabChallenges,),
                ],
              ),
              !isSearchActive
                ? Container()
                : Flexible(
                child: TabBarView(
                    controller: _tabController,
                    children: [
                      showUsers(),
                      showChallenges()
                    ]
                )*/Flexible(
                  child: showUsers(),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget tabsRows(String title, int position) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 6),
        TextWithTap(
          title.tr(),
          color: tabIndex == position
              ? Colors.white
              : Colors.white.withOpacity(0.4),
          fontSize: size.width/19.5,
          marginLeft: 10,
          fontWeight: FontWeight.w900,
        ),
      ],
    );
  }

  Widget chatInputField() {
    return Row(
      children: [
        Expanded(
          child: ContainerCorner(
            borderWidth: 0,
            borderRadius: 10,
            marginLeft: 10,
            // marginRight: 10,
            marginBottom: 10,
            marginTop: 10,
            color: Colors.white.withOpacity(0.1),
            height: 45,
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                      left: 5,
                      right: 10,
                    ),
                    child: Center(
                      child: TextField(
                        autocorrect: false,
                        autofocus: true,
                        textInputAction: TextInputAction.search,
                        style: GoogleFonts.nunito(
                          color: Colors.white,
                        ),
                        onTap: () { },
                        /*onChanged: (value){
                          if(value == ''){
                            searchTerm = value;
                            isSearchActive = false;
                          }else{
                            setState((){
                              searchTerm = value;
                            });
                          }
                        },*/
                        onSubmitted: (value){
                          if(value != ''){
                            setState((){
                              searchTerm = value;
                              isSearchActive = true;
                            });
                          }else{
                            setState((){
                              searchTerm = value;
                              isSearchActive = false;
                            });
                          }
                        },
                        keyboardType: TextInputType.multiline,
                        maxLines: 2,
                        controller: userSearchController,
                        decoration: InputDecoration(
                          hintText: "group_creation.search".tr(),
                          prefixIcon: Icon(
                            Icons.search,
                            color: Colors.white.withOpacity(0.1),
                          ),
                          border: InputBorder.none,
                          hintStyle: GoogleFonts.nunito(
                            color: Colors.white.withOpacity(0.2),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                searchTerm != ''
                ? IconButton(
                    onPressed: (){
                      clearTextField();
                    },
                    icon: Icon(
                      Icons.close,
                      color: kContentColorDarkTheme,
                      size: size.width/20,
                    ),
                ) : const SizedBox(),
              ],
            ),
          ),
        ),
        ContainerCorner(
          onTap: () => MainHelper.goBackToPreviousPage(context),
          width:size.width/15,
          height:size.width/15,
          marginLeft: 10,
          marginRight: 10,
          color: kPrimaryColor,
          borderRadius: 50,
          child: Center(
            child: Icon(Icons.close, size: size.width/25,color: kContentColorDarkTheme,),
          ),
        ),
      ],
    );
  }

  Widget showUsers(){
    return FutureBuilder(
      future: _getUsers(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          Center(
            child: MainHelper.appLoading(),
          );
        } else if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasData) {

            usersList = snapshot.data as List<dynamic>;
            return ListView.builder(
              itemCount: usersList.length,
              itemBuilder: (context, index){
                UserModel user = usersList[index];

                  return ContainerCorner(
                    onTap: () {
                      MainHelper.goToNavigatorScreen(
                          context,
                          UserProfilePage(mUser: user,currentUser: widget.currentUser,),
                      );
                    },
                    width: size.width*0.80,
                    height: size.height/12,
                    marginLeft: size.width*0.02,
                    marginRight: size.width*0.02,
                    marginTop: size.width*0.03,
                    child: Row(
                      children: [
                        ActionsHelper.polygonAvatarWidget(
                            currentUser:user,fontSize: size.width/13),
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(left:size.width*0.02),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TextWithTap(
                                  user.getFullName!,
                                  fontSize: size.width/25,
                                  color: kContentColorDarkTheme,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                TextWithTap(
                                  '@${user.getUsername}',
                                  fontSize: size.width/35,
                                  color: kContentColorDarkTheme,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                  );
              },
            );

          } else if (snapshot.hasError) {
            return noResultFound();
          } else {
            return noResultFound();
          }
        } else {
          return noResultFound();
        }

        return Center(
          child: MainHelper.appLoading(),
        );
      },
    );
  }

  Widget showChallenges(){
    return FutureBuilder(
      future: _getChallenges(),
      builder: (BuildContext context, AsyncSnapshot snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          Center(
            child: MainHelper.appLoading(),
          );
        } else if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasData) {

            challengesList = snapshot.data as List<dynamic>;
            return ListView.builder(
              itemCount: challengesList.length,
              itemBuilder: (context, index){
                ChallengeModel challenge = challengesList[index];

                return ContainerCorner(
                  onTap: () {
                    watchChallengeVideo(challenge);
                  },
                  width: size.width*0.80,
                  height: size.height/12,
                  marginLeft: size.width*0.02,
                  marginRight: size.width*0.02,
                  marginTop: size.width*0.03,
                  child: Row(
                    children: [
                      ActionsHelper.polygonAvatarWidget(
                          currentUser:challenge.getAuthor!,fontSize: size.width/25),
                      Padding(
                        padding: EdgeInsets.only(left:size.width*0.02),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TextWithTap(challenge.getAuthor!.getFullName!,fontSize: size.width/25,color: kContentColorDarkTheme,),
                            TextWithTap(MainHelper.getChallengeModeList(challenge.getMode!).toUpperCase(),
                              fontSize: size.width/35,color: kContentColorDarkTheme,),
                          ],
                        ),
                      )
                    ],
                  ),
                );
              },
            );

          } else if (snapshot.hasError) {
            return noResultFound();
          } else {
            return noResultFound();
          }
        } else {
          return noResultFound();
        }

        return Center(
          child: MainHelper.appLoading(),
        );
      },
    );
  }

  clearTextField(){
    setState(() {
      userSearchController.text = '';
      searchTerm = '';
      isSearchActive = false;
    });
  }

  Widget noConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget noResultFound() {
    return Center(
      child: TextWithTap(
        'search_screen.no_result'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
        marginRight: size.width / 30,
        marginLeft: size.width / 30,
      ),
    );
  }

  watchChallengeVideo(ChallengeModel challenge) async {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());
    query.includeObject([
      VideoModel.keyAuthor,
    ]);
    query.whereEqualTo(VideoModel.keyObjectId, challenge.getAuthorVideo!.objectId);
    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        VideoModel video = parseResponse.results?.first as VideoModel;

        MainHelper.goToNavigatorScreen(context,
          WatchVideoPage(video: video, currentUser: widget.currentUser,)
        );

      }
    }else {
      MainHelper.showAppNotificationAdvanced(
          title: 'video.bad_connection'.tr(), context: context);
    }
  }
}
