// ignore_for_file: must_be_immutable

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/video_pages/watch_video_page.dart';
import 'package:challenge/models/CategoryModel.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:challenge/widgets/custome_drawer.dart';

import '../../../configurations/global_config.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import 'followers_page.dart';
import 'followings_page.dart';


class ProfilePage extends StatefulWidget {
  static String route = '/profile';
  UserModel? currentUser; // receive the current user's data

  ProfilePage({Key? key, this.currentUser}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  AnimationController? _animationController;

  int challenges = 0;
  List<dynamic> allCategories = [];

  getAllCategories() async {
    QueryBuilder<CategoryModel> query = QueryBuilder(CategoryModel());
    query.orderByAscending(CategoryModel.keyName);

    ParseResponse response = await query.query();

    if (response.success) {
      if (response.result != null) {
        setState(() {
          allCategories = response.results as List<dynamic>;
        });
      }
    }
  }

  @override
  void initState() {
    _animationController = AnimationController.unbounded(vsync: this);

    getAllCategories();
    _getUserChallenges();
    super.initState();
  }


  _getUserChallenges() async {
    QueryBuilder<ChallengeModel> query = QueryBuilder(ChallengeModel());
    query.whereEqualTo(
        ChallengeModel.keyAuthorId, widget.currentUser!.objectId);
    ParseResponse result = await query.query();

    if (result.success) {
      if (result.results != null) {
        setState(() {
          challenges = result.results!.length;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: widget.currentUser!.getIsViewer! ? 2 : 3,
      child: Scaffold(
        extendBodyBehindAppBar: true,
        endDrawer: CustomDrawer(
          currentUser: widget.currentUser,
        ),
        appBar: AppBar(
          automaticallyImplyLeading: false,
          elevation: 0,
          backgroundColor: kTransparentColor,
          actions: [
            Builder(builder: (ctx) {
              return ContainerCorner(
                onTap: () => Scaffold.of(ctx).openEndDrawer(),
                imageDecoration: "assets/images/top_btn.png",
                width: size.width / 7,
                height: size.height / 5,
              );
            }),
          ],
        ),
        body: getBody(),
      ),
    );
  }

  Widget getBody() {
    return Container(
      height: size.height,
      width: size.width,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/app_bg.png"),
          fit: BoxFit.cover,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            right: size.width / 20,
            left: size.width / 20,
          ),
          child: widget.currentUser!.getIsViewer!
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(bottom: size.height / 35),
                      child: showUserInfos(),
                    ),
                    Flexible(
                      fit: FlexFit.loose,
                      child: displayViewerTabs(),
                    ),
                  ],
                )
              : Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    showUserInfos(),
                    showProgressBar(),
                    // showMedalsAndTrophies(),
                    Flexible(
                      fit: FlexFit.loose,
                      child: displayTabs(),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  Widget line() {
    return ContainerCorner(
      borderWidth: 0.5,
      marginBottom: 7.0,
      marginTop: 7.0,
      borderColor: Colors.white,
      width: size.width,
    );
  }

  Widget button(String label,
      {double? fontSize,
      FontWeight? fontWeight,
      Widget? page,
      String? route,
      String? message,
      bool? isPoPup}) {
    return GestureDetector(
      onTap: () {
        if (page != null) {
          MainHelper.goToNavigatorScreen(
            context,
            page,
          );
        } else if (route != null) {
          MainHelper.goToNavigator(context, route);
        } else if (message != null) {
          MainHelper.showAppNotificationAdvanced(
            title: message,
            context: context,
            isError: false,
          );
        } else if (isPoPup!) {
          MainHelper.showDialogLivEend(
            context: context,
            title: 'profile_screen.market'.tr(),
            confirmButtonText: 'ok'.tr(),
            message: 'profile_screen.market_unavailable'.tr(),
            onPressed: () {
              MainHelper.hideLoadingDialog(context);
            },
          );
        }
      },
      child: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/white_btn.png'),
            fit: BoxFit.cover,
          ),
        ),
        height: size.height / 30,
        width: double.infinity,
        child: SizedBox(
          width: double.infinity,
          height: size.height / 30,
          child: TextWithTap(
            label,
            fontSize: fontSize ?? 10,
            fontWeight: fontWeight ?? FontWeight.w600,
            textAlign: TextAlign.center,
            marginTop: 7,
            color: kButtonTextColor,
          ),
        ),
      ),
    );
  }

  double getProgressPercentage(int? amount) {
    if(amount! > Config.progressBarLimit){
      return double.parse(Config.progressBarLimit.toString());
    }else{
      var coin = amount;
      return (size.width - (size.width / 10 * 2)) * coin / Config.progressBarLimit;
    }
  }

  Widget showUserInfos() {
    return Row(
      children: [
        Flexible(
          flex: 1,
          child: Padding(
            padding: const EdgeInsets.only(right: 4.0),
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:widget.currentUser!),
          ),
        ),
        Flexible(
          flex: 2,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextWithTap(
                widget.currentUser!.username!,
                fontSize: 19,
                color: kContentColorDarkTheme,
              ),
              Padding(
                padding:
                    EdgeInsets.only(right: size.width / 25, top: 6, bottom: 15),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextWithTap(
                      'profile_screen.follower'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(
                            widget.currentUser!.getFollowers!.length)
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                      onTap: () => MainHelper.goToNavigatorScreen(context,
                       FollowersPage(currentUser: widget.currentUser,
                        user: widget.currentUser,
                       )),
                    ),
                    TextWithTap(
                      'profile_screen.following'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(
                            widget.currentUser!.getFollowing!.length)
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                      onTap: () => MainHelper.goToNavigatorScreen(context,
                          FollowingsPage(currentUser: widget.currentUser,
                            user: widget.currentUser,
                          )),
                    ),
                    TextWithTap(
                      'profile_screen.challenge'.tr(namedArgs: {
                        'number': MainHelper.formatNumber(challenges)
                      }),
                      fontSize: 7.8,
                      color: kContentColorDarkTheme,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10.0),
                child: Row(
                  mainAxisAlignment: widget.currentUser!.getIsViewer!
                      ? MainAxisAlignment.start
                      : MainAxisAlignment.spaceBetween,
                  children: [
                    widget.currentUser!.getIsViewer!
                        ? const SizedBox()
                        : TextWithTap(
                            'profile_screen.point'.tr(namedArgs: {
                              'number': widget.currentUser!.getPoints.toString()
                            }),
                            fontSize: 7.6,
                            color: kContentColorDarkTheme,
                          ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        TextWithTap(
                          'CREDITS',
                          fontSize: 7.6,
                          marginRight: size.width / 17,
                          color: kContentColorDarkTheme,
                        ),
                        TextWithTap(
                          MainHelper.formatNumber(
                              widget.currentUser!.getCredits),
                          fontSize: 7.6,
                          textAlign: TextAlign.end,
                          color: kContentColorDarkTheme,
                        ),
                        Image(
                          image: const AssetImage('assets/images/coin.png'),
                          width: size.width / 26,
                          height: size.width / 26,
                        ),
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ),
      ],
    );
  }

  Widget showProgressBar() {
    return Padding(
      padding: const EdgeInsets.only(top: 13),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.only(right: size.width / 52, bottom: 4.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const TextWithTap(
                  '0',
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
                TextWithTap(
                  'profile_screen.classe'.tr(),
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
                TextWithTap(
                  Config.progressBarLimit.toString(),
                  fontSize: 7.8,
                  color: kContentColorDarkTheme,
                ),
              ],
            ),
          ),
          ContainerCorner(
            borderColor: kProfileProgressbarColor,
            borderWidth: 2,
            color: kTransparentColor,
            height: size.width / 17,
            child: Row(
              children: [
                ContainerCorner(
                  alignment: Alignment.centerLeft,
                  color: kProfileProgressbarColor,
                  height: size.width / 17,
                  width: getProgressPercentage(
                      widget.currentUser!.getPoints),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget showMedalsAndTrophies() {
    return Padding(
      padding: const EdgeInsets.only(top: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextWithTap(
                'profile_screen.medals'.tr(),
                fontSize: 13,
                marginRight: size.width / 15,
                fontWeight: FontWeight.bold,
                color: kContentColorDarkTheme,
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width * 0.64,
                      height: size.height / 20,
                      child: ListView.builder(
                        itemCount: widget.currentUser!.getMedals ?? 0,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.only(right: size.width / 25),
                            child: SvgPicture.asset(
                              'assets/svg/medal.svg',
                              width: size.width / 16,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 4.0,
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TextWithTap(
                'profile_screen.trophy'.tr(),
                fontSize: 13,
                marginRight: size.width / 15,
                fontWeight: FontWeight.bold,
                color: kContentColorDarkTheme,
              ),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: size.width * 0.64,
                      height: size.height / 20,
                      child: ListView.builder(
                        itemCount: widget.currentUser!.getTrophy ?? 0,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Padding(
                            padding: EdgeInsets.only(right: size.width / 25),
                            child: SvgPicture.asset(
                              'assets/svg/trophy.svg',
                              width: size.width / 16,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget displayTabs() {
    return Padding(
      padding: EdgeInsets.only(
        right: size.width / 44,
        left: size.width / 44,
      ),
      child: Column(
        children: [
          line(),
          TabBar(indicatorColor: Colors.transparent, tabs: [
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-1.png',
            ),
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-2.png',
            ),
            /*ContainerCorner(
              width: size.width / 2,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-3.png',
            ),*/
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-4.png',
            ),
          ]),
          line(),
          Flexible(
            child: TabBarView(
              children: [
                allUserVideos(),
                moreUserInfo(),
                // const TextWithTap(''),
                allSavedVideos(),
            ]),
          )
        ],
      ),
    );
  }

  Widget displayViewerTabs() {
    return Padding(
      padding: EdgeInsets.only(
        right: size.width / 44,
        left: size.width / 44,
      ),
      child: Column(
        children: [
          line(),
          TabBar(indicatorColor: Colors.transparent, tabs: [
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-2.png',
            ),
            ContainerCorner(
              width: size.width / 6,
              height: size.width / 5.5,
              imageDecoration: 'assets/images/tab-4.png',
            ),
          ]),
          line(),
          Flexible(
            child: TabBarView(children: [
              moreUserInfo(),
              allSavedVideos(),
            ]),
          )
        ],
      ),
    );
  }

  Widget allSavedVideos() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereContainedIn(
        VideoModel.keyObjectId, widget.currentUser!.getSaves!);
    query.orderByDescending(VideoModel.keyCreatedAt);

    return ParseLiveGridWidget<VideoModel>(
      query: query,
      crossAxisCount: 3,
      reverse: false,
      crossAxisSpacing: 2,
      mainAxisSpacing: 2,
      lazyLoading: false,
      childAspectRatio: .7,
      scrollPhysics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      animationController: _animationController,
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {
          return noConnectedMessage();
        } else if (snapshot.hasData) {
          VideoModel video = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              WatchVideoPage(
                currentUser: widget.currentUser!,
                video: video,
              ),
            ),
            child: Stack(children: [
              ActionsHelper.videoThumbnailWidget(
                  video, size.width * 0.5, size.height * 0.6),
              ContainerCorner(
                height: size.height * 0.6,
                width: size.width * 0.5,
                color: Colors.black.withOpacity(0.5),
              ),
              Center(
                child: SvgPicture.asset(
                  'assets/svg/ic_video_play.svg',
                  width: size.width / 4.5,
                  height: size.width / 4.5,
                  color:Colors.white,
                ),
              ),
              Positioned(
                bottom: 2.0,
                left: 5.0,
                right: 5.0,
                child: SizedBox(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextWithTap(
                          MainHelper.formatNumber(video.getViewsCount),
                          color:Colors.white,
                          fontSize: 14,
                          marginRight: 0,
                        ),
                        const Icon(
                          Icons.play_arrow_outlined,
                          size: 18,
                          color:Colors.white,
                        )
                      ]
                  ),),
              ),
            ]),
          );
        } else {
          return Center(
            child: MainHelper.appLoading(),
          );
        }
      },
      queryEmptyElement: noVideosMessage(),
      gridLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  Widget allUserVideos() {
    QueryBuilder<VideoModel> query = QueryBuilder<VideoModel>(VideoModel());

    query.includeObject([
      VideoModel.keyAuthor,
    ]);

    query.whereEqualTo(
        VideoModel.keyCurrentState, VideoModel.videoCurrentStatePublished);
    query.whereEqualTo(VideoModel.keyAuthor, widget.currentUser);
    query.orderByDescending(VideoModel.keyCreatedAt);

    return ParseLiveGridWidget<VideoModel>(
      query: query,
      crossAxisCount: 3,
      reverse: false,
      crossAxisSpacing: 2,
      mainAxisSpacing: 2,
      lazyLoading: false,
      childAspectRatio: .7,
      scrollPhysics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      duration: const Duration(milliseconds: 200),
      animationController: _animationController,
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<VideoModel> snapshot) {
        if (snapshot.failed) {
          return noConnectedMessage();
        } else if (snapshot.hasData) {
          VideoModel video = snapshot.loadedData!;
          return GestureDetector(
            onTap: () => MainHelper.goToNavigatorScreen(
              context,
              WatchVideoPage(
                currentUser: widget.currentUser!,
                video: video,
              ),
            ),
            child: Stack(children: [
              ActionsHelper.videoThumbnailWidget(
                  video, size.width * 0.5, size.height * 0.6),
              ContainerCorner(
                height: size.height * 0.6,
                width: size.width * 0.5,
                color: Colors.black.withOpacity(0.5),
              ),
              Center(
                child: SvgPicture.asset(
                  'assets/svg/ic_video_play.svg',
                  width: size.width / 4.5,
                  height: size.width / 4.5,
                  color:Colors.white,
                ),
              ),
              Positioned(
                bottom: 2.0,
                left: 5.0,
                right: 5.0,
                child: SizedBox(
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextWithTap(
                          MainHelper.formatNumber(video.getViewsCount ?? 0),
                          color:Colors.white,
                          fontSize: 14,
                          marginRight: 0,
                        ),
                        const Icon(
                          Icons.play_arrow_outlined,
                          size: 18,
                          color:Colors.white,
                        )
                      ]
                  ),),
              ),
            ]),
          );
        } else {
          return Center(
            child: MainHelper.appLoading(),
          );
        }
      },
      queryEmptyElement: noVideosMessage(),
      gridLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  Widget noVideosMessage() {
    return Center(
      child: TextWithTap(
        'profile_screen.no_videos'.tr(),
        fontSize: 17,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget moreUserInfo() {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextWithTap(
            widget.currentUser!.getAboutYou == ''
                ? widget.currentUser!.getBio.toString()
                : widget.currentUser!.getAboutYou.toString(),
            color: kContentColorDarkTheme,
            fontSize: 17,
            fontWeight: FontWeight.bold,
            marginBottom: 30,
          ),
          TextWithTap(
            widget.currentUser!.getFullName.toString(),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginBottom: 10,
          ),
          Visibility(
            visible: allCategories.isNotEmpty,
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: List.generate(allCategories.length, (index) {
                  CategoryModel category = allCategories[index];
                  return TextWithTap(
                    widget.currentUser!.getCategories!
                                .contains(category.objectId) ||
                            widget.currentUser!.getCategories!
                                .contains(category.getCode)
                        ? '${category.getName!} '
                        : '',
                    color: kContentColorDarkTheme,
                    fontSize: 15,
                  );
                }),
              ),
            ),
          ),
          TextWithTap(
            MainHelper.getFilmList(widget.currentUser!.getFavoriteFilm!),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
          TextWithTap(
            MainHelper.getHobbyList(widget.currentUser!.getHobby!),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
          TextWithTap(
            widget.currentUser!.getJobTitle.toString(),
            color: kContentColorDarkTheme,
            fontSize: 15,
            marginTop: 10,
          ),
        ],
      ),
    );
  }

  Widget noConnectedMessage() {
    return Center(
      child: TextWithTap(
        'not_connected'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }
}
