import 'package:flutter/material.dart';
import 'package:flutter_polygon_clipper/flutter_polygon_clipper.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/message_pages/group_creation_page.dart';
import 'package:challenge/pages/home/message_pages/message_goup_page.dart';
import 'package:challenge/pages/home/stories_page/see_stories_page.dart';
import 'package:challenge/pages/home/stories_page/story_type_chooser_page.dart';
import 'package:challenge/models/LocalMessagesModel.dart';
import 'package:challenge/models/MessageListModel.dart';
import 'package:challenge/models/MessageModel.dart';
import 'package:challenge/models/StoriesAuthorsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:challenge/widgets/custom_widgets/button_widget.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:localstorage/localstorage.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';
import 'message_page.dart';

class MessagesListPage extends StatefulWidget {
  static const String route = '/home/messages';
  final UserModel? currentUser;

  const MessagesListPage({Key? key, this.currentUser}) : super(key: key);

  @override
  State<MessagesListPage> createState() => _MessagesListPageState();
}

class _MessagesListPageState extends State<MessagesListPage>
    with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;

  LocalStoredListMessages listMessages = LocalStoredListMessages();
  LocalStoredMessages messagesToStore = LocalStoredMessages();
  LocalStorage localStorage = LocalStorage("messages");
  bool initialized = false;

  int tabsLength = 2;
  int tabMessages = 0;
  int tabGroupMessages = 1;
  late TabController _tabController;
  int tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _getAllAuthors();
    _tabController = TabController(vsync: this, length: tabsLength)
      ..addListener(() {
        setState(() {
          tabIndex = _tabController.index;
        });
      });
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Stack(
      children: [
        ContainerCorner(
          borderWidth: 0,
          height: size.height,
          width: size.width,
          imageDecoration: "assets/images/app_bg.png",
        ),
        Scaffold(
          backgroundColor: kTransparentColor,
          appBar: AppBar(
            backgroundColor: kTransparentColor,
            bottom: TabBar(
              isScrollable: true,
              enableFeedback: false,
              controller: _tabController,
              indicatorColor: Colors.transparent,
              unselectedLabelColor: kTabIconDefaultColor,
              labelColor: kTabIconSelectedColor,
              labelStyle: const TextStyle(fontWeight: FontWeight.bold),
              labelPadding: const EdgeInsets.only(right: 14),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500),
              tabs: [
                tabsRows("message_screen.messages_", tabMessages,
                    const Icon(Icons.supervisor_account)),
                tabsRows(
                    "message_screen.groups_",
                    tabGroupMessages,
                    SvgPicture.asset(
                      "assets/svg/ic_followers_active.svg",
                      color: kPrimaryColor,
                    )),
              ],
            ),
            automaticallyImplyLeading: false,
            toolbarHeight: 70,
            centerTitle: true,
            title: TextWithTap(
              "chat_".tr(),
              color: Colors.white,
              fontSize: 30,
              fontWeight: FontWeight.w900,
            ),
            actions: [
              TextButton(
                onPressed: () => MainHelper.goToNavigatorScreen(
                    context,
                    GroupCreationPage(
                      currentUser: widget.currentUser,
                    )),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(
                      Icons.group_add,
                      color: Colors.white,
                    ),
                  ],
                ),
              )
            ],
            leadingWidth: 80,
          ),
          body: TabBarView(controller: _tabController, children: [
            ListView(
              children: [
                TextWithTap(
                  "message_screen.stories".tr(),
                  color: Colors.white,
                  fontSize: 20,
                  marginLeft: 10,
                  fontWeight: FontWeight.w900,
                ),
                ContainerCorner(
                  height: size.height * 0.1,
                  child: Center(
                    child: Row(
                      children: [
                        Expanded(child: _getAllStories())
                      ],
                    ),
                  ),
                ),
                ContainerCorner(child: loadMessages(widget.currentUser!)),
              ],
            ),
            ListView(
              children: [
                ContainerCorner(
                  child: loadGroupMessages(widget.currentUser!),
                ),
              ],
            )
          ]),
        ),
      ],
    );
  }

  Widget tabsRows(String title, int position, Widget icon) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const SizedBox(width: 6),
        TextWithTap(
          title.tr(),
          color: tabIndex == position
              ? Colors.white
              : Colors.white.withOpacity(0.4),
          fontSize: 20,
          marginLeft: 10,
          fontWeight: FontWeight.w900,
        ),
      ],
    );
  }

  List<StoriesAuthorsModel> authorsList = [];
  int startIndex = 0;

  _getAllAuthors() async {
    QueryBuilder<StoriesAuthorsModel> query =
        QueryBuilder<StoriesAuthorsModel>(StoriesAuthorsModel());

    query.includeObject([
      StoriesAuthorsModel.keyAuthor,
      StoriesAuthorsModel.keyLastStory,
      StoriesAuthorsModel.keyStoriesList,
    ]);

    query.whereGreaterThan(
        StoriesAuthorsModel.keyLastStoryExpiration, DateTime.now());
    query.orderByAscending(StoriesAuthorsModel.keyLastStorySeen);

    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.result != null) {
        for (StoriesAuthorsModel storyAuthorModel in parseResponse.results!) {
          if (!authorsList.contains(storyAuthorModel)) {
            authorsList.add(storyAuthorModel);
          }
        }
      }
    }
  }

  Widget loadGroupMessages(UserModel currentUser) {
    QueryBuilder<MessageListModel> queryBuilder =
        QueryBuilder<MessageListModel>(MessageListModel());

    queryBuilder.whereContainedIn(
        MessageListModel.keyMembersIDs, [widget.currentUser!.objectId!]);
    queryBuilder.orderByDescending(MessageListModel.keyUpdatedAt);

    queryBuilder.includeObject([
      MessageListModel.keyAuthor,
      MessageListModel.keyReceiver,
      MessageListModel.keyMessage,
      MessageListModel.keyCall,
      MessageListModel.keyGroupReceiver
    ]);

    return ParseLiveListWidget<MessageListModel>(
      query: queryBuilder,
      reverse: false,
      lazyLoading: true,
      listenOnAllSubItems: true,
      shrinkWrap: true,
      scrollPhysics: const NeverScrollableScrollPhysics(),
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<ParseObject> snapshot) {
        if (snapshot.hasData) {
          MessageListModel chatMessage =
              snapshot.loadedData! as MessageListModel;

          UserModel chatUser = chatMessage.getAuthorId! == currentUser.objectId!
              ? chatMessage.getReceiver != null
                  ? chatMessage.getReceiver!
                  : currentUser
              : chatMessage.getAuthor!;

          bool isMe =
              chatMessage.getAuthorId! == currentUser.objectId! ? true : false;

          return ButtonWidget(
            height: 50,
            onTap: () {
              MainHelper.goToNavigatorScreen(
                  context,
                  GroupMessagePage(
                    currentUser: currentUser,
                    groupModel: chatMessage.getGroupReceiver,
                  ));
            },
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (chatMessage.getMessageType ==
                          MessageModel.messageGroupNotify ||
                      chatMessage.getMessageType ==
                          MessageModel.textMessageForGroup ||
                      chatMessage.getMessageType ==
                          MessageModel.pictureMessageForGroup)
                    ActionsHelper.groupCover(chatMessage.getGroupReceiver!),
                  if (chatMessage.getMessageType !=
                          MessageModel.messageGroupNotify &&
                      chatMessage.getMessageType !=
                          MessageModel.textMessageForGroup &&
                      chatMessage.getMessageType !=
                          MessageModel.pictureMessageForGroup)

                    ContainerCorner(
                        height: 50,
                        width: 50,
                        child: ActionsHelper.polygonAvatarWidget(
                            currentUser:chatUser,
                            fontSize: 20,),),
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (chatMessage.getGroupReceiverId == null)
                              TextWithTap(
                                chatUser.getFullName!,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                marginLeft: 10,
                                color: Colors.white,
                                marginTop: 5,
                                marginRight: 5,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                            if (chatMessage.getGroupReceiverId != null)
                              TextWithTap(
                                chatMessage.getGroupReceiver!.getGroupName!,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                marginLeft: 10,
                                color: Colors.white,
                                marginRight: 5,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                        Row(
                          children: [
                            Visibility(
                              visible: chatMessage.getAuthorId ==
                                      currentUser.objectId &&
                                  chatMessage.getMessageType !=
                                      MessageModel.messageTypeCall &&
                                  chatMessage.getMessageType !=
                                      MessageModel.messageGroupNotify &&
                                  chatMessage.getMessageType ==
                                      MessageModel.textMessageForGroup &&
                                  chatMessage.getMessageType ==
                                      MessageModel.pictureMessageForGroup,
                              child: Padding(
                                padding:
                                    const EdgeInsets.only(top: 7, left: 10),
                                child: SvgPicture.asset(
                                  "assets/svg/ic_sent_message.svg",
                                  color: kGrayColor,
                                ),
                              ),
                            ),
                            if (chatMessage.getMessageType ==
                                    MessageModel.messageGroupNotify ||
                                chatMessage.getMessageType ==
                                    MessageModel.textMessageForGroup ||
                                chatMessage.getMessageType ==
                                    MessageModel.pictureMessageForGroup)
                              Row(
                                children: [
                                  if (chatMessage.getAuthor!.objectId ==
                                      widget.currentUser!.objectId)
                                    TextWithTap(
                                      "you_".tr(),
                                      marginTop: 5,
                                      marginLeft: 10,
                                      color: !chatMessage.isRead! && !isMe
                                          ? Colors.redAccent
                                          : kGrayColor,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  if (chatMessage.getAuthor!.objectId !=
                                      widget.currentUser!.objectId)
                                    TextWithTap(
                                      "${chatMessage.getAuthor!.getFirstName!.toUpperCase()}:",
                                      marginTop: 5,
                                      marginLeft: 10,
                                      color: !chatMessage.isRead! && !isMe
                                          ? Colors.redAccent
                                          : kGrayColor,
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  TextWithTap(
                                    chatMessage.getText!.substring(
                                      0, chatMessage.getText!.length > 10
                                        ? 10
                                        :chatMessage.getText!.length
                                    ),
                                    marginTop: 5,
                                    marginLeft: 5,
                                    color: !chatMessage.isRead! && !isMe
                                        ? Colors.redAccent
                                        : kGrayColor,
                                    overflow: TextOverflow.ellipsis,
                                    maxLines: 1,
                                    fontWeight:
                                        !chatMessage.isRead! && !isMe
                                            ? FontWeight.bold
                                            : FontWeight.normal,
                                  ),
                                ],
                              ),
                            if (chatMessage.getMessageType ==
                                MessageModel.messageTypeText)
                              ContainerCorner(
                                width:
                                    MediaQuery.of(context).size.width / 1.9,
                                child: TextWithTap(
                                  chatMessage.getText!,
                                  marginTop: 5,
                                  marginLeft: 10,
                                  color: !chatMessage.isRead! && !isMe
                                      ? Colors.redAccent
                                      : kGrayColor,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  fontWeight: !chatMessage.isRead! && !isMe
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                            if (chatMessage.getMessageType ==
                                MessageModel.messageTypeGif)
                              ContainerCorner(
                                child: Row(
                                  children: const [
                                    Padding(
                                      padding: EdgeInsets.only(left: 5),
                                      child: Icon(
                                        Icons.attach_file,
                                        size: 16,
                                        color: kGrayColor,
                                      ),
                                    ),
                                    Icon(
                                      Icons.gif,
                                      size: 40,
                                      color: kGrayColor,
                                    ),
                                  ],
                                ),
                              ),
                            if (chatMessage.getMessageType ==
                                MessageModel.messageStoryReply)
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 5, top: 8),
                                    child: SvgPicture.asset(
                                      "assets/svg/estados_selected.svg",
                                      color: kPrimaryColor,
                                      height: 12,
                                      width: 12,
                                    ),
                                  ),
                                  TextWithTap(
                                    "stories.story_reply".tr(),
                                    color: kGrayColor,
                                    marginLeft: 5,
                                    marginTop: 7,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            if (chatMessage.getMessageType ==
                                MessageModel.messageTypePicture)
                              ContainerCorner(
                                child: Row(
                                  children: [
                                    const Padding(
                                      padding:
                                          EdgeInsets.only(top: 8, left: 5),
                                      child: Icon(
                                        Icons.photo_camera,
                                        size: 20,
                                        color: kGrayColor,
                                      ),
                                    ),
                                    TextWithTap(
                                      MessageModel.messageTypePicture,
                                      marginTop: 5,
                                      marginLeft: 5,
                                      color: !chatMessage.isRead! && !isMe
                                          ? Colors.redAccent
                                          : kGrayColor,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      fontSize: 17,
                                      fontWeight:
                                          !chatMessage.isRead! && !isMe
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                    ),
                                  ],
                                ),
                              ),
                            if (chatMessage.getMessageType ==
                                MessageModel.messageTypeCall)
                              ContainerCorner(
                                child: Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 8, left: 5),
                                      child: Icon(
                                        chatMessage.getCall!.getAuthorId ==
                                                currentUser.objectId!
                                            ? Icons.call_made
                                            : Icons.call_received,
                                        size: 20,
                                        color: kGrayColor,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 8, left: 5),
                                      child: Icon(
                                        chatMessage.getCall!.getIsVoiceCall!
                                            ? Icons.call
                                            : Icons.videocam,
                                        size: 24,
                                        color: kGrayColor,
                                      ),
                                    ),
                                    TextWithTap(
                                      chatMessage.getCall!.getAccepted!
                                          ? chatMessage
                                              .getCall!.getDuration!
                                          : "push_notifications.missed_call_title"
                                              .tr(),
                                      marginTop: 5,
                                      marginLeft: 5,
                                      color: !chatMessage.isRead! && !isMe
                                          ? Colors.redAccent
                                          : kGrayColor,
                                      overflow: TextOverflow.ellipsis,
                                      fontSize: 17,
                                      maxLines: 1,
                                      fontWeight:
                                          !chatMessage.isRead! && !isMe
                                              ? FontWeight.bold
                                              : FontWeight.normal,
                                    ),
                                  ],
                                ),
                              )
                          ],
                        ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWithTap(
                            MainHelper.getMessageListTime(
                                chatMessage.updatedAt!),
                            marginLeft: 5,
                            marginRight: 5,
                            marginBottom: 5,
                            color: kGrayColor,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                      !chatMessage.isRead! && !isMe
                          ? ContainerCorner(
                              borderRadius: 100,
                              color: kRedColor1,
                              marginRight: 5,
                              child: TextWithTap(
                                chatMessage.getCounter.toString(),
                                color: Colors.white,
                                marginRight: 5,
                                marginTop: 2,
                                marginLeft: 5,
                                marginBottom: 2,
                                fontSize: 11,
                              ),
                            )
                          : Container(),
                    ],
                  ),
                ],
              ),
            ),
          );
        } else {
          return Container();
        }
      },
      queryEmptyElement: noMessage(),
      listLoadingElement: ContainerCorner(
        width: size.width,
        height: size.height * 0.7,
        child: Center(
          child: MainHelper.appLoading(),
        ),
      ),
    );
  }

  Widget loadMessages(UserModel currentUser) {
    QueryBuilder<MessageListModel> queryFrom =
        QueryBuilder<MessageListModel>(MessageListModel());

    queryFrom.whereEqualTo(MessageListModel.keyAuthorId, currentUser.objectId!);
    queryFrom.whereValueExists(MessageListModel.keyGroupReceiverId, false);

    QueryBuilder<MessageListModel> queryTo =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryTo.whereEqualTo(MessageListModel.keyReceiverId, currentUser.objectId!);

    QueryBuilder<MessageListModel> queryBuilder =
        QueryBuilder.or(MessageListModel(), [queryFrom, queryTo]);

    queryBuilder.orderByDescending(MessageListModel.keyUpdatedAt);

    queryBuilder.includeObject([
      MessageListModel.keyAuthor,
      MessageListModel.keyReceiver,
      MessageListModel.keyMessage,
      MessageListModel.keyCall,
      MessageListModel.keyGroupReceiver
    ]);

    return ParseLiveListWidget<MessageListModel>(
      query: queryBuilder,
      reverse: false,
      lazyLoading: true,
      listenOnAllSubItems: true,
      shrinkWrap: true,
      scrollPhysics: const NeverScrollableScrollPhysics(),
      duration: const Duration(milliseconds: 200),
      childBuilder: (BuildContext context,
          ParseLiveListElementSnapshot<ParseObject> snapshot) {
        if (snapshot.hasData) {
          MessageListModel chatMessage =
              snapshot.loadedData! as MessageListModel;

          UserModel chatUser = chatMessage.getAuthorId! == currentUser.objectId!
              ? chatMessage.getReceiver != null
                  ? chatMessage.getReceiver!
                  : currentUser
              : chatMessage.getAuthor!;

          bool isMe =
              chatMessage.getAuthorId! == currentUser.objectId! ? true : false;

          return ButtonWidget(
            height: 50,
            onTap: () {
              if (chatMessage.getMessageType ==
                      MessageModel.messageGroupNotify ||
                  chatMessage.getMessageType ==
                      MessageModel.textMessageForGroup ||
                  chatMessage.getMessageType ==
                      MessageModel.pictureMessageForGroup) {
                MainHelper.goToNavigatorScreen(
                    context,
                    GroupMessagePage(
                      currentUser: currentUser,
                      groupModel: chatMessage.getGroupReceiver,
                    ));
              } else {
                if(currentUser.getBlockedUsersIDs!.contains(chatUser.objectId)){
                  MainHelper.showAppNotificationAdvanced(
                    context: context,
                    title: 'Unable to access messages',
                    message: "You've blocked this user, unblock him to chat!"
                  );
                }else if(chatUser.getBlockedUsersIDs!.contains(currentUser.objectId)){
                  MainHelper.showAppNotificationAdvanced(
                    context: context,
                    title: 'Unable to access messages',
                    message: "You've been blocked by this user!"
                  );
                }else{
                  MainHelper.goToNavigatorScreen(
                    context,
                    MessagePage(
                      currentUser: currentUser,
                      mUser: chatUser,
                    ),
                  );
                }
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (chatMessage.getMessageType ==
                          MessageModel.messageGroupNotify ||
                      chatMessage.getMessageType ==
                          MessageModel.textMessageForGroup ||
                      chatMessage.getMessageType ==
                          MessageModel.pictureMessageForGroup)
                    ActionsHelper.groupCover(chatMessage.getGroupReceiver!),
                  if (chatMessage.getMessageType !=
                          MessageModel.messageGroupNotify &&
                      chatMessage.getMessageType !=
                          MessageModel.textMessageForGroup &&
                      chatMessage.getMessageType !=
                          MessageModel.pictureMessageForGroup)
                    ContainerCorner(
                      height: 50,
                      width: 50,
                      child: ActionsHelper.polygonAvatarWidget(
                        currentUser: chatUser,
                        fontSize: 20,),),
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (chatMessage.getGroupReceiverId == null)
                              TextWithTap(
                                chatUser.getFullName!,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                marginLeft: 10,
                                color: Colors.white,
                                marginTop: 5,
                                marginRight: 5,
                              ),
                            if (chatMessage.getGroupReceiverId != null)
                              TextWithTap(
                                chatMessage.getGroupReceiver!.getGroupName!,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                marginLeft: 10,
                                color: MainHelper.isDarkMode(context)
                                    ? Colors.white
                                    : Colors.black,
                                marginRight: 5,
                              ),
                            Row(
                              children: [
                                Visibility(
                                  visible: chatMessage.getAuthorId ==
                                          currentUser.objectId &&
                                      chatMessage.getMessageType !=
                                          MessageModel.messageTypeCall &&
                                      chatMessage.getMessageType !=
                                          MessageModel.messageGroupNotify &&
                                      chatMessage.getMessageType ==
                                          MessageModel.textMessageForGroup &&
                                      chatMessage.getMessageType ==
                                          MessageModel.pictureMessageForGroup,
                                  child: Padding(
                                    padding:
                                        const EdgeInsets.only(top: 7, left: 10),
                                    child: SvgPicture.asset(
                                      "assets/svg/ic_sent_message.svg",
                                      color: kGrayColor,
                                    ),
                                  ),
                                ),
                                if (chatMessage.getMessageType ==
                                        MessageModel.messageGroupNotify ||
                                    chatMessage.getMessageType ==
                                        MessageModel.textMessageForGroup ||
                                    chatMessage.getMessageType ==
                                        MessageModel.pictureMessageForGroup)
                                  ContainerCorner(
                                    width:
                                        MediaQuery.of(context).size.width / 1.5,
                                    child: Row(
                                      children: [
                                        if (chatMessage.getAuthor!.objectId ==
                                            widget.currentUser!.objectId)
                                          TextWithTap(
                                            "you_".tr(),
                                            marginTop: 5,
                                            marginLeft: 10,
                                            color: !chatMessage.isRead! && !isMe
                                                ? Colors.redAccent
                                                : kGrayColor,
                                            overflow: TextOverflow.ellipsis,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        if (chatMessage.getAuthor!.objectId !=
                                            widget.currentUser!.objectId)
                                          TextWithTap(
                                            "${chatMessage.getAuthor!.getFirstName!.toUpperCase()}:",
                                            marginTop: 5,
                                            marginLeft: 10,
                                            color: !chatMessage.isRead! && !isMe
                                                ? Colors.redAccent
                                                : kGrayColor,
                                            overflow: TextOverflow.ellipsis,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        TextWithTap(
                                          chatMessage.getText!.substring(
                                              0, chatMessage.getText!.length > 10
                                              ? 10
                                              :chatMessage.getText!.length
                                          ),
                                          marginTop: 5,
                                          marginLeft: 10,
                                          color: !chatMessage.isRead! && !isMe
                                              ? Colors.redAccent
                                              : kGrayColor,
                                          overflow: TextOverflow.ellipsis,
                                          fontWeight:
                                              !chatMessage.isRead! && !isMe
                                                  ? FontWeight.bold
                                                  : FontWeight.normal,
                                        ),
                                      ],
                                    ),
                                  ),
                                if (chatMessage.getMessageType ==
                                    MessageModel.messageTypeText)
                                  ContainerCorner(
                                    width:
                                        MediaQuery.of(context).size.width / 1.9,
                                    child: TextWithTap(
                                      chatMessage.getText!,
                                      marginTop: 5,
                                      marginLeft: 10,
                                      color: !chatMessage.isRead! && !isMe
                                          ? Colors.redAccent
                                          : kGrayColor,
                                      overflow: TextOverflow.ellipsis,
                                      fontWeight: !chatMessage.isRead! && !isMe
                                          ? FontWeight.bold
                                          : FontWeight.normal,
                                    ),
                                  ),
                                if (chatMessage.getMessageType ==
                                    MessageModel.messageTypeGif)
                                  ContainerCorner(
                                    child: Row(
                                      children: const [
                                        Padding(
                                          padding: EdgeInsets.only(left: 5),
                                          child: Icon(
                                            Icons.attach_file,
                                            size: 16,
                                            color: kGrayColor,
                                          ),
                                        ),
                                        Icon(
                                          Icons.gif,
                                          size: 40,
                                          color: kGrayColor,
                                        ),
                                      ],
                                    ),
                                  ),
                                if (chatMessage.getMessageType ==
                                    MessageModel.messageStoryReply)
                                  Row(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            left: 5, top: 8),
                                        child: SvgPicture.asset(
                                          "assets/svg/estados_selected.svg",
                                          color: kPrimaryColor,
                                          height: 12,
                                          width: 12,
                                        ),
                                      ),
                                      TextWithTap(
                                        "stories.story_reply".tr(),
                                        color: kGrayColor,
                                        marginLeft: 5,
                                        marginTop: 7,
                                      ),
                                    ],
                                  ),
                                if (chatMessage.getMessageType ==
                                    MessageModel.messageTypePicture)
                                  ContainerCorner(
                                    child: Row(
                                      children: [
                                        const Padding(
                                          padding:
                                              EdgeInsets.only(top: 8, left: 5),
                                          child: Icon(
                                            Icons.photo_camera,
                                            size: 20,
                                            color: kGrayColor,
                                          ),
                                        ),
                                        TextWithTap(
                                          MessageModel.messageTypePicture,
                                          marginTop: 5,
                                          marginLeft: 5,
                                          color: !chatMessage.isRead! && !isMe
                                              ? Colors.redAccent
                                              : kGrayColor,
                                          overflow: TextOverflow.ellipsis,
                                          fontSize: 17,
                                          fontWeight:
                                              !chatMessage.isRead! && !isMe
                                                  ? FontWeight.bold
                                                  : FontWeight.normal,
                                        ),
                                      ],
                                    ),
                                  ),
                                if (chatMessage.getMessageType ==
                                    MessageModel.messageTypeCall)
                                  ContainerCorner(
                                    child: Row(
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 8, left: 5),
                                          child: Icon(
                                            chatMessage.getCall!.getAuthorId ==
                                                    currentUser.objectId!
                                                ? Icons.call_made
                                                : Icons.call_received,
                                            size: 20,
                                            color: kGrayColor,
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 8, left: 5),
                                          child: Icon(
                                            chatMessage.getCall!.getIsVoiceCall!
                                                ? Icons.call
                                                : Icons.videocam,
                                            size: 24,
                                            color: kGrayColor,
                                          ),
                                        ),
                                        TextWithTap(
                                          chatMessage.getCall!.getAccepted!
                                              ? chatMessage
                                                  .getCall!.getDuration!
                                              : "push_notifications.missed_call_title"
                                                  .tr(),
                                          marginTop: 5,
                                          marginLeft: 5,
                                          color: !chatMessage.isRead! && !isMe
                                              ? Colors.redAccent
                                              : kGrayColor,
                                          overflow: TextOverflow.ellipsis,
                                          fontSize: 17,
                                          fontWeight:
                                              !chatMessage.isRead! && !isMe
                                                  ? FontWeight.bold
                                                  : FontWeight.normal,
                                        ),
                                      ],
                                    ),
                                  )
                              ],
                            ),
                          ],
                        )),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextWithTap(
                            MainHelper.getMessageListTime(
                                chatMessage.updatedAt!),
                            marginLeft: 5,
                            marginRight: 5,
                            marginBottom: 5,
                            color: kGrayColor,
                          ),
                        ],
                      ),
                      !chatMessage.isRead! && !isMe
                          ? ContainerCorner(
                              borderRadius: 100,
                              color: kRedColor1,
                              marginRight: 5,
                              child: TextWithTap(
                                chatMessage.getCounter.toString(),
                                color: Colors.white,
                                marginRight: 5,
                                marginTop: 2,
                                marginLeft: 5,
                                marginBottom: 2,
                                fontSize: 11,
                              ),
                            )
                          : Container(),
                    ],
                  ),
                ],
              ),
            ),
          );
        } else {
          return Container();
        }
      },
      queryEmptyElement: noMessage(),
      listLoadingElement: Center(
        child: MainHelper.appLoading(),
      ),
    );
  }

  Widget noMessage() {
    return Center(
      child: TextWithTap(
        'message_screen.no_message'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        marginTop: size.height * 0.17,
        color:Colors.white,
      ),
    );
  }

  Widget _getAllStories()       {
    QueryBuilder<StoriesAuthorsModel> query =
    QueryBuilder<StoriesAuthorsModel>(StoriesAuthorsModel());

    query.whereGreaterThan(
        StoriesAuthorsModel.keyLastStoryExpiration, DateTime.now());
    query.orderByAscending(StoriesAuthorsModel.keyLastStorySeen);

    query.includeObject([
      StoriesAuthorsModel.keyAuthor,
      StoriesAuthorsModel.keyLastStory,
      StoriesAuthorsModel.keyStoriesList,
    ]);

    return Padding(
      padding: const EdgeInsets.only(left: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: ContainerCorner(
          width: size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    StoryTypeChooserPage(
                      currentUser: widget.currentUser,
                    )),
                child: Stack(
                  alignment: AlignmentDirectional.center,
                  children: [
                    ContainerCorner(
                      height: 60,
                      width: 60,
                      child: ActionsHelper.polygonAvatarWidget(
                          currentUser:widget.currentUser!,
                        fontSize: 10
                      ),
                    ),
                    ContainerCorner(
                      height: 60,
                      width: 60,
                      child: FlutterClipPolygon(
                        sides: 6,
                        borderRadius: 0.0, // Defaults to 0.0 degrees
                        rotate: 0.0, // Defaults to 0.0 degree,
                        child: const ContainerCorner(
                          alignment: Alignment.topCenter,
                          borderWidth: 0,
                          /*marginLeft: 10,
                          marginTop: 4,*/
                          color: Colors.black45,
                          // borderRadius: 50,
                          height: 50,
                          width: 50,
                          borderColor: kPrimaryColor,
                          child: Center(
                              child: TextWithTap("+",
                                  color: kContentColorDarkTheme, fontSize: 28)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ContainerCorner(
                  width: size.width * 0.7,
                  height: 80,
                  child: ParseLiveListWidget<StoriesAuthorsModel>(
                    query: query,
                    reverse: false,
                    lazyLoading: false,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    duration: const Duration(milliseconds: 200),
                    childBuilder: (BuildContext context,
                        ParseLiveListElementSnapshot<StoriesAuthorsModel>
                        snapshot) {
                      if (snapshot.hasData) {
                        StoriesAuthorsModel storyAuthor = snapshot.loadedData!;

                        return GestureDetector(
                          onTap: () {
                            for (int i = 0; i < authorsList.length; i++) {
                              if (authorsList[i].objectId ==
                                  storyAuthor.objectId) {
                                startIndex = i;
                              }
                            }

                            MainHelper.goToNavigatorScreen(
                                context,
                                SeeStoriesPage(
                                  currentUser: widget.currentUser,
                                  storyAuthorPre: storyAuthor,
                                  authorsList: authorsList,
                                  firstUserIndex: startIndex,
                                  backPageIndex: 3,
                                ));
                          },
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(8.0, 0, 8.0, 0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                ContainerCorner(
                                    height: 60,
                                    width: 60,
                                    child: ActionsHelper.polygonAvatarWidget(
                                        currentUser:storyAuthor.getAuthor!,
                                        fontSize: 20,
                                        width: 55,
                                        height: 55)),
                              ],
                            ),
                          ),
                        );
                      } else {
                        return Center(
                          child: MainHelper.appLoading(),
                        );
                      }
                    },
                    listLoadingElement: Center(
                      child: ContainerCorner(
                          width: 30, height: 30, child: MainHelper.appLoading()),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
