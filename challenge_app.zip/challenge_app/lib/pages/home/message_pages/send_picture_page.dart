// ignore_for_file: use_build_context_synchronously, must_be_immutable

import 'dart:io';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:image_compression_flutter/image_compression_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/utilities/helper_classes/notifications_helper.dart';
import 'package:challenge/utilities/edition_files_pages/crop_image_page.dart';
import 'package:challenge/models/MessageListModel.dart';
import 'package:challenge/models/MessageModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';

class SendPicturePage extends StatefulWidget {
  final UserModel? currentUser, mUser;
  CameraController? controller;

  SendPicturePage(
      {Key? key, this.mUser, this.currentUser, this.controller})
      : super(key: key);
  static String route = "/message/send_picture";

  @override
  State<SendPicturePage> createState() => _SendPicturePageState();
}

class _SendPicturePageState extends State<SendPicturePage> {
  get size => MediaQuery.of(context).size;

  List<CameraDescription>? cameras; //list out the camera available
  XFile? image; //for captured image

  String uploadPhoto = "";
  ParseFileBase? parseFile;
  String uploadedPic = "";
  TextEditingController storyCaptionController = TextEditingController();

  bool visibleKeyBoard = false;

  int currentCameraIndex = 0;

  @override
  void initState() {
    storyCaptionController = TextEditingController();
    setState(() {});
    super.initState();
  }

  @override
  void dispose() {
    storyCaptionController.dispose();
    super.dispose();
  }

  _switchCamera() async {
    cameras = await availableCameras();
    if(cameras != null && cameras!.length > 1) {
      if (kDebugMode) {
        print(cameras);
      }
      widget.controller = CameraController(
          cameras![currentCameraIndex == 0 ? 1 : 0], ResolutionPreset.max);

      widget.controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      });

      currentCameraIndex = currentCameraIndex == 0 ? 1 : 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(),
    );
  }

  Widget _body() {
    var size = MediaQuery.of(context).size;

    if (widget.controller != null) {
      return ContainerCorner(
          borderWidth: 0,
          child: Stack(children: [
            SizedBox(
                height: size.height,
                width: size.width,
                child: CameraPreview(widget.controller!)),
            ContainerCorner(
              onTap: () => MainHelper.goBackToPreviousPage(context),
              width: size.width / 15,
              height: size.width / 15,
              marginTop: size.height / 20,
              marginLeft: 10,
              color: kPrimaryColor,
              borderRadius: 50,
              child: Center(
                child: Icon(
                  Icons.close,
                  size: size.width / 25,
                  color:Colors.white,
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: btnActions(),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                //show captured image
                padding: const EdgeInsets.all(30),
                child: image == null
                    ? const Text("No image captured")
                    : Image.file(
                        File(image!.path),
                        height: 100,
                      ),
                //display captured image
              ),
            ),
          ]));
    } else {
      return Scaffold(
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            leading: const BackButton(
              color:Colors.white,
            ),
            backgroundColor: kTransparentColor,
            centerTitle: true,
            title: TextWithTap(
              "stories.open_gallery".tr(),
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color:Colors.white,
            ),
          ),
          body: Stack(
            children: [
              ContainerCorner(
                borderWidth: 0,
                color: kTransparentColor,
                width: size.width,
                height: size.height,
                imageDecoration: "assets/images/app_bg.png",
              ),
              ClipRRect(
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                  child: ContainerCorner(
                    width: size.width,
                    height: size.height,
                  ),
                ),
              ),
              SafeArea(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      Column(
                        children: [
                          SizedBox(
                            height: size.height / 12,
                          ),
                          Icon(
                            Icons.no_photography_outlined,
                            color: kPrimaryColor,
                            size: size.width / 2,
                          ),
                          SizedBox(
                            height: size.height / 12,
                          ),
                          TextWithTap(
                            "stories.no_camera".tr(),
                            color:Colors.white,
                            textAlign: TextAlign.center,
                            marginLeft: size.width / 10,
                            marginRight: size.width / 10,
                            marginBottom: 10,
                          ),
                          TextWithTap(
                            "stories.resolve_camera_problem".tr(),
                            color:Colors.white,
                            textAlign: TextAlign.center,
                            marginLeft: size.width / 10,
                            marginRight: size.width / 10,
                          ),
                          SizedBox(
                            height: size.height / 12,
                          ),
                          ContainerCorner(
                            radiusBottomRight: 20,
                            borderWidth: 2,
                            imageDecoration: "assets/images/btn_design.png",
                            radiusTopLeft: 20,
                            marginTop: size.width / 15,
                            marginBottom: size.height * 0.07,
                            height: size.width / 6,
                            marginLeft: size.width / 7,
                            marginRight: size.width / 7,
                            width: size.width,
                            onTap: () => _choosePhoto(),
                            child: Padding(
                              padding: const EdgeInsets.only(left: 20, right: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        right: 10, left: 10, top: 5, bottom: 5),
                                    child: SvgPicture.asset(
                                      "assets/svg/foto.svg",
                                      color: Colors.white,
                                      height: size.width / 14,
                                    ),
                                  ),
                                  TextWithTap(
                                    "stories.choose_pics".tr(),
                                    color: Colors.white,
                                    marginLeft: size.width / 20,
                                    fontSize: size.width / 25,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ));
    }
  }

  _choosePhoto() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      cropPhoto(image: image.path);
    } else {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "crop_image_scree.cancelled_by_user".tr(),
        message: "crop_image_scree.image_not_selected".tr(),
      );
    }
  }

  void compressImage(Future<ImageFile> image) {
    MainHelper.showLoadingDialogWithText(context,
        description: "crop_image_scree.optimizing_image".tr(), useLogo: true);

    image.then((value) {
      Future.delayed(const Duration(seconds: 1), () async {
        var result = await MainHelper.compressImage(value,
            quality: value.sizeInBytes >= 1000000 ? 30 : 50);

        if (result != null) {
          MainHelper.hideLoadingDialog(context);
          MainHelper.showLoadingDialogWithText(context,
              description: "crop_image_scree.optimizing_image_uploading".tr());
          uploadFile(result);
        } else {
          MainHelper.hideLoadingDialog(context);

          MainHelper.showAppNotificationAdvanced(
            context: context,
            title: "crop_image_scree.cancelled_by_user".tr(),
            message: "crop_image_scree.image_not_cropped_error".tr(),
          );
        }
      });
    }).onError((error, stackTrace) {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "try_again_later".tr(),
      );
    });
  }

  void cropPhoto({dynamic image}) async {
    MainHelper.showLoadingDialog(context);

    var result = await MainHelper.goToNavigatorScreenForResult(
        context,
        CropImagePage(
          pathOrBytes: image,
          aspectRatio: CropImagePage.aspectRatioSquare,
        ),
        route: CropImagePage.route);

    if (result != null) {
      XFile? xFile =
          MainHelper.isWebPlatform() ? XFile.fromData(result) : XFile(result);

      MainHelper.hideLoadingDialog(context);
      compressImage(xFile.asImageFile);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "crop_image_scree.cancelled_by_user".tr(),
        message: "crop_image_scree.image_not_cropped_error".tr(),
      );
    }
  }

  uploadFile(ImageFile imageFile) async {
    setState(() {
      if (imageFile.filePath.isNotEmpty) {
        parseFile = ParseFile(File(imageFile.filePath), name: "avatar.jpg");
      } else {
        parseFile = ParseWebFile(imageFile.rawBytes, name: "avatar.jpg");
      }
    });

    ParseResponse parseResponse = await parseFile!.save();

    if (parseResponse.success) {
      if (parseResponse.results!.isNotEmpty) {
        MainHelper.hideLoadingDialog(context);
        preparePhoto(parseResponse.results![0]["url"]);
      }
    } else {
      MainHelper.hideLoadingDialog(context);
      return;
    }
  }

  preparePhoto(String imageURL) {
    var size = MediaQuery.of(context).size;

    return showDialog(
        context: context,
        builder: (context) {
          return GestureDetector(
            onTap: () => MainHelper.removeFocusOnTextField(context),
            child: StatefulBuilder(
              builder: (context, setState) {
                return ContainerCorner(
                  onTap: () => MainHelper.removeFocusOnTextField(context),
                  color: kTransparentColor,
                  borderWidth: 0,
                  width: size.width,
                  height: size.height,
                  child: Scaffold(
                    extendBodyBehindAppBar: true,
                    backgroundColor: kTransparentColor,
                    appBar: AppBar(
                      backgroundColor: kTransparentColor,
                      automaticallyImplyLeading: false,
                      leading: TextButton(
                          onPressed: () =>
                              MainHelper.goBackToPreviousPage(context),
                          child: const Icon(
                            Icons.close,
                            size: 30,
                            color: Colors.white,
                          )),
                    ),
                    body: SingleChildScrollView(
                      child: Stack(
                        alignment: AlignmentDirectional.center,
                        children: [
                          if (cameras == null)
                            ContainerCorner(
                              onTap: () =>
                                  MainHelper.removeFocusOnTextField(context),
                              height: size.height,
                              width: size.width,
                              imageDecoration:  "assets/images/app_bg.png",
                              /*child: ActionsHelper.photosWidget(
                                  widget.currentUser!.getAvatar!.url,
                                  borderRadius: 0,
                                  fit: BoxFit.contain),*/
                            ),
                          ContainerCorner(
                            borderWidth: 0,
                            height: size.height,
                            width: size.width,
                            borderRadius: 50,
                            onTap: () =>
                                MainHelper.removeFocusOnTextField(context),
                            child: ClipRRect(
                              child: BackdropFilter(
                                filter:
                                    ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                                child: Container(),
                              ),
                            ),
                          ),
                          ContainerCorner(
                            onTap: () =>
                                MainHelper.removeFocusOnTextField(context),
                            height: size.height / 1.4,
                            width: size.width,
                            child: ActionsHelper.photosWidget(imageURL,
                                borderRadius: 0, fit: BoxFit.contain),
                          ),
                          Align(
                            alignment: Alignment.bottomRight,
                            child: chatInputField(),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        });
  }

  Widget chatInputField() {
    return ContainerCorner(
      child: Row(
        children: [
          const Expanded(
            child: ContainerCorner(
              borderWidth: 0,
              borderRadius: 50,
              marginLeft: 20,
              marginBottom: 10,
              height: 60,
            ),
          ),
          ContainerCorner(
            marginLeft: 10,
            marginRight: 10,
            marginBottom: 10,
            color:kPrimaryColor,
            // colors: const [Colors.deepOrangeAccent, kPrimaryColor],
            borderRadius: 50,
            height: 55,
            width: 55,
            onTap: () {
              _saveMessage();
            },
            child: ContainerCorner(
              color: kTransparentColor,
              marginAll: 5,
              height: 40,
              width: 40,
              child: Center(
                child: SvgPicture.asset(
                  "assets/svg/ic_send_message.svg",
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Save the message
  _saveMessage() async {
    MainHelper.appLoading();

    MessageModel message = MessageModel();

    message.setAuthor = widget.currentUser!;
    message.setAuthorId = widget.currentUser!.objectId!;

    message.setPictureMessage = parseFile!;

    message.setReceiver = widget.mUser!;
    message.setReceiverId = widget.mUser!.objectId!;

    message.setMessageText = MessageModel.messageTypePicture;
    message.setIsMessageFile = false;

    message.setMessageType = MessageModel.messageTypePicture;

    message.setIsRead = false;

    ParseResponse response = await message.save();

    if (response.success) {
      MainHelper.goBackToPreviousPage(context);

      _saveList(message);

      NotificationsHelper.sendPush(
          widget.currentUser!, widget.currentUser!, NotificationsHelper.typeChat,
          message: "push_notifications.story_replied"
              .tr(namedArgs: {"name": widget.currentUser!.getFullName!}));
    } else {}
  }

  // Update or Create message list
  _saveList(MessageModel messageModel) async {
    QueryBuilder<MessageListModel> queryFrom =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryFrom.whereEqualTo(MessageListModel.keyListId,
        widget.currentUser!.objectId! + widget.mUser!.objectId!);

    QueryBuilder<MessageListModel> queryTo =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryTo.whereEqualTo(MessageListModel.keyListId,
        widget.mUser!.objectId! + widget.currentUser!.objectId!);

    QueryBuilder<MessageListModel> queryBuilder =
        QueryBuilder.or(MessageListModel(), [queryFrom, queryTo]);

    ParseResponse parseResponse = await queryBuilder.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        MessageListModel messageListModel = parseResponse.results!.first;

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = widget.mUser!;
        messageListModel.setReceiverId = widget.mUser!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setIsRead = false;
        messageListModel.setListId =
            widget.currentUser!.objectId! + widget.mUser!.objectId!;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;

        await messageModel.save();
      } else {
        MessageListModel messageListModel = MessageListModel();

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = widget.mUser!;
        messageListModel.setReceiverId = widget.mUser!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setListId =
            widget.currentUser!.objectId! + widget.mUser!.objectId!;
        messageListModel.setIsRead = false;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;
        await messageModel.save();
      }

      MainHelper.goBackToPreviousPage(context);
    }
  }

  Widget btnActions() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      actionButton(Icons.photo, () => _choosePhoto(),),
      actionButton(Icons.camera, () async {
        try {
          if (widget.controller != null) {
            //check if controller is not null
            if (widget.controller!.value.isInitialized) {
              //check if controller is initialized
              image = await widget.controller!
                  .takePicture(); //capture image
              setState(() {
                //update UI
              });
              if (image != null) {
                cropPhoto(image: image!.path);
              }
            }
          }
        } catch (e) {
          e.toString(); //show error
        }
      },),
      actionButton(Icons.switch_camera, () async {
        _switchCamera();
      }),
    ]
    );
  }

  Widget actionButton(IconData icon, VoidCallback action) {
    return ContainerCorner(
      onTap: action,
      width:size.width/8,
      height:size.width/8,
      marginLeft: 10,
      marginRight: 10,
      marginTop:16,
      marginBottom:16,
      color: kButtonTextColor,
      borderRadius: 50,
      child: Center(
        child: Icon(icon, size: size.width/15,color: kContentColorDarkTheme,),
      ),
    );
  }

}
