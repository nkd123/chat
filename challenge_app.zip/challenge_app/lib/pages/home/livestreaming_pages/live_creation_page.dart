// ignore_for_file: use_build_context_synchronously

import 'dart:ui';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../configurations/constants_config.dart';
import '../../../configurations/global_setup.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';
import 'live_streaming_page.dart';

class LiveCreationPage extends StatefulWidget {
  final UserModel? currentUser;

  const LiveCreationPage({
    Key? key,
    this.currentUser,
  }) : super(key: key);

  static String route = "/live/preview";

  @override
  // ignore: library_private_types_in_public_api
  _LiveCreationPageState createState() => _LiveCreationPageState();
}

class _LiveCreationPageState extends State<LiveCreationPage>
    with TickerProviderStateMixin {
  ParseConfig parseConfig = ParseConfig();
  String agoraAppId = '';

  getAllConfigurations() async {
    ParseResponse response = await parseConfig.getConfigs();

    if(response.success && response.results != null){
      if (kDebugMode) {
        print('Configuraçoes: ${response.results}');
      }
    }
  }

  TextEditingController hashTagsEditTextController = TextEditingController();

  bool goLiveBtnSelected = true;
  bool battleBtnSelected = false;
  bool isFirstTime = false;

  TextEditingController liveTitleTextController = TextEditingController();
  TextEditingController creditsTextController = TextEditingController();

  late final AdManagerBannerAd banner;
  late final AdWidget adWidget;

  bool isBannerLoaded = false;

  loadBanner(){
    banner = AdManagerBannerAd(
      adUnitId: Constants.getAdmobBannerUnit(),
      sizes: [AdSize.banner],
      request: const AdManagerAdRequest(),
      listener: AdManagerBannerAdListener(),
    );

    banner.load();
    adWidget = AdWidget(ad: banner);

    setState(() {
      isBannerLoaded = true;
    });
  }

  @override
  void initState() {
    super.initState();
    isFirstLive();

    // getAllConfigurations();
  }

  @override
  void dispose() {
    liveTitleTextController.clear();
    creditsTextController.clear();
    super.dispose();
  }

  checkPermission() async {
    if (MainHelper.isMobile()) {
      if (await Permission.camera.isGranted) {
        //Choose picture
        createLive();
      } else if (await Permission.camera.isDenied) {
        MainHelper.showDialogPermission(
            context: context,
            title: "permissions.photo_access".tr(),
            confirmButtonText: "permissions.okay_".tr().toUpperCase(),
            message: "permissions.photo_access_explain"
                .tr(namedArgs: {"app_name": Setup.appName}),
            onPressed: () async {
              MainHelper.hideLoadingDialog(context);

              // You can request multiple permissions at once.
              Map<Permission, PermissionStatus> statuses =
              await [Permission.camera].request();

              if (statuses[Permission.camera]!.isGranted) {
                //Choose picture
                createLive();
              } else {
                MainHelper.showAppNotificationAdvanced(
                    title: "permissions.photo_access_denied".tr(),
                    message: "permissions.photo_access_denied_explain"
                        .tr(namedArgs: {"app_name": Setup.appName}),
                    context: context,
                    isError: true);
              }
            });
      } else if (await Permission.camera.isPermanentlyDenied) {
        openAppSettings();
      }
    } else {
      //Choose picture
      createLive();
    }
  }

  @override
  Widget build(BuildContext context) {
    if(!isBannerLoaded){
      loadBanner();
    }
    var size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () => MainHelper.removeFocusOnTextField(context),
      child: Scaffold(
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: false,
        body: ContainerCorner(
          color: kTransparentColor,
          borderWidth: 0,
          child: Stack(children: [
            ContainerCorner(
              borderWidth: 0,
              color: kTransparentColor,
              width: size.width,
              height: size.height,
              imageDecoration: "assets/images/app_bg.png",
            ),
            ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                child: ContainerCorner(
                  width: size.width,
                  height: size.height,
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ContainerCorner(
                          //height: 100,
                          width: size.width,
                          marginLeft: size.width / 20,
                          marginRight: size.width / 20,
                          marginTop: size.width / 3,
                          marginBottom: size.width / 20,
                          color: kTransparentColor, // Colors.black.withOpacity(0.4),
                          borderRadius: 10,
                          borderWidth: 0,
                          child: Column(
                            children: [
                              ContainerCorner(
                                borderWidth: 0,
                                width: 85,
                                height: 85,
                                marginLeft: 10,
                                color: kTransparentColor,
                                child: ActionsHelper.polygonAvatarWidget(
                                    currentUser: widget.currentUser!,
                                    fontSize: 26),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  TextWithTap(
                                    widget.currentUser!.getFullName!,
                                    color: Colors.white,
                                    fontSize: 14.5,
                                    marginLeft: size.width / 40,
                                    marginTop: 10,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              )
                            ],
                          ),
                        ),
                        ContainerCorner(
                          height: 50,
                          width: size.width,
                          marginLeft: size.width / 20,
                          marginRight: size.width / 20,
                          marginTop: size.width / 35,
                          color: Colors.black.withOpacity(0.4),
                          borderRadius: 10,
                          borderWidth: 0,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: TextFormField(
                              cursorColor: Colors.white,
                              autocorrect: false,
                              keyboardType: TextInputType.multiline,
                              style: GoogleFonts.nunito(
                                color: Colors.white,
                                fontSize: 16.5,
                              ),
                              maxLines: 1,
                              controller: liveTitleTextController,
                              decoration: InputDecoration(
                                floatingLabelStyle: GoogleFonts.nunito(
                                  color: Colors.white,
                                  fontSize: 20,
                                ),
                                hintText: "live_streaming.live_title".tr(),
                                hintStyle: GoogleFonts.nunito(
                                  color: Colors.white.withOpacity(0.5),
                                  fontSize: 16,
                                ),
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: ContainerCorner(
                onTap: () => MainHelper.goBackToPreviousPage(context),
                width: size.width / 15,
                height: size.width / 15,
                marginLeft: 10,
                marginRight: 10,
                marginTop: 10,
                color: kPrimaryColor,
                borderRadius: 50,
                child: Center(
                  child: Icon(
                    Icons.close,
                    size: size.width / 25,
                    color: kContentColorDarkTheme,
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: ContainerCorner(
                radiusBottomRight: 20,
                borderWidth: 2,
                imageDecoration: "assets/images/btn_design.png",
                radiusTopLeft: 20,
                marginTop: size.width / 15,
                marginBottom: size.height * 0.07,
                height: size.width / 6,
                marginLeft: size.width / 7,
                marginRight: size.width / 7,
                width: size.width,
                onTap: () {
                  if (liveTitleTextController.text.isEmpty) {
                    MainHelper.showAppNotificationAdvanced(
                      title: "live_streaming.no_title_title".tr(),
                      message: "live_streaming.no_title_explain".tr(),
                      context: context,
                      isError: true,
                    );
                  }
                  else {
                    checkPermission();
                  }
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextWithTap(
                        "live_streaming.btn_go_live".tr(),
                        color: Colors.white,
                        marginLeft: 10,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      )
                    ],
                  ),
                ),
              ),
            ),
            Visibility(
              visible: isBannerLoaded,
              child: Align(
                alignment: Alignment.bottomCenter,
                child: ContainerCorner(
                  marginTop: 10,
                  width: size.width,
                  height: size.height * 0.08,
                  child: adWidget,
                ),
              ),
            )
          ]),
        ),
      ),
    );
  }

  void isFirstLive() async {
    QueryBuilder<LiveStreamingModel> queryBuilder =
        QueryBuilder(LiveStreamingModel());
    queryBuilder.whereEqualTo(
        LiveStreamingModel.keyAuthorId, widget.currentUser!.objectId);

    ParseResponse parseResponse = await queryBuilder.count();

    if (parseResponse.success) {
      if (parseResponse.count > 0) {
        isFirstTime = false;
      } else {
        isFirstTime = true;
      }
    }
  }

  void createLive() async {
    MainHelper.showLoadingDialog(context, isDismissible: false);

    QueryBuilder<LiveStreamingModel> queryBuilder =
        QueryBuilder(LiveStreamingModel());
    queryBuilder.whereEqualTo(
        LiveStreamingModel.keyAuthorId, widget.currentUser!.objectId);
    queryBuilder.whereEqualTo(LiveStreamingModel.keyStreaming, true);

    ParseResponse parseResponse = await queryBuilder.query();
    if (parseResponse.success) {
      if (parseResponse.results != null) {
        LiveStreamingModel live =
            parseResponse.results!.first! as LiveStreamingModel;

        live.setStreaming = false;
        await live.save();

        createLiveFinish();
      } else {
        createLiveFinish();
      }
    } else {
      
      MainHelper.showErrorResult(context, parseResponse.error!.code);
      
      MainHelper.hideLoadingDialog(context);
    }
  }

  createLiveFinish() async {
    LiveStreamingModel streamingModel = LiveStreamingModel();
    streamingModel.setStreamingChannel = widget.currentUser!.getUsername! +
        widget.currentUser!.getUid!.toString();

    streamingModel.setAuthor = widget.currentUser!;
    streamingModel.setAuthorId = widget.currentUser!.objectId!;
    streamingModel.setAuthorUid = widget.currentUser!.getUid!;
    streamingModel.addDiamonds = widget.currentUser!.getPointsTotal!;
    streamingModel.setFirstLive = isFirstTime;
    streamingModel.setLiveTitle = liveTitleTextController.text;
    streamingModel.setLiveType = LiveStreamingModel.liveVideo;

    if (widget.currentUser!.getAvatar != null) {
      streamingModel.setImage = widget.currentUser!.getAvatar!;
    }

    streamingModel.setPrivate = false;
    streamingModel.setStreaming = false;
    streamingModel.addViewersCount = 0;
    streamingModel.addDiamonds = 0;

    ParseResponse parseResponse = await streamingModel.save();

    if (parseResponse.success) {
      LiveStreamingModel liveStreaming = parseResponse.results!.first!;

      createChallenge(liveStreaming);

      
      MainHelper.hideLoadingDialog(context);
      
      MainHelper.goToNavigatorScreen(
        context,
        LiveStreamingPage(
          channelName: streamingModel.getStreamingChannel!,
          isBroadcaster: true,
          currentUser: widget.currentUser!,
          mLiveStreamingModel: liveStreaming,
          mUser: widget.currentUser!,
        ),
      );
    } else {
      
      MainHelper.showErrorResult(context, parseResponse.error!.code);
      
      MainHelper.hideLoadingDialog(context);
    }
  }

  createChallenge(LiveStreamingModel liveStreaming) async {
    ChallengeModel challenge = ChallengeModel();

    challenge.setAuthor = widget.currentUser!;
    challenge.setAuthorId = widget.currentUser!.objectId!;

    challenge.setMode = ChallengeModel.modeLIVESTREAMING;

    challenge.setLiveStreaming = liveStreaming;
    challenge.setLiveStreamingId = liveStreaming.objectId!;

    await challenge.save();
  }
}
