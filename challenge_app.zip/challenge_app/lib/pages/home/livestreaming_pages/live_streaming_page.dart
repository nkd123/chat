// ignore_for_file: must_be_immutable, use_build_context_synchronously

import 'dart:async';
import 'dart:ui';

import 'package:challenge/models/ReportModel.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_windowmanager/flutter_windowmanager.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:flutter/material.dart';

import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as rtc_local_view;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as rtc_remote_view;
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/cloud_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/utilities/helper_classes/notifications_helper.dart';
import 'package:challenge/widgets/components_widgets/coins_payment_widget.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:challenge/models/GiftSendersGlobalModel.dart';
import 'package:challenge/models/GiftSendersModel.dart';
import 'package:challenge/models/GiftsModel.dart';
import 'package:challenge/models/GiftsSentModel.dart';
import 'package:challenge/models/LiveMessagesModel.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/NotificationsModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:stop_watch_timer/stop_watch_timer.dart';
import 'package:wakelock/wakelock.dart';

import '../../../configurations/global_config.dart';
import '../../../widgets/custom_widgets/button_with_gradient.dart';
import '../../../widgets/custom_widgets/button_with_icon.dart';
import '../../../widgets/custom_widgets/text_with_tap.dart';

class LiveStreamingPage extends StatefulWidget {
  final String channelName;
  final bool isBroadcaster;
  UserModel currentUser;
  UserModel? mUser;
  UserModel? invitedBroadcaster;
  LiveStreamingModel? mLiveStreamingModel;
  final GiftsModel? giftsModel;

  LiveStreamingPage(
      {Key? key,
      required this.channelName,
      required this.isBroadcaster,
      required this.currentUser,
      this.mUser,
      this.mLiveStreamingModel,
      this.giftsModel})
      : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _LiveStreamingPageState createState() => _LiveStreamingPageState();
}

class _LiveStreamingPageState extends State<LiveStreamingPage>
    with TickerProviderStateMixin {
  get size => MediaQuery.of(context).size;
  final _users = <int>[];
  final usersInLiveBeforePrivate = <UserModel>[];

  final usersWhoSentGift = <UserModel>[];

  final joinedLiveUsers = [];
  var usersToInvite = [];
  late UserModel invitedUser;
  bool invited = false;
  late RtcEngine _engine;
  bool muted = false;
  bool liveMessageSent = false;
  late int streamId;
  late LiveStreamingModel liveStreamingModel;
  bool liveEnded = false;
  bool following = false;
  bool liveJoined = false;
  LiveQuery liveQuery = LiveQuery();
  Subscription? subscription;
  String liveCounter = "0";
  String diamondsCounter = "0";
  String mUserDiamonds = "";
  AnimationController? _animationController;
  int bottomSheetCurrentIndex = 0;

  int invitedBroadcasterUid = 1;
  bool inviteAccepted = false;

  bool warningShows = false;
  bool isPrivateLive = false;
  bool initGift = false;

  bool coHostAvailable = false;
  int coHostUid = 0;
  bool invitationSent = false;

  TextEditingController textEditingController = TextEditingController();

  late FocusNode? chatTextFieldFocusNode;
  GiftsModel? selectedGif;

  final StopWatchTimer _stopWatchTimer = StopWatchTimer();
  String callDuration = "00:00";

  int livePoints = 0;

  void initializeSelectedGif(GiftsModel gift) {
    setState(() {
      selectedGif = gift;
    });
  }

  _getDefaultGiftPrice() async {
    QueryBuilder<GiftsModel> queryGift = QueryBuilder<GiftsModel>(GiftsModel());
    queryGift.whereEqualTo(
        GiftsModel.keyGiftCategories, GiftsModel.giftCategoryTypeClassic);
    queryGift.setLimit(1);

    ParseResponse response = await queryGift.query();
    if (response.success) {
      initializeSelectedGif(response.results as GiftsModel);
      setState(() {
        selectedGif = response.results as GiftsModel;
      });
    }
  }

  startTimerToEndLive(BuildContext context, int seconds) {
    Future.delayed(Duration(seconds: seconds), () {
      if (!isLiveJoined()) {
        if (widget.isBroadcaster) {
          MainHelper.showDialogLivEend(
            context: context,
            dismiss: false,
            title: 'live_streaming.cannot_stream'.tr(),
            confirmButtonText: 'live_streaming.finish_live'.tr(),
            message: 'live_streaming.cannot_stream_ask'.tr(),
            onPressed: () {
              //MainHelper.goToPageWithClear(context, HomePage(userModel: currentUser)),
              MainHelper.goBackToPreviousPage(context);
              MainHelper.goBackToPreviousPage(context);
              //_onCallEnd(context),
            },
          );
        } else {
          setState(() {
            liveEnded = true;
          });
          _stopWatchTimer.onExecute.add(StopWatchExecute.reset);
          widget.mLiveStreamingModel!.setStreaming = false;
          widget.mLiveStreamingModel!.save();
        }
      }
    });
  }

  startTimerToConnectLive(BuildContext context, int seconds) {
    Future.delayed(Duration(seconds: seconds), () {
      if (!liveJoined) {
        final snackBar = SnackBar(
          backgroundColor: MainHelper.isDarkModeNoContext()
            ? kContentColorLightTheme
            : kContentColorDarkTheme,
          content: Text(widget.isBroadcaster
            ? "can_not_try".tr()
            : "live_streaming.something_wrong".tr(),
            style: TextStyle(
              color: MainHelper.isDarkModeNoContext()
                  ? kContentColorDarkTheme
                  : kContentColorLightTheme,
          ),
          ),
        );

        ScaffoldMessenger.of(context).showSnackBar(snackBar);
        MainHelper.goBackToPreviousPage(context);
      }
    });
  }

  bool _showChat = false;

  @override
  void dispose() {
    Wakelock.disable();
    // clear users
    _users.clear();
    // destroy sdk and leave channel
    _engine.destroy();

    if (subscription != null) {
      liveQuery.client.unSubscribe(subscription!);
    }

    if (subscription != null) {
      liveQuery.client.unSubscribe(subscription!);
    }

    if (invitedBroadcasterUid == widget.currentUser.getUid!) {
      saveLiveUpdate();
    }

    textEditingController.dispose();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeRight,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    _secureScreen(false);
    super.dispose();
  }

  @override
  void initState() {
    // initialize agora sdk
    setupControlLiveQuery();
    getPoints();

    if (!widget.isBroadcaster) {
      setState(() {
        mUserDiamonds = widget.mUser!.getPointsTotal.toString();
        _showChat = false;
        //setupInvitationLiveQuery();
      });
    }

    if (widget.mLiveStreamingModel!.getInvitationAccepted! &&
        !widget.isBroadcaster) {
      getInvitedBroadCaster();
    }

    //context.read<CallsProvider>().setUserBusy(true);
    Wakelock.enable();

    _secureScreen(true);
    initializeAgora();

    _stopWatchTimer.onExecute.add(StopWatchExecute.start);

    chatTextFieldFocusNode = FocusNode();

    _animationController = AnimationController.unbounded(vsync: this);

    super.initState();
  }

  bool _hideSendButton = false;
  bool visibleKeyBoard = false;
  bool visibleAudienceKeyBoard = false;

  void showChatState() {
    setState(() {
      _showChat = !_showChat;
    });
  }

  void toggleSendButton(bool active) {
    setState(() {
      _hideSendButton = active;
    });
  }

  String liveTitle = "live_streaming.live_".tr();

  Future<void> initializeAgora() async {
    // startTimerToConnectLive(context, 10);

    await _initAgoraRtcEngine();

    if (!widget.isBroadcaster &&
        widget.currentUser.getFollowing!.contains(widget.mUser!.objectId)) {
      following = true;
    }

    if (widget.mLiveStreamingModel != null) {
      liveStreamingModel = widget.mLiveStreamingModel!;
    }

    if (widget.isBroadcaster) {
      streamId = (await _engine.createDataStream(false, false))!;
    }

    _engine.setEventHandler(RtcEngineEventHandler(
      rtmpStreamingEvent: (string, rtmpEvent) {},
      joinChannelSuccess: (channel, uid, elapsed) {
        setState(() {
          startTimerToEndLive(context, 5);

          if (widget.isBroadcaster && uid == widget.currentUser.getUid) {}
        });
      },
      firstRemoteVideoFrame: (uid, width, height, elapsed) {},
      firstLocalVideoFrame: (width, height, elapsed) {
        if (widget.isBroadcaster && !liveJoined) {
          createLive(widget.mLiveStreamingModel!);

          setState(() {
            liveJoined = true;
          });
        }
      },
      error: (ErrorCode errorCode) {
        // JoinChannelRejected
        if (errorCode == ErrorCode.JoinChannelRejected) {
          _engine.leaveChannel();
          MainHelper.goToPageWithClear(
              context, HomePage(currentUser: widget.currentUser));
        }
      },
      leaveChannel: (stats) {
        setState(() {
          _users.clear();
        });
      },
      userJoined: (uid, elapsed) {
        setState(() {
          _users.add(uid);
          usersInLiveBeforePrivate.add(widget.mUser!);
          liveJoined = true;
          joinedLiveUsers.add(uid);
        });

        updateViewers(uid, widget.currentUser.objectId!);
      },
      userOffline: (uid, elapsed) {
        if (!widget.isBroadcaster) {
          setState(() {
            _users.remove(uid);

            if (uid == widget.mUser!.getUid) {
              liveEnded = true;
              liveJoined = false;
            }
          });
        }
      },
      streamMessage: (_, __, message) {},
      streamMessageError: (_, __, error, ___, ____) {},
    ));

    await _engine.joinChannel(null, widget.channelName,
        widget.currentUser.objectId, widget.currentUser.getUid!);
  }

  Future<void> _initAgoraRtcEngine() async {
    // Create RTC client instance
    RtcEngineContext context = RtcEngineContext(Config.agoraAppId);
    _engine = await RtcEngine.createWithContext(context);

    if (widget.isBroadcaster) {
      await _engine.startPreview();
    }
    await _engine.enableVideo();

    await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    if (widget.isBroadcaster) {
      await _engine.setClientRole(ClientRole.Broadcaster);
    } else {
      await _engine.setClientRole(ClientRole.Audience);
    }
  }

  bool selected = false;

  @override
  Widget build(BuildContext context) {
    // var size = MediaQuery.of(context).size;

    if (isPrivateLive) {
      if (liveStreamingModel.getAuthorId != widget.currentUser.objectId) {
        openPayPrivateLiveSheet(liveStreamingModel);
      }
    }

    return WillPopScope(
      onWillPop: () => closeAlert(),
      child: GestureDetector(
        onTap: () {
          if (FocusScope.of(context).hasFocus) {
            FocusScope.of(context).unfocus();
            showChatState();
            setState(() {
              visibleKeyBoard = false;
              visibleAudienceKeyBoard = false;
            });
          }
        },
        child: Scaffold(
          resizeToAvoidBottomInset: false,
          backgroundColor: kTransparentColor,
          extendBodyBehindAppBar: true,
          body: Center(
            child: Stack(
              alignment: AlignmentDirectional.center,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    _getRenderViews(),
                    Visibility(
                      visible: !isLiveJoined(),
                      child: getLoadingScreen(),
                    ),
                  ],
                ),
                Visibility(
                  visible: false, //isLiveJoined(),
                  child: _toolbar(),
                ),
                Visibility(
                  visible: !liveEnded && isLiveJoined(),
                  child: topBar(),
                ),
                Visibility(
                  visible: !liveEnded && isLiveJoined(),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Container(
                        margin: EdgeInsets.only(
                            right: size.width * 0.15,
                            bottom: visibleKeyBoard
                                ? MediaQuery.of(context).viewInsets.bottom
                                : 1),
                        child: _bottomBar(),
                      ),
                    ),
                  ),
                ),
                Visibility(
                  visible: !liveEnded && isLiveJoined(),
                  child: Padding(
                    padding: MediaQuery.of(context).orientation ==
                            Orientation.landscape
                        ? const EdgeInsets.only(top: 60.0)
                        : const EdgeInsets.only(top: 0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: widget.isBroadcaster ||
                              invitedBroadcasterUid ==
                                  widget.currentUser.getUid!
                          ? btnBrodcasterActions()
                          : btnAudienceActions(),
                    ),
                  ),
                ),
                Visibility(
                  visible: invited,
                  child: ContainerCorner(
                    width: size.width,
                    height: size.height,
                    color: Colors.black.withOpacity(0.4),
                    child: Center(
                      child: ContainerCorner(
                        width: size.width * 0.8,
                        height: size.height * 0.6,
                        //color: kPrimaryColor,
                        imageDecoration: 'assets/images/invite_bg.png',
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            TextWithTap(
                              "live_streaming.invite_title".tr().toUpperCase(),
                              color: kContentColorDarkTheme,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                            ),
                            TextWithTap(
                              "live_streaming.invite_dec".tr(),
                              color: kContentColorDarkTheme,
                              fontSize: 18,
                              textAlign: TextAlign.center,
                              marginLeft: size.width * 0.05,
                              marginRight: size.width * 0.05,
                              marginTop: 30,
                              marginBottom: 30,
                            ),
                            ContainerCorner(
                              radiusBottomRight: 20,
                              borderWidth: 2,
                              imageDecoration: "assets/images/white_btn.png",
                              radiusTopLeft: 20,
                              marginTop: size.width / 15,
                              height: size.width / 9,
                              marginLeft: size.width / 8,
                              marginRight: size.width / 8,
                              width: size.width,
                              onTap: () {
                                setState(() {
                                  invited = false;
                                });

                                acceptInvitation(widget.currentUser);
                              },
                              child: Center(
                                child: TextWithTap(
                                  "live_streaming.accept".tr().toUpperCase(),
                                  color: kButtonTextColor,
                                  fontWeight: FontWeight.w900,
                                  fontSize: size.width / 16,
                                ),
                              ),
                            ),
                            ContainerCorner(
                              radiusBottomRight: 20,
                              borderWidth: 2,
                              imageDecoration: "assets/images/white_btn.png",
                              radiusTopLeft: 20,
                              //marginTop: size.width / 15,
                              height: size.width / 9,
                              marginLeft: size.width / 8,
                              marginRight: size.width / 8,
                              width: size.width,
                              onTap: () {
                                setState(() {
                                  invited = false;
                                });

                                declineInvitation();
                              },
                              child: Center(
                                child: TextWithTap(
                                  "live_streaming.refuse".tr().toUpperCase(),
                                  color: kButtonTextColor,
                                  fontWeight: FontWeight.w900,
                                  fontSize: size.width / 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool isLiveJoined() {
    if (liveJoined) {
      return true;
    } else {
      return false;
    }
  }

  bool visibleToolbar() {
    if (widget.isBroadcaster) {
      return true;
    } else if (!widget.isBroadcaster && liveEnded) {
      return false;
    } else {
      return false;
    }
  }

  Widget topBar() {
    return SafeArea(
      child: Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(
              top: size.height * 0.0001, left: 10.0, right: 10.0),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Row(
              children: [
                ContainerCorner(
                  width: 65,
                  height: 65,
                  child: Row(children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 4.5, bottom: 4.5),
                      child: ActionsHelper.polygonAvatarWidget(
                        currentUser:widget.isBroadcaster
                            ? widget.currentUser
                            : widget.mUser!,
                        fontSize: 26,
                      ),
                    ),
                  ]),
                ),
                TextWithTap(
                  '@${widget.isBroadcaster ? widget.currentUser.getUsername! : widget.mUser!.getUsername}',
                  fontSize: 12.5,
                  color: kContentColorDarkTheme,
                  overflow: TextOverflow.ellipsis,
                )
              ],
            ),
            Row(
              children: [
                ContainerCorner(
                  width: size.width * 0.16,
                  height: 40.0,
                  color: kButtonTextColor,
                  borderRadius: 2,
                  marginRight: 3,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      TextWithTap(
                        MainHelper.getViewersNumberFormated(
                            int.parse(liveCounter)),
                        color: Colors.white,
                        fontSize: 12,
                        marginRight: size.width / 70,
                      ),
                      SvgPicture.asset(
                        "assets/svg/ic_live_viewer.svg",
                        width: 12,
                        height: 12,
                      ),
                    ],
                  ),
                ),
                ContainerCorner(
                  width: size.width * 0.17,
                  height: 40.0,
                  color: kPrimaryColor,
                  borderRadius: 2,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ContainerCorner(
                        height: 8,
                        width: 8,
                        color: Colors.white,
                        borderRadius: 50,
                        marginRight: size.width / 70,
                      ),
                      TextWithTap(
                        "live_streaming.live_".tr().toUpperCase(),
                        color: Colors.white,
                        fontSize: 12,
                      ),
                    ],
                  ),
                ),
                ContainerCorner(
                  onTap: () => closeAlert(),
                  width: 30,
                  height: 30,
                  marginLeft: 20.0,
                  color: kButtonTextColor,
                  borderRadius: 50,
                  child: Center(
                    child: Icon(
                      Icons.close,
                      size: MediaQuery.of(context).orientation ==
                              Orientation.landscape
                          ? size.width / 37
                          : size.width / 23,
                      color: kContentColorDarkTheme,
                    ),
                  ),
                ),
              ],
            ),
          ]),
        ),
      ),
    );
  }

  Widget oldTopBar() {
    return SafeArea(
      child: Align(
        alignment: Alignment.topCenter,
        child: Padding(
          padding: EdgeInsets.only(top: size.height * 0.027),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            ContainerCorner(
              imageDecoration: "assets/images/ic_live_top_btn.png",
              width: size.width * 0.26,
              height: 30,
              boxFit: BoxFit.fill,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ContainerCorner(
                    height: 8,
                    width: 8,
                    color: Colors.white,
                    borderRadius: 50,
                    marginRight: size.width / 70,
                  ),
                  TextWithTap(
                    "live_streaming.live_".tr().toUpperCase(),
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ],
              ),
            ),
            ContainerCorner(
              imageDecoration: "assets/images/ic_live_top_btn.png",
              width: size.width * 0.26,
              height: 30,
              boxFit: BoxFit.fill,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      right: 15.0,
                    ),
                    child: SvgPicture.asset(
                      "assets/svg/ic_live_network_state.svg",
                      width: 12,
                      height: 12,
                    ),
                  ),
                ],
              ),
            ),
            ContainerCorner(
              imageDecoration: "assets/images/ic_live_top_btn.png",
              width: size.width * 0.26,
              height: 30,
              boxFit: BoxFit.fill,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextWithTap(
                    liveCounter.toString(),
                    color: Colors.white,
                    fontSize: 12,
                    marginRight: size.width / 70,
                  ),
                  SvgPicture.asset(
                    "assets/svg/ic_live_viewer.svg",
                    width: 12,
                    height: 12,
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }

  requestLive() {
    sendMessage(LiveMessagesModel.messageTypeCoHost, "", widget.currentUser);
  }

  closeAlert() {
    if (!widget.isBroadcaster) {
      //context.read<CallsProvider>().setUserBusy(false);
      saveLiveUpdate();
    } else {
      if (liveJoined == false && liveEnded == true) {
        MainHelper.goToPageWithClear(
            context, HomePage(currentUser: widget.currentUser));
      } else {
        MainHelper.showDialogLivEend(
          context: context,
          title: 'live_streaming.live_'.tr(),
          confirmButtonText: 'live_streaming.finish_live'.tr(),
          message: 'live_streaming.finish_live_ask'.tr(),
          onPressed: () {
            //context.read<CallsProvider>().setUserBusy(false);
            int points = widget.currentUser.getChallengePoint ?? 0;
            widget.currentUser.setChallengePoint =
                points + Config.endLivePoints;
            widget.currentUser.save();

            MainHelper.goBackToPreviousPage(context);
            _onCallEnd(context);
          },
        );
      }
    }
  }

  getInvitedBroadCaster() async {
    //
    QueryBuilder<LiveStreamingModel> query =
        QueryBuilder<LiveStreamingModel>(LiveStreamingModel());
    query.whereEqualTo(
        LiveStreamingModel.keyObjectId, widget.mLiveStreamingModel!.objectId);

    query.includeObject(
        [LiveStreamingModel.keyAuthor, LiveStreamingModel.keyAuthorInvited]);

    ParseResponse response = await query.query();

    if (response.success) {
      if (response.results != null) {
        LiveStreamingModel live =
            response.results?.first! as LiveStreamingModel;
        setState(() {
          widget.invitedBroadcaster = live.getAuthorInvited;
          invitedBroadcasterUid = live.getAuthorInvited!.getUid!;
        });
      }
    }
  }

  Widget _toolbar() {
    return Container(
        margin: const EdgeInsets.only(top: 50),
        alignment: Alignment.topLeft,
        padding: const EdgeInsets.symmetric(vertical: 48, horizontal: 5),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    SvgPicture.asset(
                      "assets/svg/ic_small_viewers.svg",
                      height: 16,
                    ),
                    SvgPicture.asset(
                      "assets/svg/ic_diamond.svg",
                      height: 25,
                    ),
                  ],
                ),
                Column(
                  children: [
                    TextWithTap(
                      liveCounter.toString(),
                      color: Colors.white,
                      fontSize: 16,
                      marginLeft: 10,
                    ),
                    TextWithTap(
                      diamondsCounter,
                      color: Colors.white,
                      fontSize: 16,
                      marginLeft: 9,
                      marginBottom: 7,
                    ),
                  ],
                ),
              ],
            ),
          ],
        ));
  }

  Widget _bottomBar() {
    return widget.isBroadcaster ||
          invitedBroadcasterUid == widget.currentUser.getUid!
      ? streamerBottom()
      : audienceBottom();
  }

  Widget _getRenderViews() {
    if (widget.isBroadcaster) {
      return Column(
        children: [
          const Flexible(
            flex: 1,
            child: rtc_local_view.SurfaceView(
              zOrderMediaOverlay: true,
              zOrderOnTop: true,
            ),
          ),
          if (widget.mLiveStreamingModel!.getInvitationAccepted!)
            Flexible(
                flex: 1,
                child: rtc_remote_view.SurfaceView(
                  uid: widget.invitedBroadcaster!.getUid!,
                  channelId: widget.channelName,
                )),
        ],
      );
    } else {
      if (invitedBroadcasterUid == widget.currentUser.getUid!) {
        return Column(
          children: [
            const Flexible(
              flex: 1,
              child: rtc_local_view.SurfaceView(
                zOrderMediaOverlay: true,
                zOrderOnTop: true,
              ),
            ),
            if (widget.mLiveStreamingModel!.getInvitationAccepted! &&
                invitedBroadcasterUid != 1)
              Flexible(
                  flex: 1,
                  child: rtc_remote_view.SurfaceView(
                    uid: widget.mUser!.getUid!,
                    channelId: widget.channelName,
                  )),
          ],
        );
      } else {
        return Column(
          children: [
            Flexible(
              flex: 1,
              child: rtc_remote_view.SurfaceView(
                uid: widget.mUser!.getUid!,
                channelId: widget.channelName,
              ),
            ),
            if (widget.mLiveStreamingModel!.getInvitationAccepted! &&
                invitedBroadcasterUid != 1)
              Flexible(
                  flex: 1,
                  child: rtc_remote_view.SurfaceView(
                    uid: invitedBroadcasterUid,
                    channelId: widget.channelName,
                  )),
          ],
        );
      }
    }
  }

  Widget getLoadingScreen() {
    var size = MediaQuery.of(context).size;
    if (liveEnded) {
      return Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              TextWithTap(
                "live_streaming.live_ended".tr(),
                marginBottom: size.height * 0.15,
                marginTop: 15,
                fontSize: 16,
                color: Colors.white,
              ),
              ContainerCorner(
                borderWidth: 0,
                width: 110,
                height: 110,
                marginBottom: 10,
                color: kTransparentColor,
                child: ActionsHelper.polygonAvatarWidget(
                    currentUser:widget.isBroadcaster
                    ? widget.currentUser
                    : widget.mUser!,
                    fontSize: 26),
              ),
              TextWithTap(
                widget.isBroadcaster
                    ? widget.currentUser.getFullName!
                    : widget.mUser!.getFullName!,
                //marginTop: 13,
                marginBottom: 10,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              Container(
                margin: const EdgeInsets.only(bottom: 25),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SvgPicture.asset(
                      "assets/svg/ic_live_viewer.svg",
                      height: 14,
                      color: Colors.white,
                    ),
                    TextWithTap(
                      liveStreamingModel.getViewers!.length.toString(),
                      color: Colors.white,
                      fontSize: 15,
                      marginRight: 15,
                      marginLeft: 5,
                    ),
                  ],
                ),
              ),
              Visibility(
                visible: !widget.isBroadcaster,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Visibility(
                      visible: !following,
                      child: ContainerCorner(
                        radiusBottomRight: 20,
                        borderWidth: 2,
                        imageDecoration: "assets/images/btn_design.png",
                        radiusTopLeft: 20,
                        marginTop: size.width / 15,
                        marginBottom: size.height * 0.07,
                        height: size.width / 6,
                        width: size.width * 0.7,
                        onTap: () {
                          followOrUnfollow();
                        },
                        child: Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextWithTap(
                                "live_streaming.live_follow".tr(),
                                color: Colors.white,
                                marginLeft: 10,
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Visibility(
                      visible: following,
                      child: ContainerCorner(
                        marginRight: 50,
                        marginLeft: 50,
                        borderRadius: 50,
                        height: 30,
                        child: Center(
                            child: TextWithTap(
                          "live_streaming.you_follow".tr(),
                          color: kPrimaryColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 16,
                        )),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SafeArea(
            child: Positioned(
              top: 10,
              right: 0,
              child: ContainerCorner(
                onTap: () => MainHelper.goToNavigatorScreen(
                    context,
                    HomePage(
                      currentUser: widget.currentUser,
                    )),
                width: size.width / 15,
                height: size.width / 15,
                marginLeft: 10,
                marginRight: 10,
                marginTop: 10,
                color: kPrimaryColor,
                borderRadius: 50,
                child: Center(
                  child: Icon(
                    Icons.close,
                    size: size.width / 25,
                    color: kContentColorDarkTheme,
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    } else {
      return Stack(
        children: [
          ContainerCorner(
            borderWidth: 0,
            color: kTransparentColor,
            width: size.width,
            height: size.height,
            imageDecoration: "assets/images/app_bg.png",
          ),
          ClipRRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
              child: ContainerCorner(
                width: size.width,
                height: size.height,
              ),
            ),
          ),
          MainHelper.appLoading(),
        ],
      );
    }
  }

  void followOrUnfollow() async {
    if (widget.currentUser.getFollowing!.contains(widget.mUser!.objectId)) {
      widget.currentUser.removeFollowing = widget.mUser!.objectId!;

      setState(() {
        following = false;
      });
    } else {
      widget.currentUser.setFollowing = widget.mUser!.objectId!;

      setState(() {
        following = true;
      });
    }

    await widget.currentUser.save();

    ParseResponse parseResponse = await CloudCodeHelper.followUser(
        isFollowing: false,
        author: widget.currentUser,
        receiver: widget.mUser!);
    if (parseResponse.success) {
      ActionsHelper.createOrDeleteNotification(widget.currentUser,
          widget.mUser!, NotificationsModel.notificationTypeFollowers);
    }
  }

  void _onCallEnd(BuildContext context) {
    saveLiveUpdate();
    if (subscription != null) {
      liveQuery.client.unSubscribe(subscription!);
    }

    if (mounted) {
      setState(() {
        liveEnded = true;
        liveJoined = false;
      });
    }
  }

  void saveLiveUpdate() async {
    if (widget.isBroadcaster) {
      liveStreamingModel.setStreaming = false;
      await liveStreamingModel.save();
      _engine.leaveChannel();
    } else if (invitedBroadcasterUid == widget.currentUser.getUid!) {
      // A saida do invited broadcaster
      await _engine.stopScreenCapture();
      _engine.leaveChannel();

      setState(() {
        liveStreamingModel.removeViewersCount = 1;
        widget.mLiveStreamingModel!.setAuthorInvitedUid = 0;
        widget.mLiveStreamingModel!.setInvitedBroadCasterId = '';
        widget.mLiveStreamingModel!.setInvitationAccepted = false;
      });

      await widget.mLiveStreamingModel!.save();

      MainHelper.goToPageWithClear(
          context, HomePage(currentUser: widget.currentUser));
    } else {
      if (liveJoined) {
        liveStreamingModel.removeViewersCount = 1;
        await liveStreamingModel.save();
      }
      _engine.leaveChannel();

      MainHelper.goToPageWithClear(
          context, HomePage(currentUser: widget.currentUser));
    }
  }

  void _onToggleMute() {
    setState(() {
      muted = !muted;
    });
    _engine.muteLocalAudioStream(muted);
  }

  _onSwitchCamera() {
    //_engine.sendStreamMessage(streamId, "mute user blet");
    _engine.switchCamera();
  }

  updateViewers(int uid, String objectId) async {
    liveStreamingModel.addViewersCount = 1;
    liveStreamingModel.setViewersId = objectId;
    liveStreamingModel.setViewers = uid;

    if (liveStreamingModel.getPrivate!) {
      liveStreamingModel.setPrivateViewersId = objectId;
    }

    ParseResponse parseResponse = await liveStreamingModel.save();
    if (parseResponse.success) {
      setState(() {
        liveCounter = liveStreamingModel.getViewersCount.toString();
        diamondsCounter = liveStreamingModel.getDiamonds.toString();
      });

      sendMessage(LiveMessagesModel.messageTypeJoin, "", widget.currentUser);

      setupCounterLive(liveStreamingModel.objectId!);
      setupCounterLiveUser();
    }
  }

  createLive(LiveStreamingModel liveStreamingModel) async {
    liveStreamingModel.setStreaming = true;

    ParseResponse parseResponse = await liveStreamingModel.save();
    if (parseResponse.success) {
      setupCounterLive(liveStreamingModel.objectId!);
      setupCounterLiveUser();

      NotificationsHelper.sendPush(
          widget.currentUser, widget.currentUser, NotificationsHelper.typeLive,
          objectId: widget.mLiveStreamingModel!.objectId!);
    }
  }

  void openViewUser(UserModel user) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showTheUser(user);
        });
  }

  void openBottomSheet(Widget widget) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return widget;
        });
  }

   void follow(UserModel mUser) async {
    MainHelper.showLoadingDialog(context);

    ParseResponse parseResponseUser;

    widget.currentUser.setFollowing = widget.mUser!.objectId!;
    parseResponseUser = await widget.currentUser.save();

    if (parseResponseUser.success) {
      if (parseResponseUser.results != null) {
        MainHelper.hideLoadingDialog(context);

        setState(() {
          widget.currentUser = parseResponseUser.results!.first as UserModel;
        });
      }
    }

    ParseResponse parseResponse;
    parseResponse = await CloudCodeHelper.followUser(
        isFollowing: false, author: widget.currentUser, receiver: mUser);

    if (parseResponse.success) {
      ActionsHelper.createOrDeleteNotification(widget.currentUser, mUser,
          NotificationsModel.notificationTypeFollowers);
    }
  }

  Widget _showListOfPeopleToBeInvited() {
    QueryBuilder<UserModel> query = QueryBuilder(UserModel.forQuery());
    query.whereContainedIn(UserModel.keyObjectId,
        liveStreamingModel.getViewersId as List<dynamic>);
    query.whereNotEqualTo(UserModel.keyObjectId, widget.currentUser.objectId);

    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.67,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Stack(
                  children: [
                    ContainerCorner(
                      borderWidth: 0,
                      color: Colors.black.withOpacity(0.4),
                      width: size.width,
                      height: size.height,
                      radiusTopRight: 25,
                      radiusTopLeft: 25,
                      imageDecoration: "assets/images/app_bg.png",
                    ),
                    ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topRight: Radius.circular(25),
                        topLeft: Radius.circular(25),
                      ),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                        child: ContainerCorner(
                            color: kTransparentColor,
                            height: size.height,
                            width: size.width),
                      ),
                    ),
                    Container(
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25.0),
                          topRight: Radius.circular(25.0),
                        ),
                      ),
                      child: Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          backgroundColor: kTransparentColor,
                          leading: IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(
                              Icons.close,
                            ),
                          ),
                          actions: [
                            usersToInvite.isNotEmpty
                                ? ContainerCorner(
                                    height: 20,
                                    width: 100,
                                    borderRadius: 10,
                                    marginRight: 20,
                                    marginTop: 10,
                                    marginBottom: 10,
                                    onTap: () {
                                      MainHelper.hideLoadingDialog(context);
                                      sendInvitation(invitedUser);
                                    },
                                    color: kPrimaryColor,
                                    // colors: const [kWarninngColor, kPrimaryColor],
                                    child: Center(
                                        child: TextWithTap(
                                      "live_streaming.invite".tr(),
                                      color: Colors.white,
                                      fontSize: 15,
                                      fontWeight: FontWeight.bold,
                                    )),
                                  )
                                : const SizedBox(),
                          ],
                          automaticallyImplyLeading: false,
                        ),
                        body: ParseLiveListWidget<UserModel>(
                          query: query,
                          reverse: false,
                          lazyLoading: false,
                          shrinkWrap: true,
                          duration: const Duration(milliseconds: 30),
                          childBuilder: (BuildContext context,
                              ParseLiveListElementSnapshot<UserModel>
                                  snapshot) {
                            if (snapshot.hasData) {
                              UserModel user = snapshot.loadedData as UserModel;

                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    if (usersToInvite.contains(user.objectId)) {
                                      usersToInvite.remove(user.objectId);
                                    } else {
                                      if (joinedLiveUsers.isEmpty &&
                                          !widget.mLiveStreamingModel!
                                              .getInvitationAccepted!) {
                                        usersToInvite.add(user.objectId);
                                        invitedUser = user;
                                      }
                                    }
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      left: 10.0, right: 12.0),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: ContainerCorner(
                                          child: Row(
                                            children: [
                                              ContainerCorner(
                                                width: 60,
                                                height: 60,
                                                child: ActionsHelper
                                                    .polygonAvatarWidget(
                                                  currentUser:user,
                                                ),
                                              ),
                                              Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  TextWithTap(
                                                    user.getFullName!,
                                                    marginLeft: 15,
                                                    color: Colors.white,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      usersToInvite.contains(user.objectId)
                                          ? const Icon(
                                              Icons.check_circle,
                                              color: kPrimaryColor,
                                            )
                                          : const Icon(
                                              Icons.radio_button_unchecked,
                                              color: kPrimaryColor,
                                            ),
                                    ],
                                  ),
                                ),
                              );
                            } else {
                              return const Center(
                                child: CircularProgressIndicator(),
                              );
                            }
                          },
                          queryEmptyElement: Center(
                            child: noViewersMessage(),
                          ),
                          listLoadingElement: const Center(
                            child: CircularProgressIndicator(),
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              });
            },
          ),
        ),
      ),
    );
  }

  Widget noViewersMessage() {
    return Center(
      child: TextWithTap(
        'live_streaming.no_viewers'.tr(),
        fontSize: size.width / 19,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  Widget _showTheUser(UserModel user) {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.4,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(clipBehavior: Clip.none, children: [
                    Scaffold(
                      backgroundColor: kTransparentColor,
                      appBar: AppBar(
                        backgroundColor: kTransparentColor,
                        leading: IconButton(
                          onPressed: () => Navigator.of(context).pop(),
                          icon: const Icon(
                            Icons.close,
                          ),
                        ),
                        actions: [
                          IconButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              //openBottomSheet(_showUserSettings());
                            },
                            icon: SvgPicture.asset(
                              "assets/svg/ic_post_config.svg",
                              color: Colors.white,
                            ),
                          ),
                        ],
                        automaticallyImplyLeading: false,
                      ),
                      body: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Center(
                            child: ContainerCorner(
                              height: 25,
                              width: MediaQuery.of(context).size.width,
                              marginLeft: 10,
                              marginRight: 10,
                              child: FittedBox(
                                  child: TextWithTap(
                                user.getFullName!,
                                color: Colors.white,
                              )),
                            ),
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ContainerCorner(
                                child: Row(
                                  children: [
                                    SvgPicture.asset(
                                      "assets/svg/ic_diamond.svg",
                                      width: 20,
                                      height: 20,
                                    ),
                                    TextWithTap(
                                      user.getPoints.toString(),
                                      color: Colors.white,
                                      marginLeft: 5,
                                    )
                                  ],
                                ),
                              ),
                              ContainerCorner(
                                marginLeft: 15,
                                child: Row(
                                  children: [
                                    SvgPicture.asset(
                                      "assets/svg/ic_followers_active.svg",
                                      width: 20,
                                      height: 20,
                                    ),
                                    TextWithTap(
                                      user.getFollowers!.length.toString(),
                                      color: Colors.white,
                                      marginLeft: 5,
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                          ContainerCorner(
                            borderRadius: 50,
                            height: 50,
                            marginLeft: 20,
                            marginRight: 50,
                            marginTop: 20,
                            onTap: () {
                              Navigator.of(context).pop();
                              requestLive();
                            },
                            color: kColorsIndigo300,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  "assets/svg/ic_tab_live_selected.svg",
                                  color: Colors.white,
                                ),
                                TextWithTap(
                                  "live_streaming.ask_to_join_live".tr(),
                                  color: Colors.white,
                                  fontSize: 18,
                                  marginLeft: 5,
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      top: -30,
                      left: 1,
                      right: 1,
                      child: Center(
                        child: ActionsHelper.avatarWidget(user,
                            width: 70, height: 70),
                      ),
                    )
                  ]),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  _showInvitationDialog() {
    setState(() {
      invited = true;
    });
  }

  sendInvitation(UserModel user) async {
    MainHelper.showLoadingDialog(context);

    widget.mLiveStreamingModel!.setInvitedBroadCasterId = user.objectId!;
    widget.mLiveStreamingModel!.setInvitationAccepted = false;

    ParseResponse response = await widget.mLiveStreamingModel!.save();

    if (response.success) {
      setState(() {
        widget.invitedBroadcaster = user;
      });

      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        //user: user,
        title: "live_streaming.invitation_succeed_title".tr(),
        message: "live_streaming.invitation_succeed_explain"
            .tr(namedArgs: {"name": user.getFirstName!}),
        isError: false,
        context: context,
      );
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        //user: user,
        title: "live_streaming.invitation_failed_title".tr(),
        message: "live_streaming.invitation_failed_explain"
            .tr(namedArgs: {"name": user.getFirstName!}),
        isError: true,
        context: context,
      );
    }
  }

  acceptInvitation(UserModel? user) async {
    // joinedLiveUsers.add(user!.objectId);
    inviteAccepted = true;

    setState(() {
      widget.invitedBroadcaster = user;
    });

    /*await _engine.enableVideo();
    await _engine.startPreview();

    await _engine.setChannelProfile(ChannelProfile.LiveBroadcasting);
    await _engine.setClientRole(ClientRole.Broadcaster);*/

    await _engine.enableLocalVideo(true);
    await _engine.startPreview();
    await _engine.setClientRole(ClientRole.Broadcaster);

    setState(() {
      _showChat = true;
      invitedBroadcasterUid = widget.currentUser.getUid!;
      widget.mLiveStreamingModel!.setAuthorInvited = user!;
      widget.mLiveStreamingModel!.setAuthorInvitedUid = user.getUid!;
      widget.mLiveStreamingModel!.setInvitedBroadCasterId = user.objectId!;
      widget.mLiveStreamingModel!.setInvitationAccepted = true;
    });

    await widget.mLiveStreamingModel!.save();
  }

  declineInvitation() async {
    widget.mLiveStreamingModel!.setInvitedBroadCasterId = "";
    widget.mLiveStreamingModel!.setInvitationAccepted = false;

    await widget.mLiveStreamingModel!.save();
  }

  setupCounterLiveUser() async {
    QueryBuilder<UserModel> query = QueryBuilder(UserModel.forQuery());

    if (widget.isBroadcaster) {
      query.whereEqualTo(UserModel.keyObjectId, widget.currentUser.objectId);
    } else {
      query.whereEqualTo(UserModel.keyObjectId, widget.mUser!.objectId);
    }

    subscription = await liveQuery.client.subscribe(query);

    subscription!.on(LiveQueryEvent.update, (user) async {
      if (widget.isBroadcaster) {
        widget.currentUser = user as UserModel;
      } else {
        widget.mUser = user as UserModel;
      }

      setState(() {
        if (!widget.isBroadcaster) {
          mUserDiamonds = widget.mUser!.getPointsTotal!.toString();
        }
      });
    });

    subscription!.on(LiveQueryEvent.enter, (user) {
      if (widget.isBroadcaster) {
        widget.currentUser = user as UserModel;
      } else {
        widget.mUser = user as UserModel;
      }

      setState(() {
        if (!widget.isBroadcaster) {
          mUserDiamonds = widget.mUser!.getPointsTotal!.toString();
        }
      });
    });
  }

  setupCounterLive(String objectId) async {
    QueryBuilder<LiveStreamingModel> query =
        QueryBuilder<LiveStreamingModel>(LiveStreamingModel());

    query.whereEqualTo(LiveStreamingModel.keyObjectId, objectId);
    query.includeObject([
      LiveStreamingModel.keyPrivateLiveGift,
      LiveStreamingModel.keyGiftSenders,
      LiveStreamingModel.keyGiftSendersAuthor,
      LiveStreamingModel.keyAuthor
    ]);

    subscription = await liveQuery.client.subscribe(query);

    subscription!.on(LiveQueryEvent.update, (LiveStreamingModel value) async {

      setState(() {
        widget.mLiveStreamingModel = value;
        liveStreamingModel = value;

        liveCounter = value.getViewersCount.toString();
        diamondsCounter = value.getDiamonds.toString();
      });

      QueryBuilder<LiveStreamingModel> query2 =
          QueryBuilder<LiveStreamingModel>(LiveStreamingModel());
      query2.whereEqualTo(LiveStreamingModel.keyObjectId, objectId);
      query2.includeObject([
        LiveStreamingModel.keyPrivateLiveGift,
        LiveStreamingModel.keyGiftSenders,
        LiveStreamingModel.keyGiftSendersAuthor,
        LiveStreamingModel.keyAuthor
      ]);
      ParseResponse response = await query2.query();

      if (response.success) {
        LiveStreamingModel updatedLive =
            response.results!.first as LiveStreamingModel;

        if (updatedLive.getPrivate == true && !widget.isBroadcaster) {
          if (!updatedLive.getPrivateViewersId!
              .contains(widget.currentUser.objectId)) {
            openPayPrivateLiveSheet(updatedLive);
          }
        }
      }
    });

    subscription!.on(LiveQueryEvent.enter, (LiveStreamingModel value) {
      widget.mLiveStreamingModel = value;
      liveStreamingModel = value;

      setState(() {
        liveCounter = liveStreamingModel.getViewersCount.toString();
        diamondsCounter = liveStreamingModel.getDiamonds.toString();
      });
    });
  }

  void openSettingSheet() async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showSettingsBottomSheet();
        });
  }

  getPoints() async {
    QueryBuilder<LiveStreamingModel> query = QueryBuilder(LiveStreamingModel());
    query.whereEqualTo(
        LiveStreamingModel.keyObjectId, widget.mLiveStreamingModel!.objectId);
    ParseResponse response = await query.query();

    if (response.success && response.result != null) {
      LiveStreamingModel liveStream = response.results?.first;
      livePoints =
          liveStream.getPoints != null ? liveStream.getPoints!.length * 10 : 0;
    }
  }

  addPoints() async {
    if (!widget.mLiveStreamingModel!.getPoints!
            .contains(widget.currentUser.objectId) &&
        !widget.isBroadcaster) {
      widget.mLiveStreamingModel!.setPoints = widget.currentUser.objectId!;
      await widget.mLiveStreamingModel!.save();
    } else if (widget.mLiveStreamingModel!.getPoints!
        .contains(widget.currentUser.objectId)) {
      MainHelper.showAppNotificationAdvanced(
          title: 'live_streaming.cant_add_point_msg'.tr(), context: context);
    }
  }

  Widget streamerBottom() {
    //return Container(color: Colors.green,);

    return Container(
      //color: kRedColor1,
      alignment: Alignment.bottomCenter,
      child: SingleChildScrollView(
        physics: const ClampingScrollPhysics(),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            liveMessages(),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: ContainerCorner(
                    color: kTransparentColor,
                    borderColor: kContentColorDarkTheme,
                    borderRadius: 50,
                    marginLeft: 10,
                    marginRight: 10,
                    child: Row(
                      children: [
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10, right: 10),
                            child: TextField(
                              keyboardType: TextInputType.multiline,
                              style: GoogleFonts.nunito(
                                color: Colors.white,
                              ),
                              onTap: () {
                                setState(() {
                                  visibleKeyBoard = true;
                                });
                              },
                              controller: textEditingController,
                              maxLines: null,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintStyle: const TextStyle(
                                  color: kContentColorDarkTheme,
                                ),
                                hintText: "live_streaming.live_tape_here".tr(),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                ContainerCorner(
                  marginLeft: 10,
                  marginRight: 10,
                  color: kButtonTextColor,
                  borderRadius: 50,
                  height: 50,
                  width: 50,
                  onTap: () {
                    if (textEditingController.text.isNotEmpty) {
                      sendMessage(LiveMessagesModel.messageTypeComment,
                          textEditingController.text, widget.currentUser);
                      textEditingController.clear();
                    }
                  },
                  child: ContainerCorner(
                    color: kTransparentColor,
                    marginAll: 8,
                    height: 30,
                    width: 30,
                    child: SvgPicture.asset(
                      "assets/svg/ic_send_message.svg",
                      color: Colors.white,
                      height: 10,
                      width: 30,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget audienceBottom() {
    return Visibility(
      visible: _showChat,
      child: ContainerCorner(
        alignment: Alignment.bottomCenter,
        marginBottom: MediaQuery.of(context).viewInsets.bottom,
        color: Colors.transparent,
        child: SingleChildScrollView(
          physics: const ClampingScrollPhysics(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              liveMessages(),
              chatInputField(),
            ],
          ),
        ),
      ),
    );
  }

  Widget getGiftsPrices(StateSetter setState) {
    QueryBuilder<GiftsModel> giftQuery = QueryBuilder<GiftsModel>(GiftsModel());
    giftQuery.whereValueExists(GiftsModel.keyGiftCategories, true);
    giftQuery.whereEqualTo(
        GiftsModel.keyGiftCategories, GiftsModel.giftCategoryTypeClassic);

    return ContainerCorner(
      color: kTransparentColor,
      child: ParseLiveGridWidget<GiftsModel>(
        query: giftQuery,
        crossAxisCount: 4,
        reverse: false,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        lazyLoading: false,
        shrinkWrap: true,
        listenOnAllSubItems: true,
        listeningIncludes: [
          LiveStreamingModel.keyAuthor,
          LiveStreamingModel.keyAuthorInvited,
        ],
        duration: const Duration(seconds: 0),
        animationController: _animationController,
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<GiftsModel> snapshot) {
          GiftsModel gift = snapshot.loadedData!;

          if (initGift) {
            setState(() {
              selectedGif = gift;
            });
          }

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedGif = gift;
              });
            },
            child: Column(
              children: [
                Lottie.network(gift.getFile!.url!,
                    width: 60, height: 60, animate: true, repeat: true),
                ContainerCorner(
                  color: kTransparentColor,
                  marginTop: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        "assets/svg/ic_coin_with_star.svg",
                        width: 18,
                        height: 18,
                      ),
                      TextWithTap(
                        gift.getCoins.toString(),
                        color: Colors.white,
                        fontSize: 14,
                        marginLeft: 5,
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
        queryEmptyElement: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ActionsHelper.noContentFound(
              "live_streaming.no_gift_title".tr(),
              "live_streaming.no_gift_explain".tr(),
              "assets/svg/ic_menu_gifters.svg",
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center),
        ),
        gridLoadingElement: Container(
          margin: const EdgeInsets.only(top: 50),
          alignment: Alignment.topCenter,
          child: const CircularProgressIndicator(),
        ),
      ),
    );
  }

  Widget _showGiftToBePaidOnPremiumBottomSheet() {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.85,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Column(
                  children: [
                    ContainerCorner(
                      borderRadius: 10,
                      width: 170,
                      height: 250,
                      marginBottom: 20,
                      colors: const [kPrimaryColor, kWarninngColor],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      child: Scaffold(
                        appBar: AppBar(
                          toolbarHeight: 35.0,
                          backgroundColor: kTransparentColor,
                          automaticallyImplyLeading: false,
                          elevation: 0,
                          actions: [
                            IconButton(
                                onPressed: () => Navigator.of(context).pop(),
                                icon: const Icon(Icons.close)),
                          ],
                        ),
                        backgroundColor: kTransparentColor,
                        body: Column(
                          children: [
                            Center(
                                child: TextWithTap(
                              "live_streaming.premium_price".tr(),
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                              marginBottom: 15,
                            )),
                            Center(
                              child: TextWithTap(
                                "live_streaming.premium_price_explain".tr(),
                                color: Colors.white,
                                fontSize: 12,
                                marginLeft: 10,
                              ),
                            ),
                            if (selectedGif != null)
                              Lottie.network(selectedGif!.getFile!.url!,
                                  width: 90,
                                  height: 97,
                                  animate: true,
                                  repeat: true),
                            Expanded(
                              child: ContainerCorner(
                                borderRadius: 10,
                                height: 30,
                                width: 100,
                                color: kPrimaryColor,
                                onTap: () {
                                  if (selectedGif != null) {
                                    if (liveStreamingModel.getViewersCount! >
                                        0) {
                                      Navigator.pop(context);
                                      openBottomSheet(
                                          _showListOfPeopleToBeInvited());
                                    } else {
                                      _privatizeLive(selectedGif!);
                                    }
                                  } else {
                                    showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            content: Column(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                SvgPicture.asset(
                                                  "assets/svg/sad.svg",
                                                  height: 70,
                                                  width: 70,
                                                ),
                                                TextWithTap(
                                                  "live_streaming.select_price"
                                                      .tr(),
                                                  textAlign: TextAlign.center,
                                                  color: Colors.red,
                                                  marginTop: 20,
                                                ),
                                                const SizedBox(
                                                  height: 35,
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    ContainerCorner(
                                                      color: kRedColor1,
                                                      borderRadius: 10,
                                                      marginLeft: 5,
                                                      width: 125,
                                                      child: TextButton(
                                                        child: TextWithTap(
                                                          "cancel"
                                                              .tr()
                                                              .toUpperCase(),
                                                          color: Colors.white,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 14,
                                                        ),
                                                        onPressed: () {
                                                          Navigator.of(context)
                                                              .pop();
                                                          Navigator.of(context)
                                                              .pop();
                                                        },
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: ContainerCorner(
                                                        color: kGreenColor,
                                                        borderRadius: 10,
                                                        marginRight: 5,
                                                        width: 125,
                                                        child: TextButton(
                                                          child: TextWithTap(
                                                            "get_money.try_again"
                                                                .tr()
                                                                .toUpperCase(),
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 14,
                                                          ),
                                                          onPressed: () =>
                                                              Navigator.of(
                                                                      context)
                                                                  .pop(),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                                const SizedBox(height: 20),
                                              ],
                                            ),
                                          );
                                        });
                                  }
                                },
                                marginTop: 15,
                                marginBottom: 5,
                                child: Center(
                                  child: TextWithTap(
                                    "live_streaming.premium_btn".tr(),
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: ContainerCorner(
                        color: Colors.black.withOpacity(0.5),
                        radiusTopLeft: 25.0,
                        radiusTopRight: 25.0,
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height / 3,
                        child: Scaffold(
                          appBar: AppBar(
                            backgroundColor: kTransparentColor,
                            elevation: 0,
                            automaticallyImplyLeading: false,
                            title: TextWithTap(
                              "live_streaming.gif_prices".tr(),
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                            ),
                            centerTitle: true,
                          ),
                          backgroundColor: kTransparentColor,
                          body: getGiftsPrices(
                              setState), //getClassicGifts(setState)
                        ),
                      ),
                    ),
                  ],
                );
              });
            },
          ),
        ),
      ),
    );
  }

  _privatizeLive(GiftsModel gift, {List? viewersInLiveId}) async {
    MainHelper.showLoadingDialog(context);

    widget.mLiveStreamingModel!.setPrivate = true;
    widget.mLiveStreamingModel!.setPrivateLivePrice = gift;

    if (viewersInLiveId != null) {
      if (viewersInLiveId.isNotEmpty) {
        widget.mLiveStreamingModel!.setPrivateListViewersId = viewersInLiveId;
      }
    }

    ParseResponse response = await widget.mLiveStreamingModel!.save();

    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      Navigator.pop(context);

      setState(() {
        isPrivateLive = true;
        liveTitle = "live_streaming.private_live".tr();
      });
    }
  }

  _unPrivatizeLive(GiftsModel gift) async {
    MainHelper.showLoadingDialog(context);

    widget.mLiveStreamingModel!.setPrivate = false;
    //widget.mLiveStreamingModel!.removePrice = widget.mLiveStreamingModel!.getPrivateLivePrice!;

    ParseResponse response = await widget.mLiveStreamingModel!.save();

    if (response.success) {
        MainHelper.hideLoadingDialog(context);
      setState(() {
        isPrivateLive = false;
        liveTitle = "live_streaming.live_".tr();
      });
    }
  }

  Widget _showSettingsBottomSheet() {
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: 0.67,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Column(
                    children: [
                      const ContainerCorner(
                        color: kGrayColor,
                        width: 50,
                        borderRadius: 20,
                        height: 5,
                        marginTop: 5,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, top: 20),
                        child: TextButton(
                          onPressed: () {
                            _onSwitchCamera();
                            Navigator.of(context).pop();
                          },
                          child: Row(
                            children: [
                              const Icon(
                                Icons.camera_front_outlined,
                                color: Colors.white,
                                size: 20,
                              ),
                              TextWithTap(
                                "live_streaming.switch_camera".tr(),
                                color: Colors.white,
                                marginLeft: 10,
                                fontSize: 18,
                              )
                            ],
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 10, top: 5),
                        child: TextButton(
                          onPressed: () {
                            _onToggleMute();
                            Navigator.of(context).pop();
                          },
                          child: Row(
                            children: [
                              Icon(
                                muted ? Icons.mic : Icons.mic_off_rounded,
                                color: Colors.white,
                                size: 20,
                              ),
                              TextWithTap(
                                "live_streaming.toggle_audio".tr(),
                                color: Colors.white,
                                marginLeft: 10,
                                fontSize: 18,
                              )
                            ],
                          ),
                        ),
                      ),
                      Visibility(
                        visible: !isPrivateLive,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10, top: 5),
                          child: TextButton(
                            onPressed: () {
                              _getDefaultGiftPrice();
                              Navigator.of(context).pop();
                              openBottomSheet(
                                  _showGiftToBePaidOnPremiumBottomSheet());
                            },
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.vpn_key_outlined,
                                  color: Colors.white,
                                  size: 18,
                                ),
                                TextWithTap(
                                  "live_streaming.privatize_live".tr(),
                                  color: Colors.white,
                                  marginLeft: 10,
                                  fontSize: 18,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                      Visibility(
                        visible: isPrivateLive,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10, top: 5),
                          child: TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                              _unPrivatizeLive(selectedGif!);
                            },
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.public,
                                  color: Colors.white,
                                  size: 18,
                                ),
                                TextWithTap(
                                  "live_streaming.unset_private_live".tr(),
                                  color: Colors.white,
                                  marginLeft: 10,
                                  fontSize: 18,
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  Tab gefTab(String name, String image) {
    return Tab(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            image,
            color: Colors.white.withOpacity(0.7),
            width: 20,
            height: 20,
          ),
          TextWithTap(
            name,
            fontSize: 12,
            marginTop: 5,
          ),
        ],
      ),
    );
  }

  Widget chatInputField() {
    return ContainerCorner(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: ContainerCorner(
              color: kTransparentColor,
              borderColor: kContentColorDarkTheme,
              borderRadius: 50,
              marginLeft: 10,
              marginRight: 10,
              child: Padding(
                padding: const EdgeInsets.only(top: 5, left: 10),
                child: TextField(
                  keyboardType: TextInputType.multiline,
                  style: GoogleFonts.nunito(
                    color: Colors.white,
                  ),
                  onChanged: (text) {
                    if (text.isNotEmpty) {
                      toggleSendButton(true);
                    } else {
                      toggleSendButton(false);
                    }
                  },
                  focusNode: chatTextFieldFocusNode,
                  minLines: 1,
                  maxLines: 2,
                  controller: textEditingController,
                  decoration: InputDecoration(
                    hintText: "comment_post.leave_comment".tr(),
                    hintStyle: GoogleFonts.nunito(color: Colors.white),
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
          ),
          Visibility(
            visible: _hideSendButton,
            child: ContainerCorner(
              marginLeft: 10,
              color: kButtonTextColor,
              borderRadius: 50,
              height: 45,
              width: 45,
              onTap: () {
                if (textEditingController.text.isNotEmpty) {
                  sendMessage(LiveMessagesModel.messageTypeComment,
                      textEditingController.text, widget.currentUser);
                  setState(() {
                    textEditingController.text = "";
                    visibleAudienceKeyBoard = false;
                  });
                  toggleSendButton(false);
                }
              },
              child: ContainerCorner(
                color: kTransparentColor,
                marginAll: 5,
                height: 30,
                width: 30,
                child: SvgPicture.asset(
                  "assets/svg/ic_send_message.svg",
                  color: Colors.white,
                  height: 10,
                  width: 30,
                ),
              ),
            ),
          ),
          Visibility(
            visible: !_hideSendButton,
            child: ContainerCorner(
              marginAll: 5,
              color: kButtonTextColor,
              borderRadius: 50,
              height: 50,
              width: 50,
              onTap: () {
                CoinsFlowPayment(
                  context: context,
                  currentUser: widget.currentUser,
                  onCoinsPurchased: (coins) {},
                  onGiftSelected: (gift) {
                    sendGift(gift);

                    MainHelper.goBackToPreviousPage(context);
                    /*MainHelper.showAppNotificationAdvanced(
                      context: context,
                      user: widget.currentUser,
                      title: "live_streaming.gift_sent_title".tr(),
                      message: "live_streaming.gift_sent_explain".tr(
                        namedArgs: {"name": widget.mUser!.getFirstName!},
                      ),
                      isError: false,
                    );*/
                  },
                );
              },
              child: ContainerCorner(
                color: kTransparentColor,
                marginAll: 8,
                height: 30,
                width: 30,
                child: SvgPicture.asset(
                  "assets/svg/ic_menu_gifters.svg",
                  color: Colors.white,
                  height: 10,
                  width: 30,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  sendMessage(
    String messageType,
    String message,
    UserModel author, {
    GiftsSentModel? giftsSent,
  }) async {
    if (messageType == LiveMessagesModel.messageTypeGift) {
      // MainHelper.goBackToPreviousPage(context);
      //MainHelper.goBackToPreviousPage(context);

      liveStreamingModel.addDiamonds =
          MainHelper.getDiamondsForReceiver(giftsSent!.getDiamondsQuantity!);

      liveStreamingModel.setCoHostAuthorUid = author.getUid!;
      liveStreamingModel.addAuthorTotalDiamonds =
          MainHelper.getDiamondsForReceiver(giftsSent.getDiamondsQuantity!);

      await liveStreamingModel.save();

      addOrUpdateGiftSender(giftsSent.getGift!);

      await CloudCodeHelper.sendGift(
          author: widget.mUser!, credits: giftsSent.getDiamondsQuantity!);
    }

    LiveMessagesModel liveMessagesModel = LiveMessagesModel();
    liveMessagesModel.setAuthor = author;
    liveMessagesModel.setAuthorId = author.objectId!;

    liveMessagesModel.setLiveStreaming = widget.mLiveStreamingModel!;
    liveMessagesModel.setLiveStreamingId =
        widget.mLiveStreamingModel!.objectId!;

    if (giftsSent != null) {
      liveMessagesModel.setGiftSent = giftsSent;
      liveMessagesModel.setGiftSentId = giftsSent.objectId!;
    }

    if (messageType == LiveMessagesModel.messageTypeCoHost) {
      liveMessagesModel.setCoHostAuthor = widget.currentUser;
      liveMessagesModel.setCoHostAuthorUid = widget.currentUser.getUid!;
      liveMessagesModel.setCoHostAvailable = false;
    }

    liveMessagesModel.setMessage = message;
    liveMessagesModel.setMessageType = messageType;
    await liveMessagesModel.save();
  }

  Widget liveMessages() {
    if (widget.isBroadcaster && liveMessageSent == false) {
      NotificationsHelper.sendPush(
          widget.currentUser, widget.currentUser, NotificationsHelper.typeLive,
          objectId: widget.mLiveStreamingModel!.objectId!);
      sendMessage(
          LiveMessagesModel.messageTypeSystem,
          "live_streaming.live_streaming_created_message".tr(),
          widget.currentUser);
      liveMessageSent = true;
    }

    QueryBuilder<LiveMessagesModel> queryBuilder =
        QueryBuilder<LiveMessagesModel>(LiveMessagesModel());
    queryBuilder.whereEqualTo(LiveMessagesModel.keyLiveStreamingId,
        widget.mLiveStreamingModel!.objectId);
    queryBuilder.includeObject([
      LiveMessagesModel.keySenderAuthor,
      LiveMessagesModel.keyLiveStreaming,
      LiveMessagesModel.keyGift,
      LiveMessagesModel.keyGiftSentGift
    ]);
    queryBuilder.orderByDescending(LiveMessagesModel.keyCreatedAt);

    var size = MediaQuery.of(context).size;
    return ContainerCorner(
      marginLeft: 10,
      marginRight: 10,
      height: 300,
      width: size.width / 1.3,
      marginBottom: 15,
      colors: [kContentColorLightTheme.withOpacity(0.2),
        kContentColorLightTheme.withOpacity(0.1)
      ],
      child: ParseLiveListWidget<LiveMessagesModel>(
        query: queryBuilder,
        reverse: true,
        duration: const Duration(microseconds: 500),
        childBuilder: (BuildContext context,
            ParseLiveListElementSnapshot<LiveMessagesModel> snapshot) {
          if (snapshot.failed) {
            return Text('not_connected'.tr());
          } else if (snapshot.hasData) {
            LiveMessagesModel liveMessage = snapshot.loadedData!;

            bool isMe =
                liveMessage.getAuthorId == widget.currentUser.objectId &&
                    liveMessage.getLiveStreaming!.getAuthorId! ==
                        widget.currentUser.objectId;

            return getMessages(liveMessage, isMe);
          } else {
            return Container();
          }
        },
        queryEmptyElement: Container(),
      ),
    );
  }

  Widget getMessages(LiveMessagesModel liveMessages, bool isMe) {
    if (isMe) {
      if (liveMessages.getMessageType == LiveMessagesModel.messageTypeLike) {
        return messageLike(nameOrYou(liveMessages), liveMessages.getAuthor!);
      } else {
        return messageAvatar(
            "live_streaming.you_".tr(),
            liveMessages.getMessageType == LiveMessagesModel.messageTypeSystem
                ? "live_streaming.live_streaming_created_message".tr()
                : liveMessages.getMessage!,
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor!);
      }
    } else {
      if (liveMessages.getMessageType == LiveMessagesModel.messageTypeLike) {
        return messageLike(nameOrYou(liveMessages), liveMessages.getAuthor!);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeSystem) {
        return messageAvatar(
            nameOrYou(liveMessages),
            "live_streaming.live_streaming_created_message".tr(),
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeJoin) {
        return messageAvatar(
            nameOrYou(liveMessages),
            "live_streaming.live_streaming_watching".tr(),
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor!);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeComment) {
        return messageAvatar(nameOrYou(liveMessages), liveMessages.getMessage!,
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeFollow) {
        return messageAvatar(
            nameOrYou(liveMessages),
            "live_streaming.new_follower".tr(),
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeGift) {
        return messageGift(
            nameOrYou(liveMessages),
            "live_streaming.new_gift".tr(),
            liveMessages.getGiftSent!.getGift!.getFile!.url!,
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor!);
      } else if (liveMessages.getMessageType ==
          LiveMessagesModel.messageTypeCoHost) {
        return widget.isBroadcaster ||
                widget.currentUser.objectId == liveMessages.getAuthorId
            ? messageCoHost(
                nameOrYou(liveMessages),
                "live_streaming.ask_permition".tr(),
                liveMessages.getAuthor!,
                liveMessages,
                liveMessages.getAuthor!.getAvatar!.url!,
                liveMessages.getLiveStreaming!)
            : Container();
      } else {
        return messageAvatar(nameOrYou(liveMessages), liveMessages.getMessage!,
            liveMessages.getAuthor!.getAvatar!.url!,
            user: liveMessages.getAuthor!);
      }
    }
  }

  String nameOrYou(LiveMessagesModel liveMessage) {
    if (liveMessage.getAuthorId == widget.currentUser.objectId) {
      return "live_streaming.you_".tr();
    } else {
      return liveMessage.getAuthor!.getFullName!;
    }
  }

  Widget messageCoHost(String title, String message, UserModel cohostAuthor,
      LiveMessagesModel messagesModel, avatarUrl, LiveStreamingModel live) {
    return ContainerCorner(
      borderRadius: 50,
      marginBottom: 5,
      // colors: [Colors.black.withOpacity(0.5), Colors.black.withOpacity(0.02)],
      child: Row(
        children: [
          ContainerCorner(
            width: 50,
            height: 50,
            color: kRedColor1,
            borderRadius: 50,
            marginRight: 10,
            child: ActionsHelper.photosWidgetCircle(avatarUrl,
                width: 10, height: 10, boxShape: BoxShape.circle),
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 3.0, top: 10.0),
                  child: RichText(
                      text: TextSpan(children: [
                    TextSpan(
                      text: title,
                      style: const TextStyle(
                        color: kContentColorDarkTheme,
                        fontSize: 13.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ])),
                ),
                RichText(
                    text: TextSpan(children: [
                  TextSpan(
                    text: message,
                    style: const TextStyle(color: Colors.white, fontSize: 11.8),
                  ),
                ])),
              ],
            ),
          ),
          const SizedBox(
            width: 5,
          ),
          Visibility(
            visible: hostButtonCondition(cohostAuthor, messagesModel),
            child: ContainerCorner(
              colors: const [kWarninngColor, kPrimaryColor],
              borderRadius: 10,
              width: 100,
              height: 40,
              child: TextButton(
                  onPressed: () =>
                      acceptCoHost(cohostAuthor, messagesModel, live),
                  child: TextWithTap(
                    hostButton(cohostAuthor, messagesModel),
                    color: Colors.white,
                  )),
            ),
          ),
        ],
      ),
    );
  }

  acceptCoHost(UserModel userModel, LiveMessagesModel message,
      LiveStreamingModel live) async {
    if (widget.isBroadcaster) {
      MainHelper.showLoadingDialog(context);

      live.setCoHostUID = userModel.getUid!;
      ParseResponse response = await widget.mLiveStreamingModel!.save();

      if (response.success && !message.getCoHostAuthorAvailable!) {
        message.setCoHostAvailable = true;
        message.setCoHostAuthorUid = userModel.getUid!;
        message.setCoHostAuthor = userModel;

        await message.save();

        MainHelper.hideLoadingDialog(context);
      }
    } else {
      if (message.getCoHostAuthorAvailable! && !coHostAvailable) {
        await _engine.enableLocalVideo(true);
        await _engine.setClientRole(ClientRole.Broadcaster);

        setState(() {
          coHostAvailable = true;
          //coHostUid = currentUser!.getUid!;
          //coHostUser = currentUser;
        });
      }
    }
  }

  Widget messageAvatar(String title, String message, avatarUrl,
      {UserModel? user}) {
    return ContainerCorner(
      borderRadius: 50,
      marginBottom: 5,
      // colors: [Colors.black.withOpacity(0.5), Colors.black.withOpacity(0.02)],
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ContainerCorner(
            width: 50,
            height: 50,
            color: kTransparentColor,
            borderRadius: 50,
            marginRight: 10,
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:user!, fontSize: 10),
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 3.0, top: 10.0),
                  child: RichText(
                      text: TextSpan(children: [
                    TextSpan(
                      text: title,
                      style: const TextStyle(
                        color: kContentColorDarkTheme,
                        fontSize: 13.5,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ])),
                ),
                RichText(
                    text: TextSpan(children: [
                  TextSpan(
                    text: message,
                    style: const TextStyle(color: Colors.white, fontSize: 11.8),
                  ),
                ])),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget messageNoAvatar(String title, String message) {
    return Container(
      margin: const EdgeInsets.only(bottom: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 3.0, top: 10.0),
            child: RichText(
                text: TextSpan(children: [
              TextSpan(
                text: title,
                style: const TextStyle(
                  color: kContentColorDarkTheme,
                  fontSize: 13.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ])),
          ),
          RichText(
              text: TextSpan(children: [
            TextSpan(
              text: message,
              style: const TextStyle(color: Colors.white, fontSize: 11.8),
            ),
          ])),
        ],
      ),
    );
  }

  Widget messageGift(String title, String message, String giftUrl, avatarUrl,
      {UserModel? user}) {
    return ContainerCorner(
      borderRadius: 50,
      marginBottom: 5,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ContainerCorner(
            width: 50,
            height: 50,
            color: kTransparentColor,
            borderRadius: 50,
            marginRight: 10,
            marginTop: 7,
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:user!, fontSize: 10),
          ),
          Flexible(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(bottom: 3.0, top: 15.0),
                      child: RichText(
                          text: TextSpan(children: [
                        TextSpan(
                          text: title,
                          style: const TextStyle(
                            color: kContentColorDarkTheme,
                            fontSize: 13.5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ])),
                    ),
                    Row(
                      children: [
                        RichText(
                            text: TextSpan(children: [
                          TextSpan(
                            text: message,
                            style: const TextStyle(color: Colors.white, fontSize: 11.8),
                          ),
                        ])),
                      ],
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.only(top:15.0),
                  child: SizedBox(
                      width: 50,
                      height: 50,
                      child: Lottie.network(giftUrl,
                          width: 35, height: 35, animate: true, repeat: true)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget messageLike(String title, UserModel? author) {
    return ContainerCorner(
      borderRadius: 50,
      marginBottom: 5,
      // colors: [Colors.black.withOpacity(0.5), Colors.black.withOpacity(0.02)],
      child: Row(
        children: [
          ContainerCorner(
            width: 50,
            height: 50,
            color: kTransparentColor,
            borderRadius: 50,
            marginRight: 10,
            child: ActionsHelper.polygonAvatarWidget(
                currentUser:author!, fontSize: 10),
          ),
          Flexible(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 3.0, top: 10.0),
                  child: Column(
                    children: [
                      RichText(
                          text: TextSpan(children: [
                        TextSpan(
                          text: title,
                          style: const TextStyle(
                            color: kContentColorDarkTheme,
                            fontSize: 13.5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ])),
                    ],
                  ),
                ),
                Image.asset(
                  'assets/images/ic_thumbs_up.png',
                  width: 35,
                  height: 35,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String hostButton(UserModel author, LiveMessagesModel message) {
    if (widget.isBroadcaster) {
      if (message.getCoHostAuthorAvailable!) {
        return "live_streaming.accepted_btn".tr();
      } else {
        return "live_streaming.accept_btn".tr();
      }
    } else if (message.getAuthor!.objectId! == widget.currentUser.objectId) {
      if (message.getCoHostAuthorAvailable!) {
        return "live_streaming.join_now_btn".tr();
      } else {
        return "live_streaming.pending_btn".tr();
      }
    } else {
      return "";
    }
  }

  bool hostButtonCondition(UserModel author, LiveMessagesModel message) {
    if (widget.isBroadcaster) {
      return true;
    } else if (message.getAuthor!.objectId! == widget.currentUser.objectId) {
      return true;
    } else {
      return false;
    }
  }

  sendGift(GiftsModel giftsModel) async {
    widget.mLiveStreamingModel!.setGifSenderImage =
        widget.currentUser.getAvatar!;

    GiftsSentModel giftsSentModel = GiftsSentModel();
    giftsSentModel.setAuthor = widget.currentUser;
    giftsSentModel.setAuthorId = widget.currentUser.objectId!;

    giftsSentModel.setReceiver = widget.mUser!;
    giftsSentModel.setReceiverId = widget.mUser!.objectId!;

    giftsSentModel.setGift = giftsModel;
    giftsSentModel.setGiftId = giftsModel.objectId!;
    giftsSentModel.setCounterDiamondsQuantity = giftsModel.getCoins!;
    ParseResponse parseResponse = await giftsSentModel.save();

    if (parseResponse.success) {
      updateCurrentUser(giftsSentModel.getDiamondsQuantity!);

      sendMessage(LiveMessagesModel.messageTypeGift, "", widget.currentUser,
          giftsSent: giftsSentModel);
    }
  }

  updateCurrentUser(int coins) async {
    widget.currentUser.removeCredit = coins;
    ParseResponse response = await widget.currentUser.save();

    if (response.success) {
      widget.currentUser = response.results!.first as UserModel;
    }
  }

  void openPayPrivateLiveSheet(LiveStreamingModel live) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        enableDrag: false,
        isDismissible: false,
        builder: (context) {
          return _showPayPrivateLiveBottomSheet(live);
        });
  }

  Widget _showPayPrivateLiveBottomSheet(LiveStreamingModel live) {
    return Container(
      color: const Color.fromRGBO(0, 0, 0, 0.001),
      child: GestureDetector(
        onTap: () {},
        child: DraggableScrollableSheet(
          initialChildSize: 0.89,
          minChildSize: 0.1,
          maxChildSize: 1.0,
          builder: (_, controller) {
            return StatefulBuilder(builder: (context, setState) {
              return Container(
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.9),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(25.0),
                    topRight: Radius.circular(25.0),
                  ),
                ),
                child: Scaffold(
                  appBar: AppBar(
                    toolbarHeight: 35.0,
                    backgroundColor: kTransparentColor,
                    automaticallyImplyLeading: false,
                    elevation: 0,
                    actions: [
                      IconButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                            closeAlert();
                          },
                          icon: const Icon(Icons.close)),
                    ],
                  ),
                  backgroundColor: kTransparentColor,
                  body: Column(
                    children: [
                      Center(
                          child: TextWithTap(
                        "live_streaming.private_live".tr(),
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 25,
                        marginBottom: 15,
                      )),
                      Center(
                        child: TextWithTap(
                          "live_streaming.private_live_explain".tr(),
                          color: Colors.white,
                          fontSize: 16,
                          marginLeft: 20,
                          marginRight: 20,
                          marginTop: 20,
                        ),
                      ),
                      Expanded(
                          child: Lottie.network(
                              live.getPrivateGift!.getFile!.url!,
                              width: 150,
                              height: 150,
                              animate: true,
                              repeat: true)),
                      ContainerCorner(
                        color: kTransparentColor,
                        marginTop: 1,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              "assets/svg/ic_coin_with_star.svg",
                              width: 24,
                              height: 24,
                            ),
                            TextWithTap(
                              live.getPrivateGift!.getCoins.toString(),
                              color: Colors.white,
                              fontSize: 18,
                              marginLeft: 5,
                            )
                          ],
                        ),
                      ),
                      ContainerCorner(
                        borderRadius: 10,
                        height: 50,
                        width: 150,
                        color: kPrimaryColor,
                        onTap: () {
                          if (widget.currentUser.getCredits! >=
                              live.getPrivateGift!.getCoins!) {
                            _payForPrivateLive(live);
                          } else {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    content: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 15.0),
                                          child: CircleAvatar(
                                            radius: 48,
                                            backgroundColor: Colors.white,
                                            child: SvgPicture.asset(
                                              "assets/svg/sad.svg",
                                              color: kRedColor1,
                                            ),
                                          ),
                                        ),
                                        Text(
                                          "live_streaming.not_enough_coins"
                                              .tr(),
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            fontSize: 19,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 35,
                                        ),
                                        ButtonWithGradient(
                                          borderRadius: 100,
                                          text: "live_streaming.get_credit_btn"
                                              .tr(),
                                          marginLeft: 15,
                                          marginRight: 15,
                                          height: 50,
                                          beginColor: kWarninngColor,
                                          endColor: kPrimaryColor,
                                          onTap: () {
                                            Navigator.pop(context);
                                            //Navigator.pop(context);
                                            CoinsFlowPayment(
                                              context: context,
                                              currentUser: widget.currentUser,
                                              showOnlyCoinsPurchase: true,
                                              onCoinsPurchased: (coins) {
                                                Navigator.pop(context);
                                              },
                                              onGiftSelected: (gift) {},
                                            );
                                            //Navigator.pop(context);
                                            //Navigator.pop(context);
                                          },
                                        ),
                                        const SizedBox(height: 20),
                                      ],
                                    ),
                                  );
                                });
                          }
                        },
                        marginTop: 15,
                        marginBottom: 40,
                        child: Center(
                          child: TextWithTap(
                            "live_streaming.pay_for_live".tr(),
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            });
          },
        ),
      ),
    );
  }

  updateCurrentUserCredit(int coins) async {
    widget.currentUser.removeCredit = coins;
    ParseResponse response = await widget.currentUser.save();
    if (response.success) {
      widget.currentUser = response.results!.first as UserModel;
    }
  }

  _payForPrivateLive(LiveStreamingModel live) async {
    MainHelper.showLoadingDialog(context);

    sendGift(live.getPrivateGift!);
    live.setPrivateViewersId = widget.currentUser.objectId!;
    ParseResponse response = await live.save();

    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      Navigator.pop(context);
    }
  }

  _secureScreen(bool isSecureScreen) async {
    if (isSecureScreen) {
      if (MainHelper.isAndroidPlatform()) {
        await FlutterWindowManager.addFlags(FlutterWindowManager.FLAG_SECURE);
      }
    } else {
      if (MainHelper.isAndroidPlatform()) {
        await FlutterWindowManager.clearFlags(FlutterWindowManager.FLAG_SECURE);
      }
    }
  }

  addOrUpdateGiftSender(GiftsModel giftsModel) async {
    QueryBuilder<GiftsSenderModel> queryGiftSender =
        QueryBuilder<GiftsSenderModel>(GiftsSenderModel());

    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyAuthorId, widget.currentUser);
    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyReceiverId, widget.mUser!.objectId);
    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyLiveId, widget.mLiveStreamingModel!.objectId!);

    ParseResponse parseResponse = await queryGiftSender.query();
    if (parseResponse.success) {
      if (parseResponse.results != null) {
        GiftsSenderModel giftsSenderModel =
            parseResponse.results!.first! as GiftsSenderModel;
        giftsSenderModel.addDiamonds = giftsModel.getCoins!;
        await giftsSenderModel.save();

        widget.mLiveStreamingModel!.addGiftsSenders = giftsSenderModel;
        widget.mLiveStreamingModel!.save();
      } else {
        GiftsSenderModel giftsSenderModel = GiftsSenderModel();
        giftsSenderModel.setAuthor = widget.currentUser;
        giftsSenderModel.setAuthorId = widget.currentUser.objectId!;
        giftsSenderModel.setAuthorName = widget.currentUser.getFullName!;

        giftsSenderModel.setReceiver = widget.mUser!;
        giftsSenderModel.setReceiverId = widget.mUser!.objectId!;

        giftsSenderModel.addDiamonds = giftsModel.getCoins!;

        giftsSenderModel.setLiveId = widget.mLiveStreamingModel!.objectId!;
        await giftsSenderModel.save();

        widget.mLiveStreamingModel!.addGiftsSenders = giftsSenderModel;
        widget.mLiveStreamingModel!.save();
      }
    }

    addOrUpdateGiftSenderGlobal(giftsModel);
  }

  addOrUpdateGiftSenderGlobal(GiftsModel giftsModel) async {
    QueryBuilder<GiftsSenderGlobalModel> queryGiftSender =
        QueryBuilder<GiftsSenderGlobalModel>(GiftsSenderGlobalModel());

    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyAuthorId, widget.currentUser);
    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyReceiverId, widget.mUser!.objectId);

    ParseResponse parseResponse = await queryGiftSender.query();
    if (parseResponse.success) {
      if (parseResponse.results != null) {
        GiftsSenderGlobalModel giftsSenderModel =
            parseResponse.results!.first! as GiftsSenderGlobalModel;
        giftsSenderModel.addDiamonds = giftsModel.getCoins!;
        await giftsSenderModel.save();
      } else {
        GiftsSenderGlobalModel giftsSenderModel = GiftsSenderGlobalModel();
        giftsSenderModel.setAuthor = widget.currentUser;
        giftsSenderModel.setAuthorId = widget.currentUser.objectId!;
        giftsSenderModel.setAuthorName = widget.currentUser.getFullName!;

        giftsSenderModel.setReceiver = widget.mUser!;
        giftsSenderModel.setReceiverId = widget.mUser!.objectId!;

        giftsSenderModel.addDiamonds = giftsModel.getCoins!;

        await giftsSenderModel.save();
      }
    }
  }

  setupGiftSendersLiveQuery() async {
    QueryBuilder<GiftsSenderModel> queryGiftSender =
        QueryBuilder<GiftsSenderModel>(GiftsSenderModel());
    queryGiftSender.whereEqualTo(
        GiftsSenderModel.keyLiveId, widget.mLiveStreamingModel!.objectId!);
    queryGiftSender.includeObject(
        [GiftsSenderModel.keyAuthor, GiftsSenderModel.keyAuthor]);

    subscription = await liveQuery.client.subscribe(queryGiftSender);

    subscription!.on(LiveQueryEvent.update, (GiftsSenderModel value) async {
      setState(() {});
    });

    subscription!.on(LiveQueryEvent.enter, (GiftsSenderModel value) {
      setState(() {});
    });
  }

  setupControlLiveQuery() async {
    QueryBuilder<LiveStreamingModel> query =
        QueryBuilder<LiveStreamingModel>(LiveStreamingModel());
    query.whereEqualTo(
        LiveStreamingModel.keyObjectId, widget.mLiveStreamingModel!.objectId);

    query.includeObject(
        [LiveStreamingModel.keyAuthor, LiveStreamingModel.keyAuthorInvited]);

    subscription = await liveQuery.client.subscribe(query);

    subscription!.on(LiveQueryEvent.update, (LiveStreamingModel value) async {
      if (!value.getStreaming!) {
        if (widget.isBroadcaster) {
          _onCallEnd(context);
        }
      } else {
        if (value.getInvitationAccepted! && !widget.isBroadcaster) {
          setState(() {
            widget.mLiveStreamingModel!.setInvitationAccepted =
                value.getInvitationAccepted!;
            widget.mLiveStreamingModel!.setInvitedBroadCasterId =
                value.getInvitedBroadCasterId!;
            widget.invitedBroadcaster = value.getAuthorInvited;
            invitedBroadcasterUid = value.getAuthorInvited!.getUid!;
          });
        } else if (!value.getInvitationAccepted! &&
            value.getInvitedBroadCasterId == '') {
          setState(() {
            widget.invitedBroadcaster = null;
            widget.mLiveStreamingModel!.setInvitationAccepted =
                value.getInvitationAccepted!;
            widget.mLiveStreamingModel!.setInvitedBroadCasterId =
                value.getInvitedBroadCasterId!;
          });
        } else if (value.getInvitedBroadCasterId ==
                widget.currentUser.objectId &&
            !value.getInvitationAccepted!) {
          setState(() {
            if (!inviteAccepted) {
              _showInvitationDialog();
            }
          });
        }

        if (value.getPoints!.length * 10 > livePoints) {
          setState(() {
            livePoints = value.getPoints!.length * 10;
          });

          if (widget.isBroadcaster) {
            int points = widget.currentUser.getChallengePoint ?? 0;
            widget.currentUser.setChallengePoint =
                points + Config.userLivePoints;
            widget.currentUser.save();

            if (value.getPoints!.length * 10 ==
                widget.mLiveStreamingModel!.getLimitCredit!) {
              saveLiveUpdate();
            }
          }
        }

        if (widget.isBroadcaster &&
            value.getInvitedBroadCasterId == '' &&
            value.getAuthorInvitedUid == 0) {
          usersToInvite = [];
        }
      }
    });

    subscription!.on(LiveQueryEvent.enter, (LiveStreamingModel value) {
      setState(() {});
    });
  }

  Widget btnBrodcasterActions() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      actionButton(muted ? Icons.mic : Icons.mic_off_rounded, _onToggleMute),
      actionButton(Icons.group_add, invitePeople),
      actionButton(Icons.cameraswitch_sharp, _onSwitchCamera),
      actionButton(
          Icons.crop_landscape_outlined, switchPortraitOrLandscapeMode),
    ] // List.generate(imagesPath.length, (index) => action(imagesPath[index], (){})),
        );
  }

  Widget btnAudienceActions() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      /*action('assets/svg/ic_stop_live.svg', addPoints),
      action('assets/svg/ic_ask_mimi_game.svg', askForMimiGame),
      action('assets/svg/ic_app_share_video.svg', shareLive),*/
      actionButton(Icons.thumb_up, likeLive),
      actionButton(Icons.chat, showChatState),
      actionButton(Icons.flag, reportLive),
    ] // List.generate(imagesPath.length, (index) => action(imagesPath[index], (){})),
        );
  }

  Widget action(String imagePath, VoidCallback action) {
    return GestureDetector(
      onTap: action,
      child: SvgPicture.asset(
        imagePath,
        height: MediaQuery.of(context).orientation == Orientation.landscape
            ? size.width / 15
            : size.width / 5,
        width: MediaQuery.of(context).orientation == Orientation.landscape
            ? size.width / 15
            : size.width / 5,
      ),
    );
  }

  Widget actionButton(IconData icon, VoidCallback action) {
    return ContainerCorner(
      onTap: action,
      height: MediaQuery.of(context).orientation == Orientation.landscape
          ? size.width / 20
          : size.width / 7,
      width: MediaQuery.of(context).orientation == Orientation.landscape
          ? size.width / 20
          : size.width / 7,
      marginLeft: 10,
      marginRight: 10,
      marginTop: 16,
      marginBottom: 16,
      color: kButtonTextColor,
      borderRadius: 50,
      child: Center(
        child: Icon(
          icon,
          size: MediaQuery.of(context).orientation == Orientation.landscape
              ? size.width / 30
              : size.width / 15,
          color: kContentColorDarkTheme,
        ),
      ),
    );
  }

  // Broadcaster's buttons methods
  invitePeople() {
    openBottomSheet(_showListOfPeopleToBeInvited());
  }

  addFilters() {}

  switchPortraitOrLandscapeMode() {
    if (MediaQuery.of(context).orientation == Orientation.landscape) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft]);
    }
  }

  // Audience's buttons methods
  askForMimiGame() {}

  shareLive() {}

  likeLive() {
    sendMessage(LiveMessagesModel.messageTypeLike, '', widget.currentUser);
  }

  reportLive() {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: true,
        backgroundColor: kTransparentColor,
        // Colors.black.withOpacity(0.4),
        enableDrag: true,
        isDismissible: true,
        builder: (context) {
          return _showPostOptionsAndReportAuthor();
        });
  }

  Widget _showPostOptionsAndReportAuthor() {
    List<dynamic> reportReason = [
      ReportModel.thisPosHasSexualContents,
      ReportModel.fakeProfileSpan,
      ReportModel.inappropriateMessage,
      ReportModel.someoneIsInDanger,
    ];

    return GestureDetector(
      onTap: () => MainHelper.goBackToPreviousPage(context),
      child: Container(
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        height: size.height,
        child: GestureDetector(
          onTap: () {},
          child: DraggableScrollableSheet(
            initialChildSize: size.height <= 570 ? 0.6 : 0.5,
            minChildSize: 0.1,
            maxChildSize: 1.0,
            builder: (_, controller) {
              return StatefulBuilder(builder: (context, setState) {
                var size = MediaQuery.of(context).size;
                return Container(
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Stack(
                    children: [
                      ContainerCorner(
                        borderWidth: 0,
                        color: Colors.black.withOpacity(0.4),
                        width: size.width,
                        height: size.height,
                        radiusTopRight: 25,
                        radiusTopLeft: 25,
                        imageDecoration: "assets/images/app_bg.png",
                      ),
                      ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topRight: Radius.circular(25),
                          topLeft: Radius.circular(25),
                        ),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: ContainerCorner(
                              color: kTransparentColor,
                              height: size.height,
                              width: size.width),
                        ),
                      ),
                      Scaffold(
                        backgroundColor: kTransparentColor,
                        appBar: AppBar(
                          automaticallyImplyLeading: false,
                          backgroundColor: kTransparentColor,
                          centerTitle: true,
                          actions: [
                            IconButton(
                                onPressed: () =>
                                    MainHelper.goBackToPreviousPage(context),
                                icon: const Icon(
                                  Icons.close,
                                  color: Colors.white,
                                  size: 25,
                                ))
                          ],
                          title: TextWithTap(
                            "video.report_reason_title".tr(),
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        body: ContainerCorner(
                          radiusTopRight: 20.0,
                          radiusTopLeft: 20.0,
                          color: kTransparentColor,
                          child: SingleChildScrollView(
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: List.generate(
                                  reportReason.length,
                                  (index) => Column(
                                        children: [
                                          ButtonWithIcon(
                                            text: MainHelper.getReportMessage(
                                                reportReason[index]),
                                            iconColor: kPrimaryColor,
                                            height: 50,
                                            marginLeft: 10,
                                            marginRight: 10,
                                            backgroundColor:
                                                Colors.white.withOpacity(0.1),
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            textColor: Colors.white,
                                            fontSize: 17,
                                            fontWeight: FontWeight.w500,
                                            onTap: () {
                                              createReport(
                                                  MainHelper.getReportMessage(
                                                      reportReason[index]));
                                            },
                                          ),
                                          const Divider(),
                                        ],
                                      )),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                );
              });
            },
          ),
        ),
      ),
    );
  }

  createReport(String message) async {
    MainHelper.showLoadingDialog(context);

    ReportModel report = ReportModel();

    report.setAccuser = widget.currentUser;
    report.setAccusedId = widget.currentUser.objectId!;

    report.setAccused = widget.mLiveStreamingModel!.getAuthor!;
    report.setAccuserId = widget.mLiveStreamingModel!.getAuthor!.objectId!;

    report.setLiveStreaming = widget.mLiveStreamingModel!;
    report.setLiveStreamingId = widget.mLiveStreamingModel!.objectId!;

    report.setMessage = message;

    ParseResponse response = await report.save();

    if (response.success) {
      /*widget.currentUser!.setReportedVideos = widget.video!.objectId!;
      widget.currentUser!.save();*/

      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title: 'report_message'.tr(),
        context: context,
        isError: false,
      );
      MainHelper.hideLoadingDialog(context);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        title: 'video.report_failed_title'.tr(),
        message: 'video.report_failed_message'.tr(),
        context: context,
        isError: true,
      );
      MainHelper.hideLoadingDialog(context);
    }
  }
}
