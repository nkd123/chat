// ignore_for_file: use_build_context_synchronously

import 'dart:ui';
import 'package:challenge/pages/home/home_page.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/utilities/helper_classes/notifications_helper.dart';
import 'package:challenge/pages/home/profile_pages/profile_page.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:challenge/models/MessageListModel.dart';
import 'package:challenge/models/MessageModel.dart';
import 'package:challenge/models/StoriesAuthorsModel.dart';
import 'package:challenge/models/StoriesModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/button_widget.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:story/story_page_view/story_page_view.dart';
import 'package:auto_size_text/auto_size_text.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';
import '../message_pages/message_page.dart';

class SeeStoriesPage extends StatefulWidget {
  final UserModel? currentUser;
  final StoriesAuthorsModel? storyAuthorPre;
  final List<StoriesAuthorsModel>? authorsList;
  final int? firstUserIndex;
  final int? backPageIndex;

  static String route = "stories/see_stories";

  const SeeStoriesPage(
      {Key? key,
      this.currentUser,
      this.storyAuthorPre,
      this.authorsList,
      this.firstUserIndex,
      this.backPageIndex})
      : super(key: key);

  @override
  State<SeeStoriesPage> createState() => _SeeStoriesPageState();
}

class _SeeStoriesPageState extends State<SeeStoriesPage> {
  get size => MediaQuery.of(context).size;
  late ValueNotifier<IndicatorAnimationCommand> indicatorAnimationController;
  TextEditingController storyMessageTextEditing = TextEditingController();
  List<StoriesModel> storiesList = [];
  late int initialStoryIndex = 0;
  bool storyDownloaded = false;
  StoriesAuthorsModel? selectedUserStory;
  int firstStoryAuthor = 0;
  bool isKeyBoardVisible = true;
  FocusNode focusNode = FocusNode();

  @override
  void initState() {
    firstStoryAuthor = widget.firstUserIndex!;

    indicatorAnimationController = ValueNotifier<IndicatorAnimationCommand>(
        IndicatorAnimationCommand.pause);

    selectedUserStory = widget.authorsList![firstStoryAuthor];

    removeOldStories(selectedUserStory!.getAuthorId!);

    indicatorAnimationController.value = IndicatorAnimationCommand.pause;
    allStories(selectedUserStory!.getAuthorId!).then((value) {
      setState(() {
        storyDownloaded = true;
        storiesList = value;
        firstStoryToBeSeen();
      });
      indicatorAnimationController.value = IndicatorAnimationCommand.resume;
    });

    super.initState();
  }

  @override
  void dispose() {
    storiesList.clear();
    indicatorAnimationController.dispose();
    focusNode.dispose();
    super.dispose();
  }

  firstStoryToBeSeen() {
    if (selectedUserStory!.getAuthor!.objectId !=
        widget.currentUser!.objectId) {
      bool find = false;
      for (var story in storiesList) {
        if (story['views'] == null && !find) {
          initialStoryIndex = storiesList.indexOf(story);
          find = true;
        } else if (!story['views'].contains(widget.currentUser!.objectId) &&
            !find) {
          initialStoryIndex = storiesList.indexOf(story);
          find = true;
        }
      }
    }
  }

  Future<List<StoriesModel>> allStories(String storyAuthorId) async {
    List<StoriesModel> currentList = [];

    QueryBuilder<StoriesModel> storiesQueries =
        QueryBuilder<StoriesModel>(StoriesModel());

    storiesQueries.whereEqualTo(StoriesModel.keyAuthorId, storyAuthorId);
    storiesQueries.whereGreaterThan(StoriesModel.keyExpiration, DateTime.now());

    ParseResponse parseResponse = await storiesQueries.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        for (StoriesModel storiesModel in parseResponse.results!) {
          if (!currentList.contains(storiesModel)) {
            currentList.add(storiesModel);
          }
        }

        setState(() {
          storiesList = currentList;
          storyDownloaded = true;
        });

        firstStoryToBeSeen();
      }
    }

    return currentList;
  }

  Future<List<StoriesModel>> removeOldStories(String storyAuthorId) async {
    List<StoriesModel> currentList = [];

    QueryBuilder<StoriesModel> storiesQueries =
        QueryBuilder<StoriesModel>(StoriesModel());

    storiesQueries.whereEqualTo(StoriesModel.keyAuthorId, storyAuthorId);

    ParseResponse parseResponse = await storiesQueries.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        for (StoriesModel storiesModel in parseResponse.results!) {
          if (!MainHelper.isAvailable(storiesModel.getExpireDate!)) {
            widget.storyAuthorPre!.setRemoveStory = storiesModel.objectId!;
            widget.storyAuthorPre!.save();
          }
        }
      }
    }
    return currentList;
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return GestureDetector(
      onTap: () => MainHelper.removeFocusOnTextField(context),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: StoryPageView(
          pageLength: widget.authorsList!.length,
          itemBuilder: (context, pageIndex, storyIndex) {
            selectedUserStory = widget.authorsList![pageIndex];

            return Stack(
              children: [
                _background(storyDownloaded, storyIndex),
                Positioned.fill(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 35, sigmaY: 35),
                    child: SizedBox(
                      width: size.width,
                      height: size.height,
                    ),
                  ),
                ),
                _content(storyDownloaded, storyIndex),
                  Padding(
                  padding: EdgeInsets.only(top: size.height / 13, left: 10),
                  child: ContainerCorner(
                    height: 50,
                    width: 50,
                    child: ActionsHelper.polygonAvatarWidget(
                      currentUser:selectedUserStory!.getAuthor!,
                    ),
                    onTap: () {
                    MainHelper.goToNavigatorScreen(
                              context,
                              widget.storyAuthorPre!.getAuthor!.getUid == widget.currentUser!.getUid
                                  ? ProfilePage(
                                      currentUser: widget.currentUser!,
                                    )
                                  : UserProfilePage(
                                      currentUser: widget.currentUser,
                                      mUser: widget.storyAuthorPre!.getAuthor),
                            back: true,
                          );
                  }
                  ),
                  
                ),  
                Align(
                  alignment: Alignment.topCenter,
                  child: Padding(
                    padding: EdgeInsets.only(top: size.height / 13, left: 67),
                    child: Row(
                      children: [
                        const SizedBox(
                          width: 8,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              selectedUserStory!.getAuthor!.getFullName!,
                              style: const TextStyle(
                                fontSize: 17,
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),                         
                            if (storyDownloaded)
                              TextWithTap(
                                MainHelper.getTimeAgoForFeed(
                                    storiesList[storyIndex].createdAt!),
                                marginTop: 8,
                                color: Colors.white,
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                                
                              ),                      
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          },
          onPageChanged: (pageIndex) {
            storyDownloaded = false;
            indicatorAnimationController.value = IndicatorAnimationCommand.pause;

            allStories(widget.authorsList![pageIndex].getAuthorId!)
                .then((value) {
              storiesList = value;
              storyDownloaded = true;
              firstStoryToBeSeen();
              indicatorAnimationController.value = IndicatorAnimationCommand.resume;
            });
          },
          gestureItemBuilder: (context, pageIndex, storyIndex) {
            if (storyDownloaded) {
              addViewOnSeenPicture(storiesList[storyIndex]);
            }
            if (storyIndex == storiesList.length - 1 && widget.currentUser!.objectId != widget.storyAuthorPre!.objectId) {
              selectedUserStory!.setLastStorySeen = true;
              selectedUserStory!.save();
            }
            return Stack(children: [
              Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: EdgeInsets.only(top: size.height / 13),
                  child: IconButton(
                    padding: EdgeInsets.zero,
                    color: Colors.white,
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      MainHelper.goToNavigatorScreen(
                        context,
                        HomePage(
                          showPageWithIndex: widget.backPageIndex,
                          currentUser: widget.currentUser,
                          key: Key(widget.currentUser!.objectId!),
                        ),
                      );
                    },
                  ),
                ),
              ),
              if (selectedUserStory!.getAuthor!.objectId ==
                  widget.currentUser!.objectId)
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.only(
                      bottom: 30,
                    ),
                    child: TextButton(
                      onPressed: () async {
                        indicatorAnimationController.value =
                            IndicatorAnimationCommand.pause;
                        if (storyDownloaded) {
                          await showModalBottomSheet(
                            backgroundColor: kTransparentColor,
                            context: context,
                            builder: (context) {
                              QueryBuilder<UserModel> usersQuery =
                                  QueryBuilder<UserModel>(UserModel.forQuery());
                              usersQuery.whereContainedIn(UserModel.keyObjectId,
                                  storiesList[storyIndex].geViewsIDs!);
                              usersQuery.whereNotEqualTo(UserModel.keyObjectId,
                                  widget.currentUser!.objectId);

                              return Stack(
                                children: [
                                  ContainerCorner(
                                    borderWidth: 0,
                                    color: Colors.black.withOpacity(0.4),
                                    width: size.width,
                                    height: size.height,
                                    radiusTopRight: 25,
                                    radiusTopLeft: 25,
                                    imageDecoration: "assets/images/app_bg.png",
                                  ),
                                  ClipRRect(
                                    borderRadius: const BorderRadius.only(
                                      topRight: Radius.circular(25),
                                      topLeft: Radius.circular(25),
                                    ),
                                    child: BackdropFilter(
                                      filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                                      child: ContainerCorner(
                                          color: kTransparentColor,
                                          height: size.height,
                                          width: size.width),
                                    ),
                                  ),
                                  ContainerCorner(
                                    borderWidth: 0,
                                    width: size.width,
                                    height: size.height,
                                    marginTop:20.0,
                                    child: ParseLiveListWidget<UserModel>(
                                      query: usersQuery,
                                      reverse: false,
                                      lazyLoading: false,
                                      duration: const Duration(milliseconds: 200),
                                      childBuilder: (BuildContext context,
                                          ParseLiveListElementSnapshot<ParseObject>
                                          snapshot) {
                                        if (snapshot.hasData) {
                                          UserModel viewer =
                                          snapshot.loadedData! as UserModel;
                                          return ButtonWidget(
                                            height: 50,
                                            onTap: () =>
                                                MainHelper.goToNavigatorScreen(
                                                  context,
                                                  MessagePage(
                                                    currentUser: widget.currentUser,
                                                    mUser: viewer,
                                                  ),
                                                ),
                                            child: Padding(
                                              padding: const EdgeInsets.only(top: 12.0, left: 15.0,right: 15.0),
                                              child: Row(
                                                children: [
                                                  ContainerCorner(
                                                    width: 60,
                                                    height: 60,
                                                    child: ActionsHelper.polygonAvatarWidget(
                                                        currentUser:viewer),
                                                  ),
                                                  TextWithTap(
                                                    viewer.getFullName!,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.bold,
                                                    marginLeft: 10,
                                                    color: Colors.white,
                                                    marginRight: 5,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          );
                                        } else {
                                          return Center(
                                            child: MainHelper.appLoading(),
                                          );
                                        }
                                      },
                                      queryEmptyElement: noViewersViewers(),
                                      listLoadingElement: Center(
                                        child: MainHelper.appLoading(),
                                      ),
                                    ),
                                  ),
                                ],
                              );

                            },
                          );
                        }
                        indicatorAnimationController.value =
                            IndicatorAnimationCommand.resume;
                      },
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SvgPicture.asset("assets/svg/ic_small_viewers.svg"),
                          const SizedBox(
                            width: 6,
                          ),
                          if (storyDownloaded)
                            TextWithTap(
                              storiesList[storyIndex]
                                  .geViewsIDs!
                                  .length
                                  .toString(),
                              color: Colors.white,
                              fontWeight: FontWeight.w500,
                            )
                        ],
                      ),
                    ),
                  ),
                ),
              if (selectedUserStory!.getAuthor!.objectId!.isEmpty)
                Align(
                  alignment: Alignment.bottomCenter,
                  child: StatefulBuilder(
                      builder: (BuildContext lowerContext, innerState) {
                    return TextButton(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.keyboard_arrow_up,
                            color: Colors.white,
                            size: 35,
                          ),
                          TextWithTap(
                            "stories.reply_".tr(),
                            color: Colors.white,
                            marginBottom: 10,
                          )
                        ],
                      ),
                      onPressed: () {
                        focusNode.requestFocus();
                        openBottomSheet(storyIndex);

                        Future.delayed(const Duration(seconds: 1), () {
                          indicatorAnimationController.value =
                              IndicatorAnimationCommand.pause;
                        });
                        MainHelper.goToNavigatorScreen(
                              context,
                              widget.storyAuthorPre!.getAuthor!.getUid == widget.currentUser!.getUid
                                  ? ProfilePage(
                                      currentUser: widget.currentUser!,
                                    )
                                  : UserProfilePage(
                                      currentUser: widget.currentUser,
                                      mUser: widget.storyAuthorPre!.getAuthor),
                            back: true,
                          );
                      },
                    );
                  }),
                ),
            ]);
          },
          indicatorAnimationController: indicatorAnimationController,
          initialStoryIndex: (pageIndex) {
            return initialStoryIndex;
          },
          initialPage: firstStoryAuthor,
          storyLength: (storyIndex) {
            return widget.authorsList![storyIndex].getStoriesList!.length;
          },
          indicatorPadding: EdgeInsets.only(top: size.height / 15),
          onPageLimitReached: () {
            // Navigator.pop(context);
            MainHelper.goToNavigatorScreen(
              context,
                HomePage(
                  showPageWithIndex: widget.backPageIndex,
                  currentUser: widget.currentUser,
                  key: Key(widget.currentUser!.objectId!),
                ),
            );
          },
        ),
      ),
    );
  }

  Widget noViewersViewers() {
    return Center(
      child: TextWithTap(
        'live_streaming.no_viewers'.tr(),
        fontSize: size.width / 22,
        textAlign: TextAlign.center,
        color: kContentColorDarkTheme,
      ),
    );
  }

  void openBottomSheet(int storyIndex) async {
    showModalBottomSheet(
        context: (context),
        isScrollControlled: false,
        backgroundColor: Colors.transparent,
        enableDrag: false,
        isDismissible: false,
        builder: (context) {
          return _showTextField(storyIndex);
        });
  }

  Widget _showTextField(int storyIndex) {
    var size = MediaQuery.of(context).size;
    return GestureDetector(
      onTap: () => Navigator.of(context).pop(),
      child: ContainerCorner(
        width: size.width,
        height: size.height,
        color: const Color.fromRGBO(0, 0, 0, 0.001),
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: GestureDetector(
                  onTap: () {
                    focusNode.unfocus(
                        disposition: UnfocusDisposition.previouslyFocusedChild);
                    Navigator.of(context).pop();
                    indicatorAnimationController.value =
                        IndicatorAnimationCommand.resume;
                  },
                  child: const Padding(
                    padding: EdgeInsets.only(bottom: 10),
                    child: Icon(
                      Icons.close,
                      color: Colors.white,
                      size: 30,
                    ),
                  )),
            ),
            StatefulBuilder(builder: (context, setState) {
              return Row(
                children: [
                  Expanded(
                    child: ContainerCorner(
                      color: kTransparentColor,
                      borderColor: Colors.white,
                      marginBottom:
                          MediaQuery.of(context).viewInsets.bottom + 10,
                      borderRadius: 50,
                      marginRight: 10,
                      height: 50,
                      marginLeft: 20,
                      width: 300,
                      child: TextFormField(
                        focusNode: focusNode,
                        minLines: 1,
                        maxLines: 100,
                        controller: storyMessageTextEditing,
                        autovalidateMode: AutovalidateMode.disabled,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        keyboardType: TextInputType.multiline,
                        decoration: InputDecoration(
                          hintText: "stories.story_text_hint".tr(),
                          focusedBorder: InputBorder.none,
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.only(left: 10),
                          hintStyle: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ),
                  ContainerCorner(
                    marginRight: 10,
                    marginBottom: MediaQuery.of(context).viewInsets.bottom + 10,
                    color: kFacebookColor,
                    borderRadius: 50,
                    height: 45,
                    width: 45,
                    onTap: () {
                      if (storyMessageTextEditing.text.isEmpty) {
                        MainHelper.showAppNotificationAdvanced(
                          title: "stories.make_sure_title".tr(),
                          message: "stories.make_sure_explain".tr(),
                          isError: true,
                          context: context,
                        );
                      } else {
                        indicatorAnimationController.value =
                            IndicatorAnimationCommand.resume;
                        replyStory(storiesList[storyIndex]);
                      }
                    },
                    child: ContainerCorner(
                      color: kTransparentColor,
                      marginAll: 5,
                      height: 30,
                      width: 30,
                      child: SvgPicture.asset(
                        "assets/svg/ic_send_message.svg",
                        color: Colors.white,
                        height: 10,
                        width: 30,
                      ),
                    ),
                  )
                ],
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _background(bool downloaded, int storyIndex) {
    var size = MediaQuery.of(context).size;

    if (downloaded) {
      return Stack(
        children: [
          storiesList[storyIndex].getImage != null
              ? Positioned.fill(
                  child: ActionsHelper.photosWidget(
                    storiesList[storyIndex].getImage!.url,
                    width: size.width,
                    height: size.height,
                  ),
                )
              : ContainerCorner(
                  borderWidth: 0,
                  borderRadius: 10,
                  color: MainHelper.stringToColor(
                      storiesList[storyIndex].getTextBgColors!),
                ),
        ],
      );
    } else {
      return Stack(
        children: [
          Positioned.fill(
            child: ActionsHelper.photosWidget(
              selectedUserStory!.getAuthor!.getAvatar!.url!,
              width: size.width,
              height: size.height,
            ),
          ),
        ],
      );
    }
  }

  Widget _content(bool downloaded, int storyIndex) {
    var size = MediaQuery.of(context).size;
    if (downloaded) {
      return Stack(
        children: [
          storiesList[storyIndex].getImage != null
              ? Center(
                  child: ActionsHelper.photosWidget(
                    storiesList[storyIndex].getImage!.url,
                    width: size.width,
                    height: size.height / 1.5,
                    fit: BoxFit.contain,
                    borderRadius: 0,
                  ),
                )
              : Center(
                  child: ContainerCorner(
                    child: Padding(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: AutoSizeText(
                        storiesList[storyIndex].getText!,
                        style: GoogleFonts.nunito(
                          fontSize: 49,
                          color: MainHelper.stringToColor(
                              storiesList[storyIndex].getTextColors!),
                        ),
                        minFontSize: 14,
                        stepGranularity: 7,
                        maxLines: 7,
                      ),
                    ),
                  ),
                ),
        ],
      );
    } else {
      return Stack(
        children: [
          Center(
            child: MainHelper.appLoading(),
          )
        ],
      );
    }
  }

  addViewOnSeenPicture(StoriesModel story) {
    if (!story.geViewsIDs!.contains(widget.currentUser!.objectId)) {
      if (story.getAuthorId != widget.currentUser!.objectId) {
        story.setViewersId = widget.currentUser!.objectId!;
        story.save();
      }
    }
  }

  replyStory(StoriesModel repliedStory) async {
    MessageModel messageModel = MessageModel();
    messageModel.setAuthorId = widget.currentUser!.objectId!;
    messageModel.setAuthor = widget.currentUser!;
    messageModel.setReceiver = selectedUserStory!.getAuthor!;
    messageModel.setReceiverId = selectedUserStory!.getAuthor!.objectId!;
    messageModel.setMessageType = MessageModel.messageStoryReply;
    messageModel.setMessageText = storyMessageTextEditing.text;
    messageModel.setStoryReplied = repliedStory;
    messageModel.setIsRead = false;
    storyMessageTextEditing.text = "";
    ParseResponse parseResponse = await messageModel.save();
    if (parseResponse.success) {
      final snackBar = SnackBar(
        content: TextWithTap(
          "stories.story_sent".tr(),
          color: Colors.white,
        ),
        backgroundColor: (Colors.black12),
      );
      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      _saveList(messageModel);
    }
    NotificationsHelper.sendPush(widget.currentUser!,
        selectedUserStory!.getAuthor!, NotificationsHelper.typeChat,
        message: "push_notifications.story_replied".tr(
            namedArgs: {"name": selectedUserStory!.getAuthor!.getFullName!}));
  }

  // Update or Create message list
  _saveList(MessageModel messageModel) async {
    QueryBuilder<MessageListModel> queryFrom =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryFrom.whereEqualTo(
        MessageListModel.keyListId,
        widget.currentUser!.objectId! +
            selectedUserStory!.getAuthor!.objectId!);

    QueryBuilder<MessageListModel> queryTo =
        QueryBuilder<MessageListModel>(MessageListModel());
    queryTo.whereEqualTo(
        MessageListModel.keyListId,
        selectedUserStory!.getAuthor!.objectId! +
            widget.currentUser!.objectId!);

    QueryBuilder<MessageListModel> queryBuilder =
        QueryBuilder.or(MessageListModel(), [queryFrom, queryTo]);

    ParseResponse parseResponse = await queryBuilder.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        MessageListModel messageListModel = parseResponse.results!.first;

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = selectedUserStory!.getAuthor!;
        messageListModel.setReceiverId =
            selectedUserStory!.getAuthor!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setIsRead = false;
        messageListModel.setListId = widget.currentUser!.objectId! +
            selectedUserStory!.getAuthor!.objectId!;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;

        await messageModel.save();
      } else {
        MessageListModel messageListModel = MessageListModel();

        messageListModel.setAuthor = widget.currentUser!;
        messageListModel.setAuthorId = widget.currentUser!.objectId!;

        messageListModel.setReceiver = selectedUserStory!.getAuthor!;
        messageListModel.setReceiverId =
            selectedUserStory!.getAuthor!.objectId!;

        messageListModel.setMessage = messageModel;
        messageListModel.setMessageId = messageModel.objectId!;
        messageListModel.setText = messageModel.getMessageText!;
        messageListModel.setIsMessageFile = false;

        messageListModel.setMessageType = messageModel.getMessageType!;

        messageListModel.setListId = widget.currentUser!.objectId! +
            selectedUserStory!.getAuthor!.objectId!;
        messageListModel.setIsRead = false;

        messageListModel.incrementCounter = 1;
        await messageListModel.save();

        messageModel.setMessageList = messageListModel;
        messageModel.setMessageListId = messageListModel.objectId!;
        await messageModel.save();
      }
    }
  }
}
