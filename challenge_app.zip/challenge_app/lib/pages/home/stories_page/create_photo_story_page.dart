// ignore_for_file: use_build_context_synchronously, library_private_types_in_public_api, must_be_immutable

import 'dart:io';
import 'dart:ui';

import 'package:camera/camera.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_compression_flutter/image_compression_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:challenge/utilities/helper_classes/actions_helper.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/pages/home/home_page.dart';
import 'package:challenge/utilities/edition_files_pages/crop_image_page.dart';
import 'package:challenge/models/StoriesAuthorsModel.dart';
import 'package:challenge/models/StoriesModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/widgets/custom_widgets/container_with_corner.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';

import '../../../widgets/custom_widgets/text_with_tap.dart';

class CreatePhotoStory extends StatefulWidget {
  CameraController? controller;
  final UserModel? currentUser;
  final List<CameraDescription>? cameras;

  CreatePhotoStory({Key? key, this.controller, this.currentUser,
    this.cameras
  })
      : super(key: key);

  @override
  _CreatePhotoStoryState createState() => _CreatePhotoStoryState();
}

class _CreatePhotoStoryState extends State<CreatePhotoStory> {
  get size => MediaQuery.of(context).size;

  List<CameraDescription>? cameras; //list out the camera available
  XFile? image; //for captured image

  String uploadPhoto = "";
  ParseFileBase? parseFile;
  String uploadedPic = "";
  TextEditingController storyCaptionController = TextEditingController();

  bool isKeyBoardVisible = true;

  int currentCameraIndex = 0;

  @override
  void initState() {
    storyCaptionController = TextEditingController();
    setState(() {});
    super.initState();
  }

  @override
  void dispose() {
    storyCaptionController.dispose();
    super.dispose();
  }

  _switchCamera() async {
    cameras = await availableCameras();
    if(cameras != null && cameras!.length > 1) {
      if (kDebugMode) {
        print(cameras);
      }
      widget.controller = CameraController(
          cameras![currentCameraIndex == 0 ? 1 : 0], ResolutionPreset.max);

      widget.controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      });

      currentCameraIndex = currentCameraIndex == 0 ? 1 : 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(),
    );
  }

  Widget _body() {
    var size = MediaQuery.of(context).size;

    if (widget.controller != null) {
      return ContainerCorner(
          borderWidth: 0,
          child: Stack(children: [
            SizedBox(
                height: size.height,
                width: size.width,
                child: CameraPreview(widget.controller!)),
            ContainerCorner(
              onTap: () => MainHelper.goBackToPreviousPage(context),
              width: size.width / 15,
              height: size.width / 15,
              marginTop: size.height / 15,
              marginLeft: 10,
              color: kPrimaryColor,
              borderRadius: 50,
              child: Center(
                child: Icon(
                  Icons.close,
                  size: size.width / 25,
                  color:Colors.white,
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: btnActions(),
            ),
            Align(
              alignment: Alignment.topRight,
              child: SafeArea(
                child: Container(
                  //show captured image
                  padding: const EdgeInsets.all(30),
                  child: image == null
                      ? const Text("No image captured")
                      : Image.file(
                          File(image!.path),
                          height: 100,
                        ),
                  //display captured image
                ),
              ),
            ),
          ]));
    } else {
      return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            leading: BackButton(
              color:
                  MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
            ),
            backgroundColor: MainHelper.isDarkMode(context)
                ? kContentColorLightTheme
                : Colors.white,
            centerTitle: true,
            title: TextWithTap(
              "stories.open_gallery".tr(),
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color:
                  MainHelper.isDarkMode(context) ? Colors.white : Colors.black,
            ),
          ),
          body: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(
                  height: size.height / 12,
                ),
                Icon(
                  Icons.no_photography_outlined,
                  color: kPrimaryColor,
                  size: size.width / 2,
                ),
                SizedBox(
                  height: size.height / 12,
                ),
                TextWithTap(
                  "stories.no_camera".tr(),
                  color: MainHelper.isDarkMode(context)
                      ? Colors.white
                      : Colors.black,
                  textAlign: TextAlign.center,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                ),
                TextWithTap(
                  "stories.resolve_camera_problem".tr(),
                  color: MainHelper.isDarkMode(context)
                      ? Colors.white
                      : Colors.black,
                  textAlign: TextAlign.center,
                  marginLeft: size.width / 10,
                  marginRight: size.width / 10,
                ),
                SizedBox(
                  height: size.height / 12,
                ),
                ContainerCorner(
                  height: size.height / 18,
                  marginRight: size.width / 10,
                  marginLeft: size.width / 10,
                  colors: const [Colors.deepOrangeAccent, kPrimaryColor],
                  onTap: () => _choosePhoto(),
                  borderRadius: 50,
                  child: Row(
                    children: [
                      SizedBox(width: size.width / 10),
                      SvgPicture.asset(
                        "assets/svg/foto.svg",
                        color: Colors.white,
                        height: size.width / 13,
                      ),
                      TextWithTap(
                        "stories.choose_pics".tr(),
                        color: Colors.white,
                        marginLeft: size.width / 20,
                        fontSize: size.width / 20,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ));
    }
  }

  _choosePhoto() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);

    if (image != null) {
      cropPhoto(image: image.path);
    } else {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "crop_image_scree.cancelled_by_user".tr(),
        message: "crop_image_scree.image_not_selected".tr(),
      );
    }
  }

  void compressImage(Future<ImageFile> image) {
    MainHelper.showLoadingDialogWithText(context,
        description: "crop_image_scree.optimizing_image".tr(), useLogo: true);

    image.then((value) {
      Future.delayed(const Duration(seconds: 1), () async {
        var result = await MainHelper.compressImage(value,
            quality: value.sizeInBytes >= 1000000 ? 30 : 50);

        if (result != null) {
          MainHelper.hideLoadingDialog(context);
          MainHelper.showLoadingDialogWithText(context,
              description: "crop_image_scree.optimizing_image_uploading".tr());
          uploadFile(result);
        } else {
          MainHelper.hideLoadingDialog(context);

          MainHelper.showAppNotificationAdvanced(
            context: context,
            title: "crop_image_scree.cancelled_by_user".tr(),
            message: "crop_image_scree.image_not_cropped_error".tr(),
          );
        }
      });
    }).onError((error, stackTrace) {
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "error".tr(),
        message: "try_again_later".tr(),
      );
    });
  }

  void cropPhoto({dynamic image}) async {
    MainHelper.showLoadingDialog(context);

    var result = await MainHelper.goToNavigatorScreenForResult(
        context,
        CropImagePage(
          pathOrBytes: image,
          aspectRatio: CropImagePage.aspectRatioSquare,
        ),
        route: CropImagePage.route);

    if (result != null) {
      XFile? xFile =
          MainHelper.isWebPlatform() ? XFile.fromData(result) : XFile(result);

      MainHelper.hideLoadingDialog(context);
      compressImage(xFile.asImageFile);
    } else {
      MainHelper.hideLoadingDialog(context);
      MainHelper.showAppNotificationAdvanced(
        context: context,
        title: "crop_image_scree.cancelled_by_user".tr(),
        message: "crop_image_scree.image_not_cropped_error".tr(),
      );
    }
  }

  uploadFile(ImageFile imageFile) async {
    setState(() {
      if (imageFile.filePath.isNotEmpty) {
        parseFile = ParseFile(File(imageFile.filePath), name: "avatar.jpg");
      } else {
        parseFile = ParseWebFile(imageFile.rawBytes, name: "avatar.jpg");
      }
    });

    ParseResponse parseResponse = await parseFile!.save();

    if (parseResponse.success) {
      if (parseResponse.results!.isNotEmpty) {
        MainHelper.hideLoadingDialog(context);
        prepareStory(parseResponse.results![0]["url"]);
      }
    } else {
      MainHelper.hideLoadingDialog(context);
      return;
    }
  }

  prepareStory(String imageURL) {
    var size = MediaQuery.of(context).size;

    return showDialog(
        context: context,
        builder: (context) {
          return GestureDetector(
            onTap: () => MainHelper.removeFocusOnTextField(context),
            child: StatefulBuilder(
              builder: (context, setState) {
                return ContainerCorner(
                  onTap: () => MainHelper.removeFocusOnTextField(context),
                  color: kTransparentColor,
                  borderWidth: 0,
                  width: size.width,
                  height: size.height,
                  child: Scaffold(
                    resizeToAvoidBottomInset: false,
                    extendBodyBehindAppBar: true,
                    backgroundColor: kTransparentColor,
                    appBar: AppBar(
                      backgroundColor: kTransparentColor,
                      automaticallyImplyLeading: false,
                      leading: TextButton(
                          onPressed: () =>
                              MainHelper.goBackToPreviousPage(context),
                          child: const Icon(
                            Icons.close,
                            size: 30,
                            color: Colors.white,
                          )),
                    ),
                    body: ContainerCorner(
                      borderWidth: 0,
                      child: Stack(
                        children: [
                          if (cameras == null)
                            ContainerCorner(
                              onTap: () =>
                                  MainHelper.removeFocusOnTextField(context),
                              height: size.height,
                              width: size.width,
                              borderWidth: 0,
                              child: ActionsHelper.photosWidget(
                                  widget.currentUser!.getAvatar!.url,
                                  borderRadius: 0,
                                  fit: BoxFit.contain),
                            ),
                          ContainerCorner(
                            borderWidth: 0,
                            height: size.height,
                            width: size.width,
                            borderRadius: 50,
                            onTap: () =>
                                MainHelper.removeFocusOnTextField(context),
                            child: ClipRRect(
                              child: BackdropFilter(
                                filter:
                                    ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                                child: Container(),
                              ),
                            ),
                          ),
                          Align(
                            child: ContainerCorner(
                              onTap: () =>
                                  MainHelper.removeFocusOnTextField(context),
                              height: size.height / 1.4,
                              width: size.width,
                              borderWidth: 0,
                              child: ActionsHelper.photosWidget(imageURL,
                                  borderRadius: 0, fit: BoxFit.contain),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: SingleChildScrollView(
                              child: ContainerCorner(
                                marginBottom: isKeyBoardVisible
                                    ? MediaQuery.of(context).viewInsets.bottom
                                    : 10,
                                child: chatInputField(),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        });
  }

  Widget chatInputField() {
    return ContainerCorner(
      child: Row(
        children: [
          Expanded(
            child: ContainerCorner(
              borderWidth: 2,
              borderRadius: 50,
              marginLeft: 20,
              marginBottom: 10,
              borderColor: Colors.white.withOpacity(0.7),
              height: 60,
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          const EdgeInsets.only(left: 15, right: 10, top: 7),
                      child: Center(
                        child: TextField(
                          autocorrect: false,
                          style: GoogleFonts.nunito(
                            color: Colors.white,
                          ),
                          onTap: () {
                            setState(() {
                              //visibleKeyBoard = true;
                            });
                          },
                          keyboardType: TextInputType.multiline,
                          maxLines: 2,
                          controller: storyCaptionController,
                          decoration: InputDecoration(
                            hintText: "stories.add_caption".tr(),
                            border: InputBorder.none,
                            hintStyle: GoogleFonts.nunito(
                              color: Colors.white.withOpacity(0.7),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          ContainerCorner(
            marginLeft: 10,
            marginRight: 10,
            marginBottom: 10,
            color: kButtonTextColor,
            //colors: const [Colors.deepOrangeAccent, kPrimaryColor],
            borderRadius: 50,
            height: 55,
            width: 55,
            onTap: () {
              MainHelper.goBackToPreviousPage(context);
              createStories();
            },
            child: ContainerCorner(
              color: kTransparentColor,
              marginAll: 5,
              height: 40,
              width: 40,
              child: Center(
                child: SvgPicture.asset(
                  "assets/svg/ic_send_message.svg",
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  //create story author
  createStories() async {
    MainHelper.showLoadingDialog(context);
    StoriesModel story = StoriesModel();

    story.setAuthor = widget.currentUser!;
    story.setAuthorId = widget.currentUser!.objectId!;
    story.setImage = parseFile!;
    story.setExpireDate = MainHelper.getUntilDateFromDays(1);

    ParseResponse response = await story.save();

    if (response.success) {
      MainHelper.hideLoadingDialog(context);
      _createAuthor(story);
    }else{
      MainHelper.hideLoadingDialog(context);
      Future.delayed(const Duration(seconds: 1));
      MainHelper.showAppNotificationAdvanced(
        title: "error_creating.error_title".tr(),
        message: "error_creating.error_explain".tr(),
        context: context,
        isError: true,
      );
    }

    if (storyCaptionController.text.isNotEmpty) {
      story.setText = storyCaptionController.text;
    }
  }

  //create story author
  _createAuthor(StoriesModel story) async {
    QueryBuilder<StoriesAuthorsModel> query =
        QueryBuilder<StoriesAuthorsModel>(StoriesAuthorsModel());
    query.whereEqualTo(
        StoriesAuthorsModel.keyAuthorId, widget.currentUser!.objectId);
    ParseResponse parseResponse = await query.query();

    if (parseResponse.success) {
      if (parseResponse.results != null) {
        StoriesAuthorsModel storyAuthor = parseResponse.results!.first!;
        storyAuthor.setLastStory = story;
        storyAuthor.setStoriesList = story.objectId!;
        storyAuthor.setLastStoryExpireDate = story.getExpireDate!;
        storyAuthor.setLastStorySeen = false;
        await storyAuthor.save();

        removeExpiredStories(storyAuthor);

      } else {
        StoriesAuthorsModel storyAuthor = StoriesAuthorsModel();
        storyAuthor.setAuthor = widget.currentUser!;
        storyAuthor.setAuthorId = widget.currentUser!.objectId!;
        storyAuthor.setLastStory = story;
        storyAuthor.setStoriesList = story.objectId!;
        storyAuthor.setLastStoryExpireDate = story.getExpireDate!;
        storyAuthor.setLastStorySeen = false;

        ParseResponse response = await storyAuthor.save();

        if(response.success){
          goHome();
        }
      }
    }
  }

  goHome(){
    MainHelper.goToNavigatorScreen(
      context,
      HomePage(
        showPageWithIndex: 1,
        currentUser: widget.currentUser,
        key: Key(widget.currentUser!.objectId!),
      ),
      finish: true,
      back: false
    );
  }

  removeExpiredStories(StoriesAuthorsModel storyAuthor) async {

    QueryBuilder<StoriesModel> query =
    QueryBuilder<StoriesModel>(StoriesModel());
    query.whereContainedIn(StoriesModel.keyObjectId,
        storyAuthor.getStoriesList!);
    query.whereLessThan(StoriesModel.keyExpiration, DateTime.now());

    ParseResponse response = await query.query();

    if(response.success){
      if(response.results != null){
        for (StoriesModel storiesModel in response.results!) {
          storyAuthor.removeStoriesFromList = storiesModel.objectId!;
        }
      }
    }

    ParseResponse result = await storyAuthor.save();

    if(result.success){
      goHome();
    }
  }

  Widget btnActions() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      actionButton(Icons.photo, () => _choosePhoto(),),
      actionButton(Icons.camera, () async {
        try {
          if (widget.controller != null) {
            //check if controller is not null
            if (widget.controller!.value.isInitialized) {
              //check if controller is initialized
              image = await widget.controller!
                  .takePicture(); //capture image
              setState(() {
                //update UI
              });
              if (image != null) {
                cropPhoto(image: image!.path);
              }
            }
          }
        } catch (e) {
          e.toString(); //show error
        }
      },),
      actionButton(Icons.switch_camera, () async {
        _switchCamera();
      }),
    ]
    );
  }

  Widget actionButton(IconData icon, VoidCallback action) {
    return ContainerCorner(
      onTap: action,
      width:size.width/8,
      height:size.width/8,
      marginLeft: 10,
      marginRight: 10,
      marginTop:16,
      marginBottom:16,
      color: kButtonTextColor,
      borderRadius: 50,
      child: Center(
        child: Icon(icon, size: size.width/15,color: kContentColorDarkTheme,),
      ),
    );
  }

}
