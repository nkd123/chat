import 'dart:convert';
import 'dart:io';

import 'package:challenge/models/ChallengeModel.dart';
import 'package:challenge/pages/home/profile_pages/user_profile_page.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:challenge/utilities/helper_classes/notifications_helper.dart';
import 'package:challenge/models/LiveStreamingModel.dart';
import 'package:challenge/models/PostModel.dart';
import 'package:challenge/models/UserModel.dart';
import 'package:challenge/utilities/main_utilities/shared_manager.dart';

import '../configurations/global_config.dart';
import '../pages/home/message_pages/message_page.dart';
import '../utilities/helper_classes/main_helper.dart';
import '../pages/home/livestreaming_pages/live_streaming_page.dart';
import '../pages/home/video_pages/accept_challenge_page.dart';
import 'navigation_service.dart';

class PushNotificationService {
  final FirebaseMessaging messaging;
  final FlutterLocalNotificationsPlugin localNotifications;

  UserModel? currentUser;

  PushNotificationService(
      this.messaging, this.currentUser,
      this.localNotifications);

  Future initialise() async {
    if (Platform.isIOS) {
      notificationsPermissions(messaging);
    }

    messaging.getToken(vapidKey: Config.webPushCertificate).then((token) {
      if (MainHelper.isAndroidPlatform()) {
        _storeToken(token!);
      } else if (MainHelper.isWebPlatform()) {
        _storeToken(token!);
      } else if (MainHelper.isIOSPlatform()) {
        //_storeToken(token!);
        messaging.getAPNSToken().then((value) {

          if (value != null) {
            _storeToken(value);
          } else {
            _storeToken("");
          }
        });
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      _decodePushMessage(message.data);
    });

    await enableIOSNotifications();
    await registerNotificationListeners();
  }

  _decodePushMessage(Map<String, dynamic> message) async {
    UserModel? mUser;
    PostsModel? mPost;
    LiveStreamingModel? mLive;
    ChallengeModel? mChallenge;

    //Map notification = message;
    //Map notification = message;
    var data = message["data"];
    Map notification = json.decode(data);

    var type = notification[NotificationsHelper.pushNotificationType];
    var senderId = notification[NotificationsHelper.pushNotificationSender];
    var receiverId = notification[NotificationsHelper.pushNotificationReceiver];
    var objectId = notification[NotificationsHelper.pushNotificationObjectId];

    /*
    var viewGroup = notification[NotificationsHelper.pushNotificationViewGroup];
    var alert = notification[NotificationsHelper.pushNotificationAlert];
    var title = notification[NotificationsHelper.pushNotificationTitle];
    var senderName = notification[NotificationsHelper.pushNotificationSenderName];
    var chatText = notification[NotificationsHelper.pushNotificationChat];
    var avatarUrl = notification[NotificationsHelper.pushNotificationSenderAvatar];
    */

    if (type == NotificationsHelper.typeChat) {

      QueryBuilder<UserModel> queryUser =
          QueryBuilder<UserModel>(UserModel.forQuery());
      queryUser.whereEqualTo(UserModel.keyObjectId, senderId);

      ParseResponse parseResponse = await queryUser.query();
      if (parseResponse.success && parseResponse.results != null) {
        mUser = parseResponse.results!.first! as UserModel;
      }

      if (currentUser != null && mUser != null) {
        _gotToChat(currentUser!, mUser);
      }
    } else if (type == NotificationsHelper.typeLive ||
        type == NotificationsHelper.typeLiveInvite) {
      QueryBuilder<LiveStreamingModel> queryPost =
          QueryBuilder<LiveStreamingModel>(LiveStreamingModel());
      queryPost.whereEqualTo(LiveStreamingModel.keyObjectId, objectId);
      queryPost.includeObject([LiveStreamingModel.keyAuthor]);

      ParseResponse parseResponse = await queryPost.query();
      if (parseResponse.success && parseResponse.results != null) {
        mLive = parseResponse.results!.first! as LiveStreamingModel;
      }

      if (currentUser != null && mLive != null) {
        _goToLive(currentUser!, mLive);
      }
    } else if (type == NotificationsHelper.typeLike ||
        type == NotificationsHelper.typeComment) {
      QueryBuilder<PostsModel> queryPost =
          QueryBuilder<PostsModel>(PostsModel());
      queryPost.whereEqualTo(PostsModel.keyObjectId, objectId);
      queryPost.includeObject([PostsModel.keyAuthor]);

      ParseResponse parseResponse = await queryPost.query();
      if (parseResponse.success && parseResponse.results != null) {
        mPost = parseResponse.results!.first! as PostsModel;
      }

      if (currentUser != null && mPost != null) {
        _goToPost(currentUser!, mPost);
      }
    } else if (type == NotificationsHelper.typeFollow ||
        type == NotificationsHelper.typeMissedCall) {
      QueryBuilder<UserModel> queryUser =
          QueryBuilder<UserModel>(UserModel.forQuery());
      queryUser.whereEqualTo(UserModel.keyObjectId, senderId);

      ParseResponse parseResponse = await queryUser.query();
      if (parseResponse.success && parseResponse.results != null) {
        mUser = parseResponse.results!.first! as UserModel;
      }

      if (currentUser != null && mUser != null) {
        /*ActionsHelper.showUserProfile(
            NavigationService.navigatorKey.currentContext!,
            currentUser!,
            mUser);*/
        _gotToFollowerProfile(currentUser!, mUser);
      }
    } else if (type == NotificationsHelper.typeChallenge) {
      QueryBuilder<ChallengeModel> queryChallenge =
      QueryBuilder<ChallengeModel>(ChallengeModel());
      queryChallenge.whereEqualTo(ChallengeModel.keyAuthorId, senderId);
      queryChallenge.whereEqualTo(ChallengeModel.keyChallengerId, receiverId);
      queryChallenge.whereEqualTo(ChallengeModel.keyChallengerVideo, null);

      ParseResponse parseResponse = await queryChallenge.query();
      if (parseResponse.success && parseResponse.results != null) {
        mChallenge = parseResponse.results!.first! as ChallengeModel;
      }

      if (currentUser != null && mChallenge != null) {
        _goToChallenge(currentUser!, mChallenge);
      }
    }
  }

  _gotToChat(UserModel currentUser, UserModel mUser) {
    MainHelper.goToNavigatorScreen(
        NavigationService.navigatorKey.currentContext!,
        MessagePage(
          currentUser: currentUser,
          mUser: mUser,
        ));
  }

  _goToPost(UserModel currentUser, PostsModel mPost) {
    /*MainHelper.goToNavigatorScreen(
        NavigationService.navigatorKey.currentContext!, CommentPostPage(
      currentUser: currentUser,
      post: mPost,
    ),);*/
  }

  _goToLive(UserModel currentUser, LiveStreamingModel mLive) {
    MainHelper.goToNavigatorScreen(
        NavigationService.navigatorKey.currentContext!,
        LiveStreamingPage(
          channelName: mLive.getStreamingChannel!,
          isBroadcaster: false,
          currentUser: currentUser,
          mUser: mLive.getAuthor,
          mLiveStreamingModel: mLive,
        ));
  }

  _goToChallenge(UserModel currentUser, ChallengeModel mChallenge) {
    MainHelper.goToNavigatorScreen(
        NavigationService.navigatorKey.currentContext!,
        AcceptChallengePage(
          currentUser: currentUser,
          challenge: mChallenge,
          video: mChallenge.getAuthorVideo,
          isAuthor: false,
        ),);
  }

  _gotToFollowerProfile(UserModel currentUser, UserModel mUser) {
    MainHelper.goToNavigatorScreen(
        NavigationService.navigatorKey.currentContext!,
        UserProfilePage(
          currentUser: currentUser,
          mUser: mUser,
        ));
  }

  registerNotificationListeners() async {

    AndroidNotificationChannel channel = androidNotificationChannel();

    final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
        FlutterLocalNotificationsPlugin();

    await flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    var androidSettings = const AndroidInitializationSettings('@mipmap/ic_launcher');

    var iOSSettings = const IOSInitializationSettings(
      requestSoundPermission: true,
      requestBadgePermission: true,
      requestAlertPermission: true,
    );

    final NotificationAppLaunchDetails? notificationAppLaunchDetails =
        await flutterLocalNotificationsPlugin.getNotificationAppLaunchDetails();

    var initSettings =
        InitializationSettings(android: androidSettings, iOS: iOSSettings);
    flutterLocalNotificationsPlugin.initialize(initSettings,
        onSelectNotification: (message) async {
      // This function handles the click in the notification when the app is in foreground
      // Get.toNamed(NOTIFICATIOINS_ROUTE);
      //_decodePushMessage(message);

      if (notificationAppLaunchDetails!.didNotificationLaunchApp == true) {
      }
    });

    // onMessage is called when the app is in foreground and a notification is received
    FirebaseMessaging.onMessage.listen((RemoteMessage? message) async {

      RemoteNotification? notification = message!.notification;

      //RemoteMessage? messagePush = message;
      var data = message.data["data"];
      Map notificationData = json.decode(data);

      var group = notificationData[NotificationsHelper.pushNotificationViewGroup];
      //var avatar = notificationData[NotificationsHelper.pushNotificationSenderAvatar];
      //var type = notificationData[NotificationsHelper.pushNotificationType];
      //var senderId = notificationData[NotificationsHelper.pushNotificationSender];

      /*MainHelper.showAppNotificationAdvanced(
          title: notification!.title!,
          message: notification.body,
          avatarUrl: avatar,
          context: NavigationService.navigatorKey.currentContext!,
          isError: null,
          onTap: () => _decodePushMessage(message.data),
      );*/

      //final ByteData imageData = await NetworkAssetBundle(Uri.parse(avatar)).load("");
      //final Uint8List bytes = imageData.buffer.asUint8List();

      //AndroidBitmap<Object> androidBitmap = ByteArrayAndroidBitmap.fromBase64String(base64.encode(bytes));

      AndroidNotification? android = message.notification?.android;
      AppleNotification? apple = message.notification?.apple;
      // If `onMessage` is triggered with a notification, construct our own
      // local notification to show to users using the created channel.

      if (notification != null && android != null) {

        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              channelDescription: channel.description,
              icon: android.smallIcon,
              //largeIcon: androidBitmap,
              playSound: true,
              autoCancel: true,
              groupKey: group,
              importance: Importance.max,
            ),
          ),
        );
      } else if (notification != null && apple != null) {

        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          const NotificationDetails(
            iOS: IOSNotificationDetails(
              presentSound: true,
              presentBadge: true,
              presentAlert: true,
            ),
          ),
        );
      }
    });
  }

  enableIOSNotifications() async {
    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true, // Required to display a heads up notification
      badge: true,
      sound: true,
    );
  }

  androidNotificationChannel() => const AndroidNotificationChannel(
        'high_importance_channel', // id
        'High Importance Notifications', // title
        description: 'This channel is used for important notifications.',
        // description
        importance: Importance.max,
      );

  Future<void> notificationsPermissions(FirebaseMessaging messaging) async {
    NotificationSettings settings = await messaging.requestPermission(
      alert: true,
      announcement: true,
      badge: true,
      criticalAlert: true,
      sound: true,
      carPlay: false,
      provisional: false,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
    } else {
    }
  }

  _storeToken(String deviceToken) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    SharedManager.setDeviceToken(sharedPreferences, deviceToken);

    MainHelper.initInstallation(currentUser, deviceToken);
  }
}
