import 'package:firebase_analytics/firebase_analytics.dart';

import '../models/UserModel.dart';

class Analytics {
  FirebaseAnalytics analytics = FirebaseAnalytics.instance;

  void setView() async {
    await analytics.logScreenView();
  }

  void seTUserId(UserModel user) async {
    await analytics.setUserId(id: user.objectId!);
  }

  void newLogginEvent(String? method) async {
    await analytics.logLogin(
      loginMethod: method,
    );
  }

  void newSignupEvent(String? method) async {
    await analytics.logSignUp(
     signUpMethod: method!
    );
  }
}