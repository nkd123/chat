import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:challenge/utilities/helper_classes/main_helper.dart';
import 'package:challenge/models/VideoModel.dart';
import 'package:video_player/video_player.dart';

import 'custom_widgets/container_with_corner.dart';

// ignore: must_be_immutable
class CustomVideoPlayer extends StatefulWidget { // a video custom player widget
  VideoModel video;
  CustomVideoPlayer(this.video, {Key? key}) : super(key: key);

  @override
  State<CustomVideoPlayer> createState() => _CustomVideoPlayerState();
}

class _CustomVideoPlayerState extends State<CustomVideoPlayer> {
  get size => MediaQuery.of(context).size;
  late VideoPlayerController _controller;

  void initController() {
    _controller = VideoPlayerController.network(
      widget.video.getVideo != null
          ? '${widget.video.getVideo!.url}'
          : '${widget.video.getUrl}',
    )
      ..addListener(() {
        setState((){});
      })
      ..setLooping(false)
      ..initialize().then((_) {
        _controller.pause();
      });
  }

  @override
  void initState() {
    super.initState();
    initController();
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        playOrPause();
      },
      child: _controller.value.isInitialized
          ? Stack(
            children: [
              SizedBox(
                child: AspectRatio(
                    aspectRatio: _controller.value.aspectRatio,
                    child: VideoPlayer(_controller)),
              ),
              Visibility(
                visible: !_controller.value.isPlaying,
                child: Center(
                  child: ContainerCorner(
                    onTap: (){
                      playOrPause();
                    },
                    width: size.width*0.11,
                    height: size.width*0.11,
                    color: Colors.black.withOpacity(0.3),
                    borderRadius: 50,
                    child: Center(
                      child: Icon(
                        Icons.play_arrow,
                        color: Colors.white,
                        size: size.width*0.08,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          )
          : Stack(children: [
              CachedNetworkImage(
                  imageUrl: widget.video.getThumbnail!.url!,
                  imageBuilder: (context, imageProvider) => Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.rectangle,
                          image: DecorationImage(
                              image: imageProvider, fit: BoxFit.fill),
                        ),
                      ),
                  placeholder: (context, url) => MainHelper.appLoading(),
                  errorWidget: (context, url, error) => MainHelper.appLoading()),
              MainHelper.appLoading(),
            ]),
    );
  }

  void playOrPause(){
    if(_controller.value.isInitialized) {

      if(_controller.value.isPlaying){
        _controller.pause();
      }else{
        _controller.play();
      }

    }
  }
}
