// ignore_for_file: file_names

import 'package:flutter_polygon_clipper/flutter_polygon_clipper.dart';
import 'package:challenge/utilities/main_utilities/colors.dart';
import 'package:flutter/material.dart';
import 'dart:math' show min;

class AvatarInitials extends StatelessWidget {
  final String? name;
  final Color? textColor;
  final Color? backgroundColor;
  final double? textSize;
  final double? avatarRadius;
  final bool? polygon;
  const AvatarInitials({Key? key,
    this.name,
    this.textColor,
    this.backgroundColor,
    this.textSize,
    this.avatarRadius,
    this.polygon = false,
  }) : super(key: key);

  String _getInitials() {
    var nameParts = name!.split(" ").map((elem) {
      return elem[0];
    });

    if (nameParts.isEmpty) {
      return "";
    }

    int numberOfParts = min(2, nameParts.length);
    return nameParts.join().substring(0, numberOfParts);
  }

  Widget _makeInitialsAvatar() {
    return !polygon!
        ? CircleAvatar(
      backgroundColor: backgroundColor ?? kPrimaryColor,
      radius: avatarRadius ?? 10,
      child: Text(
        _getInitials(),
        style: TextStyle(color: textColor ?? Colors.white, fontSize: textSize, fontWeight: FontWeight.bold),),)
        : FlutterClipPolygon(
      sides: 6,
      borderRadius: 0.0, // Defaults to 0.0 degrees
      rotate: 0.0, // Defaults to 0.0 degree,
      child: Container(
        color: backgroundColor ?? kPrimaryColor,
        child: Center(
          child: Text(
            _getInitials(),
            style: TextStyle(color: textColor ?? Colors.white, fontSize: textSize, fontWeight: FontWeight.bold),),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return _makeInitialsAvatar();
  }
}
